"""URLs for decision-engine."""
from django.urls import path

app_name = 'decision-engine'

urlpatterns = []
