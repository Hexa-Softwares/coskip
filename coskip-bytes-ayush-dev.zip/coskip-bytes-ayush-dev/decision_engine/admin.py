"""Admin configuration for decision-engine."""
from django.contrib import admin

# Admin configurations will be added here
