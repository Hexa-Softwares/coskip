"""
decision-engine App
"""
default_app_config = 'decision_engine.apps.DecisionEngineConfig'
