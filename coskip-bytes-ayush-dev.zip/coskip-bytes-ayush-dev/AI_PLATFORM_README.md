# CoSkip AI Platform - Production Django AI Orchestration

A production-grade Django REST API platform that orchestrates Vertex AI/Gemini models for field operations. Integrates seamlessly with existing CoSkip Node.js backend and React frontend.

## 🎯 Mission

CoSkip AI is **NOT** a replacement for the existing Node backend. Instead, it is an **AI orchestration layer** that:

✅ **Analyzes** field evidence using Gemini Vision  
✅ **Assists** technicians with workflow-aware guidance  
✅ **Processes** voice commands in real-time  
✅ **Tracks** AI decisions for compliance audits  
✅ **Integrates** seamlessly with Node backend (source of truth)  

## 📋 Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL 14+
- Redis 6+
- Docker & Docker Compose (recommended)
- Google Cloud credentials (Vertex AI)

### Installation (5 minutes)

```bash
# 1. Clone/extract repository
cd coskip-ai-platform

# 2. Copy environment config
cp .env.example .env
nano .env  # Edit with your values

# 3. Run with Docker Compose
docker-compose up -d

# 4. Create superuser
docker-compose exec django python manage.py createsuperuser

# 5. Access
- Django API: http://localhost:8000
- Admin: http://localhost:8000/admin
- Health: http://localhost:8000/health/
```

For detailed setup, see [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md).

## 🏗️ Architecture

```
Frontend (React)          Node Backend (Source Truth)    Django AI (Orchestration)
    │                            │                               │
    ├─ Jobs/Steps ─────────────► Node: /api/jobs          (No data here)
    ├─ Evidence Upload ────────► Node: /api/evidence       (No data here)
    │                            │                               
    └─ AI Analysis Request ──────────────────────────────► Django: /api/v1/evidence/analyze
                                                          + Call Vertex AI/Gemini
                                                          + Store results locally
                                                          + Return analysis
                                 ◄──────────────────────── 
                                       (Optional callback webhook)
```

## 📚 API Endpoints

### Evidence Analysis
```bash
# Analyze field evidence for compliance
POST /api/v1/evidence/analyze
  {
    "job_id": "job_123",
    "step_id": "step_456", 
    "evidence_id": "ev_789",
    "image_url": "https://...",
    "evidence_type": "hvac_filter",
    "playbook_id": "pb_001"
  }

# Response
{
  "analysis_id": "ana_001",
  "status": "complete",
  "decision": "pass",
  "confidence": 0.95,
  "issues": [],
  "required_actions": [],
  "summary": "HVAC filter properly installed and operational"
}
```

### Tech Assistance
```bash
# Ask workflow-aware assistant
POST /api/v1/assistant/query
  {
    "job_id": "job_123",
    "step_id": "step_456",
    "question": "What should I do next?"
  }

# Response
{
  "answer": "The next step is to verify the thermostat calibration...",
  "suggested_actions": ["verify_calibration", "document_status"],
  "references": ["requirement_45", "playbook_section_3"]
}
```

### Voice Commands
```bash
# Process voice command
POST /api/v1/voice/process
  {
    "transcript": "Submit evidence",
    "job_id": "job_123",
    "step_id": "step_456"
  }

# Response
{
  "intent": "submit_evidence",
  "confidence": 0.92,
  "action": "submit_evidence",
  "requires_confirmation": false
}
```

### Live Voice (WebSocket)
```bash
# Real-time voice conversation
WS ws://localhost:8000/ws/assistant/live

# Client sends audio chunks
# Server responds with transcripts and TTS audio
# Full duplex with interruption support
```

## 🗄️ Database Models

All models extend `TenantAwareModel` for multi-tenancy:

### apps/evidence_ai/
- `AIAnalysis` - Results from Gemini Vision analysis
- `AIRequirementCheck` - Individual requirement evaluation
- `AIOverlay` - Visual annotations on evidence

### apps/tech_assist/
- `AssistantRequest` - Conversation logs
- `AssistantResponse` - Cached responses
- `ConversationContext` - Session context

### apps/voice_ai/
- `VoiceCommand` - Command processing logs
- `VoiceExecution` - Command execution records

### apps/voice_gateway/
- `VoiceSession` - WebSocket session metadata
- `AudioChunk` - Streaming audio records

### apps/review_center/
- `AIReview` - Records pending human review
- `AIOverride` - Decision overrides with audit trail

### apps/audit_ai/
- `AIAuditEvent` - Complete audit log of all AI operations

## 🔌 Integrations

### Node Backend (Source of Truth)
```
Django queries Node for:
- Job details (cached 5 min)
- Step details (cached 5 min)
- Playbook definitions (cached 1 hr)
- Evidence metadata
- Existing issues

Django updates Node via:
- Webhook callbacks (optional)
- Direct API calls (when applicable)
```

### Vertex AI & Gemini
```
Models used:
- Gemini 2.5 Pro: Complex reasoning, tech assistant
- Gemini 2.5 Flash: Fast text analysis, intent classification
- Gemini Vision: Evidence image analysis
- Vertex Speech-to-Text: Audio transcription
- Vertex Text-to-Speech: Response audio generation
```

### WebSocket (Real-time Voice)
```
Features:
- Streaming audio input
- Real-time transcription
- Interrupt-aware responses
- Full duplex conversation
```

## 🚀 Deployment

### Local Development
```bash
docker-compose up -d
python manage.py runserver
```

### Production
```bash
# 1. Build image
docker build -t coskip-ai:latest .

# 2. Push to registry
docker tag coskip-ai:latest gcr.io/your-project/coskip-ai:latest
docker push gcr.io/your-project/coskip-ai:latest

# 3. Deploy to Cloud Run / GKE
gcloud run deploy coskip-ai \
  --image gcr.io/your-project/coskip-ai:latest \
  --platform managed \
  --region us-central1 \
  --set-env-vars DATABASE_URL=... \
  --set-env-vars REDIS_HOST=... \
  --set-env-vars VERTEX_AI_PROJECT=...
```

See [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for comprehensive details.

## 🔐 Security

- **Multi-tenancy**: Automatic tenant isolation at database level
- **Authentication**: Bearer JWT + API Key support
- **Rate Limiting**: Per-tenant and per-endpoint limits
- **Audit Trail**: Complete logging of all AI decisions
- **CORS**: Configured for frontend domains only
- **SSL/TLS**: Enforced in production

## 📊 Monitoring

### Health Checks
```bash
curl http://localhost:8000/health/    # Application health
curl http://localhost:8000/ready/     # Readiness probe
```

### Logging
```bash
# View logs
docker-compose logs -f django
docker-compose logs -f celery

# JSON structured logging in production
tail -f logs/coskip_ai.log | jq .
```

### Metrics
- Response times (X-Response-Time-Ms header)
- Rate limit status (X-RateLimit-Remaining header)
- Correlation IDs (X-Correlation-ID header)
- Error rates and types
- Model latencies

## 🧪 Testing

```bash
# Run tests
python manage.py test

# With coverage
coverage run --source='.' manage.py test
coverage report

# API integration tests
pytest --ds=config.settings

# Load testing
locust -f locustfile.py --host=http://localhost:8000
```

## 🔄 Celery Async Tasks

Background jobs for long-running operations:

```python
# Evidence analysis (async)
async_analyze_evidence.delay(analysis_id, image_path, requirements)

# Assistant response generation
generate_assistant_response.delay(assist_id, context)

# Voice session cleanup
cleanup_expired_sessions.delay()
```

## 📁 Project Structure

```
coskip-ai-platform/
├── config/                    # Django settings & ASGI/WSGI
├── apps/
│   ├── ai_core/              # Shared infrastructure
│   │   ├── models.py         # BaseModel, TenantAwareModel, APIKey
│   │   ├── services/         # VertexClient, BackendClient, Middleware
│   │   └── authentication.py # JWT, API Key auth
│   │
│   ├── evidence_ai/          # Evidence analysis & vision
│   ├── tech_assist/          # Technician assistant
│   ├── voice_ai/             # Voice command processing
│   ├── voice_gateway/        # Real-time WebSocket voice
│   ├── decision_engine/      # Decision logic & confidence
│   ├── review_center/        # Review & override UI
│   └── audit_ai/             # Audit trail
│
├── manage.py                 # Django management
├── requirements.txt          # Python dependencies
├── Dockerfile               # Container image
├── docker-compose.yml       # Full stack orchestration
├── .env.example             # Environment template
├── DEPLOYMENT_GUIDE.md      # Comprehensive deployment guide
└── README.md               # This file
```

## 🤝 Integration Checklist

### Frontend (React) Updates
- [ ] Update API endpoints to Django
- [ ] Add WebSocket client for live voice
- [ ] Include auth headers (JWT or API Key)
- [ ] Add correlation IDs to requests
- [ ] Handle rate limit responses (429)

### Node Backend Updates
- [ ] Implement webhook receiver for AI callbacks
- [ ] Create API key for Django
- [ ] Add AI analysis metadata to evidence records
- [ ] Update workflow logic to check AI decisions

### DevOps
- [ ] Set up PostgreSQL (14+)
- [ ] Set up Redis (6+)
- [ ] Configure Google Cloud service account
- [ ] Set up DNS for api.coskip.ai
- [ ] Configure SSL certificates
- [ ] Set up monitoring & alerts

## 🐛 Troubleshooting

### Vertex AI Connection Fails
```
Check:
1. VERTEX_AI_ENABLED=True in .env
2. Google Cloud credentials configured
3. gcloud auth application-default login
4. Project has Vertex AI APIs enabled
```

### WebSocket Connection Drops
```
Check:
1. Daphne service running (docker-compose logs daphne)
2. CHANNEL_LAYERS Redis connection
3. Browser WebSocket support
4. CORS allows WebSocket upgrade headers
```

### Rate Limiting Too Strict
```
Adjust in .env:
RATE_LIMIT_EVIDENCE_ANALYSIS=100/60  # 100 req/min
RATE_LIMIT_VOICE=200/60              # 200 req/min
```

## 📖 Documentation

- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - Complete deployment instructions, architecture, and integration guide
- **[API.md](docs/API.md)** - Detailed API documentation
- **[ARCHITECTURE.md](docs/ARCHITECTURE.md)** - System design and data flow
- **Admin Panel**: `/admin/` - Django admin interface

## 📞 Support

For issues or questions:
1. Check [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) troubleshooting section
2. Review Django logs: `docker-compose logs django`
3. Check Celery logs: `docker-compose logs celery`
4. Contact: engineering@coskip.ai

## 📄 License

©️ 2026 CoSkip - All Rights Reserved

## 👥 Team

**Architecture & Implementation**
- Senior Staff Engineer
- Backend Team

**Deployed & Maintained By**
- DevOps Team
- Platform Engineering

---

**Version**: 1.0  
**Last Updated**: June 2026  
**Status**: Production Ready ✅
