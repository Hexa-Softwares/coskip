"""
Custom exception handler for REST framework.

Provides consistent error response format across all API endpoints.
"""

import logging
from rest_framework.response import Response
from rest_framework.exceptions import APIException
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR

logger = logging.getLogger(__name__)


def coskip_exception_handler(exc, context):
    """
    Custom exception handler that returns consistent error format.
    
    All errors include:
    - error_code: machine-readable error identifier
    - message: human-readable error message
    - correlation_id: for tracing
    - timestamp: when error occurred
    """
    
    request = context.get('request')
    correlation_id = getattr(request, 'correlation_id', 'unknown')
    
    if isinstance(exc, APIException):
        data = {
            'error_code': getattr(exc, 'code', 'api_error'),
            'message': str(exc.detail),
            'correlation_id': correlation_id,
            'status_code': exc.status_code,
        }
        
        # Add debug info if in DEBUG mode
        from django.conf import settings
        if settings.DEBUG:
            data['debug'] = str(exc)
        
        return Response(data, status=exc.status_code)
    
    # Handle unexpected errors
    logger.exception(
        f"Unhandled exception",
        extra={
            'correlation_id': correlation_id,
            'exception_type': type(exc).__name__,
        }
    )
    
    data = {
        'error_code': 'internal_server_error',
        'message': 'An unexpected error occurred',
        'correlation_id': correlation_id,
        'status_code': HTTP_500_INTERNAL_SERVER_ERROR,
    }
    
    return Response(data, status=HTTP_500_INTERNAL_SERVER_ERROR)
