"""
Vertex AI clients for Gemini and Speech services.

Provides thread-safe clients for:
- Gemini 2.5 Pro (reasoning tasks)
- Gemini 2.5 Flash (fast tasks)
- Gemini Vision (image analysis)
- Gemini Live (real-time voice conversations)
- Vertex Speech-to-Text
- Vertex Text-to-Speech
"""

import logging
import threading
import json
from typing import Any, Optional, Dict, List
from functools import lru_cache
from django.conf import settings

logger = logging.getLogger(__name__)

_vertex_initialized = False
_init_lock = threading.Lock()


class VertexClientError(Exception):
    """Raised when Vertex AI operations fail."""
    pass


class VertexClientManager:
    """Thread-safe manager for Vertex AI clients."""
    
    def __init__(self):
        self._lock = threading.Lock()
        self._gemini_pro_client = None
        self._gemini_flash_client = None
        self._gemini_vision_client = None
        self._speech_client = None
        self._initialized = False
    
    def _ensure_initialized(self):
        """Initialize Vertex AI connection (thread-safe)."""
        global _vertex_initialized
        if _vertex_initialized:
            return
        
        with _init_lock:
            if _vertex_initialized:
                return
            
            if not settings.VERTEX_AI_ENABLED:
                logger.warning("Vertex AI is disabled in settings")
                return
            
            try:
                import vertexai
                vertexai.init(
                    project=settings.VERTEX_AI_PROJECT,
                    location=settings.VERTEX_AI_LOCATION
                )
                _vertex_initialized = True
                logger.info(
                    f"Vertex AI initialized: project={settings.VERTEX_AI_PROJECT}, "
                    f"location={settings.VERTEX_AI_LOCATION}"
                )
            except Exception as e:
                logger.error(f"Failed to initialize Vertex AI: {e}")
                raise VertexClientError(f"Vertex AI initialization failed: {e}")
    
    def get_gemini_pro(self):
        """Get Gemini 2.5 Pro client (reasoning)."""
        with self._lock:
            if self._gemini_pro_client is None:
                self._ensure_initialized()
                try:
                    from vertexai.generative_models import GenerativeModel
                    self._gemini_pro_client = GenerativeModel(settings.GEMINI_PRO_MODEL)
                    logger.debug(f"Initialized {settings.GEMINI_PRO_MODEL} client")
                except Exception as e:
                    raise VertexClientError(f"Failed to create Gemini Pro client: {e}")
            return self._gemini_pro_client
    
    def get_gemini_flash(self):
        """Get Gemini 2.5 Flash client (fast responses)."""
        with self._lock:
            if self._gemini_flash_client is None:
                self._ensure_initialized()
                try:
                    from vertexai.generative_models import GenerativeModel
                    self._gemini_flash_client = GenerativeModel(settings.GEMINI_FLASH_MODEL)
                    logger.debug(f"Initialized {settings.GEMINI_FLASH_MODEL} client")
                except Exception as e:
                    raise VertexClientError(f"Failed to create Gemini Flash client: {e}")
            return self._gemini_flash_client
    
    def get_gemini_vision(self):
        """Get Gemini Vision client (image analysis)."""
        with self._lock:
            if self._gemini_vision_client is None:
                self._ensure_initialized()
                try:
                    from vertexai.generative_models import GenerativeModel
                    self._gemini_vision_client = GenerativeModel(settings.GEMINI_VISION_MODEL)
                    logger.debug(f"Initialized {settings.GEMINI_VISION_MODEL} client")
                except Exception as e:
                    raise VertexClientError(f"Failed to create Gemini Vision client: {e}")
            return self._gemini_vision_client
    
    def get_speech_client(self):
        """Get Vertex Speech-to-Text client."""
        with self._lock:
            if self._speech_client is None:
                try:
                    from google.cloud import speech_v1
                    self._speech_client = speech_v1.SpeechClient()
                    logger.debug("Initialized Speech-to-Text client")
                except Exception as e:
                    raise VertexClientError(f"Failed to create Speech client: {e}")
            return self._speech_client


# Global singleton instance
_manager = VertexClientManager()


def get_gemini_pro():
    """Get Gemini 2.5 Pro client."""
    return _manager.get_gemini_pro()


def get_gemini_flash():
    """Get Gemini 2.5 Flash client."""
    return _manager.get_gemini_flash()


def get_gemini_vision():
    """Get Gemini Vision client."""
    return _manager.get_gemini_vision()


def get_speech_client():
    """Get Speech-to-Text client."""
    return _manager.get_speech_client()


def warmup_vertex_ai():
    """
    Warm up Vertex AI connection at startup.
    Runs in background thread to avoid blocking Django initialization.
    """
    import sys
    
    # Only warm up for server processes, not for management commands
    if len(sys.argv) >= 2 and sys.argv[0].endswith('manage.py'):
        if sys.argv[1] not in ['runserver', 'runsslserver']:
            return
    
    def _warmup():
        try:
            if not settings.VERTEX_AI_ENABLED:
                return
            
            from vertexai.generative_models import GenerativeModel, GenerationConfig
            model = get_gemini_flash()
            model.generate_content(
                "Reply with exactly one word: ready",
                generation_config=GenerationConfig(max_output_tokens=5, temperature=0.0),
            )
            logger.info("Vertex AI warm-up complete")
        except Exception as e:
            logger.warning(f"Vertex AI warm-up failed (non-fatal): {e}")
    
    t = threading.Thread(target=_warmup, daemon=True, name='vertex-ai-warmup')
    t.start()


class PromptBuilder:
    """Helper for building structured prompts."""
    
    @staticmethod
    def build_evidence_analysis_prompt(
        evidence_type: str,
        requirements: List[str],
        previous_analyses: Optional[List[Dict]] = None,
        context: Optional[Dict] = None,
    ) -> str:
        """Build prompt for evidence analysis."""
        
        prompt = f"""You are a field operations AI assistant analyzing evidence for {evidence_type} compliance.

Requirements to check:
{json.dumps(requirements, indent=2)}

{f'Previous analyses: {json.dumps(previous_analyses, indent=2)}' if previous_analyses else ''}

{f'Additional context: {json.dumps(context, indent=2)}' if context else ''}

Provide analysis in JSON format with:
- decision (pass/fail/needs_action)
- confidence (0-1)
- summary
- issues (list of detected problems)
- required_actions (list of actions needed)
- notes"""
        
        return prompt
    
    @staticmethod
    def build_assistant_prompt(
        question: str,
        job_context: Dict,
        step_context: Dict,
        evidence_context: Optional[List[Dict]] = None,
        playbook_context: Optional[Dict] = None,
    ) -> str:
        """Build prompt for tech assistant."""
        
        prompt = f"""You are a field operations assistant helping a technician.

Technician question: {question}

Job context:
{json.dumps(job_context, indent=2)}

Current step:
{json.dumps(step_context, indent=2)}

{f'Evidence collected: {json.dumps(evidence_context, indent=2)}' if evidence_context else ''}

{f'Playbook guidance: {json.dumps(playbook_context, indent=2)}' if playbook_context else ''}

Provide a helpful, concise response focused on the immediate task at hand.
Include actionable next steps if applicable."""
        
        return prompt


class ContextBuilder:
    """Helper for building analysis contexts."""
    
    @staticmethod
    def build_evidence_context(
        evidence_id: str,
        evidence_data: Dict,
        previous_analyses: Optional[List[Dict]] = None,
    ) -> Dict:
        """Build context for evidence analysis."""
        return {
            'evidence_id': evidence_id,
            'evidence_type': evidence_data.get('type'),
            'label': evidence_data.get('label'),
            'timestamp': evidence_data.get('timestamp'),
            'previous_analyses': previous_analyses or [],
        }
