"""
CoskipBackendClient - Integration with Node backend.

Provides methods to fetch and update data from the Node.js/Azure backend.
This ensures Django only acts as an AI orchestration layer,
never duplicating business logic or data ownership.
"""

import logging
import httpx
import json
from typing import Optional, Dict, Any, List
from django.conf import settings
from django.core.cache import cache

logger = logging.getLogger(__name__)


class CoskipBackendError(Exception):
    """Raised when backend communication fails."""
    pass


class CoskipBackendClient:
    """HTTP client for Node backend integration."""
    
    def __init__(self):
        self.base_url = settings.COSKIP_BACKEND_BASE_URL
        self.api_key = settings.COSKIP_BACKEND_API_KEY
        self.timeout = settings.COSKIP_BACKEND_TIMEOUT_SECONDS
        self.headers = {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json',
        }
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make HTTP request to Node backend."""
        
        url = f"{self.base_url}{endpoint}"
        
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.request(
                    method,
                    url,
                    headers=self.headers,
                    params=params,
                    json=json_data,
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Backend request failed: {method} {url} - {e}")
            raise CoskipBackendError(f"Backend request failed: {e}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse backend response: {e}")
            raise CoskipBackendError(f"Invalid backend response: {e}")
    
    def get_job(self, job_id: str, tenant_id: Optional[str] = None) -> Dict:
        """Fetch job details from backend."""
        
        cache_key = f"job:{job_id}"
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        try:
            result = self._make_request('GET', f'/api/jobs/{job_id}')
            cache.set(cache_key, result, 300)  # 5 minutes
            return result
        except Exception as e:
            logger.error(f"Failed to fetch job {job_id}: {e}")
            raise
    
    def get_step(self, step_id: str, tenant_id: Optional[str] = None) -> Dict:
        """Fetch job step details from backend."""
        
        cache_key = f"step:{step_id}"
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        try:
            result = self._make_request('GET', f'/api/steps/{step_id}')
            cache.set(cache_key, result, 300)
            return result
        except Exception as e:
            logger.error(f"Failed to fetch step {step_id}: {e}")
            raise
    
    def get_playbook(self, playbook_id: str) -> Dict:
        """Fetch playbook details from backend."""
        
        cache_key = f"playbook:{playbook_id}"
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        try:
            result = self._make_request('GET', f'/api/playbooks/{playbook_id}')
            cache.set(cache_key, result, 3600)  # 1 hour
            return result
        except Exception as e:
            logger.error(f"Failed to fetch playbook {playbook_id}: {e}")
            raise
    
    def get_evidence(self, evidence_id: str) -> Dict:
        """Fetch evidence details from backend."""
        
        cache_key = f"evidence:{evidence_id}"
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        try:
            result = self._make_request('GET', f'/api/evidence/{evidence_id}')
            cache.set(cache_key, result, 600)  # 10 minutes
            return result
        except Exception as e:
            logger.error(f"Failed to fetch evidence {evidence_id}: {e}")
            raise
    
    def get_issues(self, job_id: str) -> List[Dict]:
        """Fetch issues for a job from backend."""
        
        cache_key = f"issues:job:{job_id}"
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        try:
            result = self._make_request('GET', '/api/issues', params={'job_id': job_id})
            cache.set(cache_key, result, 300)
            return result.get('issues', [])
        except Exception as e:
            logger.error(f"Failed to fetch issues for job {job_id}: {e}")
            raise
    
    def create_issue(
        self,
        job_id: str,
        step_id: str,
        issue_type: str,
        severity: str,
        description: str,
        tenant_id: Optional[str] = None,
    ) -> Dict:
        """Create an issue in backend."""
        
        data = {
            'job_id': job_id,
            'step_id': step_id,
            'issue_type': issue_type,
            'severity': severity,
            'description': description,
        }
        
        try:
            result = self._make_request('POST', '/api/issues', json_data=data)
            # Clear cache for this job
            cache.delete(f"issues:job:{job_id}")
            return result
        except Exception as e:
            logger.error(f"Failed to create issue for job {job_id}: {e}")
            raise
    
    def complete_step(
        self,
        step_id: str,
        job_id: str,
        tenant_id: Optional[str] = None,
    ) -> Dict:
        """Mark a step as complete in backend."""
        
        data = {'status': 'completed'}
        
        try:
            result = self._make_request('PATCH', f'/api/steps/{step_id}', json_data=data)
            # Clear cache
            cache.delete(f"step:{step_id}")
            cache.delete(f"job:{job_id}")
            return result
        except Exception as e:
            logger.error(f"Failed to complete step {step_id}: {e}")
            raise
    
    def request_approval(
        self,
        job_id: str,
        step_id: str,
        reason: str,
        tenant_id: Optional[str] = None,
    ) -> Dict:
        """Request approval in backend."""
        
        data = {
            'job_id': job_id,
            'step_id': step_id,
            'reason': reason,
        }
        
        try:
            result = self._make_request('POST', '/api/approvals', json_data=data)
            return result
        except Exception as e:
            logger.error(f"Failed to request approval for step {step_id}: {e}")
            raise
    
    def add_evidence_metadata(
        self,
        evidence_id: str,
        metadata: Dict[str, Any],
        tenant_id: Optional[str] = None,
    ) -> Dict:
        """Add AI analysis metadata to evidence in backend."""
        
        data = {'metadata': metadata}
        
        try:
            result = self._make_request(
                'PATCH',
                f'/api/evidence/{evidence_id}/metadata',
                json_data=data
            )
            # Clear cache
            cache.delete(f"evidence:{evidence_id}")
            return result
        except Exception as e:
            logger.error(f"Failed to update evidence metadata {evidence_id}: {e}")
            raise


# Global singleton instance
_client = None


def get_coskip_backend_client() -> CoskipBackendClient:
    """Get or create singleton backend client."""
    global _client
    if _client is None:
        _client = CoskipBackendClient()
    return _client
