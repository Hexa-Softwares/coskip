"""
Middleware for CoSkip AI Platform.

Provides:
- Correlation ID tracking for distributed tracing
- Tenant isolation and context propagation
- Rate limiting per endpoint
"""

import uuid
import logging
import time
from typing import Callable
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.core.cache import cache
from django.conf import settings
from django.utils.deprecation import MiddlewareMixin

logger = logging.getLogger(__name__)


class CorrelationIdMiddleware(MiddlewareMixin):
    """
    Adds/preserves correlation ID header for request tracing.
    
    If X-Correlation-ID header is present, uses it.
    Otherwise generates a new correlation ID.
    Adds to response headers and stores in thread-local context.
    """
    
    def process_request(self, request: HttpRequest):
        correlation_id = (
            request.META.get('HTTP_X_CORRELATION_ID') or
            request.META.get('X-Correlation-ID') or
            f"corr_{uuid.uuid4().hex[:16]}"
        )
        request.correlation_id = correlation_id
        request.META['X-Correlation-ID'] = correlation_id
        return None
    
    def process_response(self, request: HttpRequest, response: HttpResponse):
        correlation_id = getattr(request, 'correlation_id', None)
        if correlation_id:
            response['X-Correlation-ID'] = correlation_id
        return response


class TenantMiddleware(MiddlewareMixin):
    """
    Multi-tenancy middleware.
    
    Extracts tenant_id from:
    1. X-Tenant-ID header
    2. JWT token claim
    3. APIKey tenant_id
    
    Enforces tenant isolation at request level.
    """
    
    def process_request(self, request: HttpRequest):
        # Extract tenant ID
        tenant_id = (
            request.META.get('HTTP_X_TENANT_ID') or
            self._extract_from_token(request)
        )
        
        if not settings.MULTI_TENANCY_ENABLED:
            tenant_id = tenant_id or 'default'
        
        request.tenant_id = tenant_id
        request.META['X-Tenant-ID'] = tenant_id or ''
        
        return None
    
    def _extract_from_token(self, request: HttpRequest) -> str:
        """Extract tenant_id from JWT token if present."""
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if auth_header.startswith('Bearer '):
            try:
                import jwt
                from django.conf import settings as django_settings
                token = auth_header[7:]
                payload = jwt.decode(
                    token,
                    django_settings.SECRET_KEY,
                    algorithms=['HS256']
                )
                return payload.get('tenant_id')
            except Exception:
                pass
        return None


class RateLimitMiddleware(MiddlewareMixin):
    """
    Rate limiting middleware.
    
    Supports per-tenant and per-user rate limiting.
    Format: "10/60" means 10 requests per 60 seconds.
    """
    
    # Endpoint-specific rate limit configs
    RATE_LIMITS = {
        '/api/v1/evidence/analyze': 'RATE_LIMIT_EVIDENCE_ANALYSIS',
        '/api/v1/voice/': 'RATE_LIMIT_VOICE',
        '/api/v1/assistant/': 'RATE_LIMIT_ASSIST',
        '/ws/assistant/live': 'RATE_LIMIT_LIVE_VOICE',
    }
    
    def process_request(self, request: HttpRequest):
        if request.method in ['OPTIONS']:
            return None
        
        # Get applicable rate limit
        rate_limit_setting = self._get_rate_limit_setting(request)
        if not rate_limit_setting:
            return None
        
        # Check rate limit
        key = self._build_cache_key(request)
        is_allowed, remaining = self._check_rate_limit(key, rate_limit_setting)
        
        if not is_allowed:
            response = JsonResponse(
                {
                    'error': 'rate_limit_exceeded',
                    'message': 'Too many requests',
                    'retry_after': 60,
                },
                status=429
            )
            response['Retry-After'] = '60'
            return response
        
        request.rate_limit_remaining = remaining
        return None
    
    def process_response(self, request: HttpRequest, response: HttpResponse):
        if hasattr(request, 'rate_limit_remaining'):
            response['X-RateLimit-Remaining'] = str(request.rate_limit_remaining)
        return response
    
    def _get_rate_limit_setting(self, request: HttpRequest) -> str:
        """Get rate limit config for request."""
        path = request.path
        
        for endpoint_pattern, setting_name in self.RATE_LIMITS.items():
            if path.startswith(endpoint_pattern):
                return getattr(settings, setting_name, None)
        
        return None
    
    def _build_cache_key(self, request: HttpRequest) -> str:
        """Build cache key for rate limiting."""
        tenant_id = getattr(request, 'tenant_id', 'anonymous')
        user_id = (
            request.user.id if request.user and request.user.is_authenticated
            else 'anonymous'
        )
        path = request.path.split('?')[0]  # Remove query string
        return f"ratelimit:{tenant_id}:{user_id}:{path}"
    
    def _check_rate_limit(self, key: str, rate_limit_str: str) -> tuple:
        """
        Check if request is within rate limit.
        
        Returns: (is_allowed: bool, remaining: int)
        """
        try:
            limit, window = map(int, rate_limit_str.split('/'))
        except (ValueError, AttributeError):
            return True, limit  # Invalid format, allow through
        
        current = cache.get(key, 0)
        
        if current >= limit:
            return False, 0
        
        cache.set(key, current + 1, window)
        return True, limit - current - 1


class RequestTimingMiddleware(MiddlewareMixin):
    """Record request timing for performance monitoring."""
    
    def process_request(self, request: HttpRequest):
        request._start_time = time.time()
        return None
    
    def process_response(self, request: HttpRequest, response: HttpResponse):
        if hasattr(request, '_start_time'):
            duration_ms = int((time.time() - request._start_time) * 1000)
            response['X-Response-Time-Ms'] = str(duration_ms)
            
            if duration_ms > 5000:  # Log slow requests
                logger.warning(
                    f"Slow request: {request.method} {request.path} "
                    f"took {duration_ms}ms",
                    extra={
                        'correlation_id': getattr(request, 'correlation_id', None),
                        'tenant_id': getattr(request, 'tenant_id', None),
                    }
                )
        
        return response
