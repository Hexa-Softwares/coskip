"""
AI Core App - Shared infrastructure.
Provides: Vertex AI clients, auth, middleware, tenant isolation.
"""

default_app_config = 'ai_core.apps.AiCoreConfig'
