"""
Core abstract base models and the APIKey model for CoSkip AI Platform.

These classes were previously located in apps/ai_core/models.py.
After the folder restructure they now live here as the canonical source.
"""
import uuid
from django.db import models
from django.utils import timezone


# ---------------------------------------------------------------------------
# Abstract base models
# ---------------------------------------------------------------------------

class TenantAwareModel(models.Model):
    """
    Abstract base class that adds tenant isolation to any model.

    Every concrete model that inherits this will carry a ``tenant_id``
    field so that row-level tenant filtering is always available.
    """
    tenant_id = models.CharField(
        max_length=128,
        db_index=True,
        default='default',
        help_text='Tenant identifier for multi-tenancy isolation.',
    )

    class Meta:
        abstract = True


class CorrelationAwareModel(models.Model):
    """
    Abstract base class that stores the correlation ID from the originating
    HTTP request, enabling end-to-end distributed tracing.
    """
    correlation_id = models.CharField(
        max_length=64,
        blank=True,
        default='',
        db_index=True,
        help_text='Correlation ID propagated from the HTTP request.',
    )

    class Meta:
        abstract = True


# ---------------------------------------------------------------------------
# APIKey model
# ---------------------------------------------------------------------------

class APIKey(models.Model):
    """
    API key for service-to-service and external authentication.
    """
    key = models.CharField(max_length=256, unique=True, db_index=True)
    name = models.CharField(max_length=128, blank=True, default='')
    tenant_id = models.CharField(max_length=128, blank=True, default='default', db_index=True)
    created_by = models.CharField(max_length=256, blank=True, default='')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(default=timezone.now)
    last_used_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'API Key'
        verbose_name_plural = 'API Keys'

    def __str__(self):
        return f"{self.name or self.key[:12]}… (tenant={self.tenant_id})"

    def mark_used(self):
        """Update the last-used timestamp."""
        self.last_used_at = timezone.now()
        self.save(update_fields=['last_used_at'])
