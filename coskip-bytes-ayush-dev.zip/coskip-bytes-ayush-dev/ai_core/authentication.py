"""
Authentication classes for CoSkip AI Platform.

Supports:
- Bearer token (JWT)
- X-API-Key header
- API key database authentication
"""

import jwt
import logging
from typing import Optional, Tuple
from django.conf import settings
from django.contrib.auth.models import AnonymousUser
from rest_framework.authentication import TokenAuthentication, BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from ai_core.models import APIKey

logger = logging.getLogger(__name__)


class CoSkipUser:
    """Custom user object for API authentication."""
    
    def __init__(self, user_id: str, tenant_id: str, role: str = 'user', is_active: bool = True):
        self.id = user_id
        self.tenant_id = tenant_id
        self.role = role
        self.is_active = is_active
        self.is_authenticated = True
        self.is_anonymous = False
    
    def has_perm(self, perm: str) -> bool:
        """Simple permission check based on role."""
        if self.role == 'admin':
            return True
        
        role_perms = {
            'tech': ['evidence_analysis', 'voice_commands', 'assistance'],
            'ops': ['evidence_analysis', 'voice_commands', 'assistance', 'overrides'],
            'admin': ['*'],
        }
        return perm in role_perms.get(self.role, [])


class BearerTokenAuthentication(BaseAuthentication):
    """
    Authenticate using JWT Bearer tokens.
    
    Expected format: Authorization: Bearer <jwt_token>
    """
    
    def authenticate(self, request) -> Optional[Tuple]:
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        
        if not auth_header.startswith('Bearer '):
            return None
        
        token = auth_header[7:]
        
        try:
            payload = jwt.decode(
                token,
                settings.SECRET_KEY,
                algorithms=['HS256']
            )
            
            user = CoSkipUser(
                user_id=payload.get('user_id'),
                tenant_id=payload.get('tenant_id'),
                role=payload.get('role', 'user'),
            )
            
            return (user, token)
        
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Token has expired')
        except jwt.InvalidTokenError as e:
            logger.warning(f"Invalid JWT token: {e}")
            raise AuthenticationFailed('Invalid token')
    
    def authenticate_header(self, request):
        return 'Bearer realm="api"'


class APIKeyAuthentication(BaseAuthentication):
    """
    Authenticate using X-API-Key header.
    
    Expected format: X-API-Key: <api_key_value>
    """
    
    def authenticate(self, request) -> Optional[Tuple]:
        api_key_header = request.META.get('HTTP_X_API_KEY')
        
        if not api_key_header:
            return None
        
        try:
            # Try to find the API key in database
            api_key_obj = APIKey.objects.get(key=api_key_header, is_active=True)
            api_key_obj.mark_used()
            
            # Create user object from API key
            user = CoSkipUser(
                user_id=api_key_obj.created_by or f'api_key_{api_key_obj.id}',
                tenant_id=api_key_obj.tenant_id or 'default',
                role='api',
            )
            
            return (user, api_key_obj)
        
        except APIKey.DoesNotExist:
            logger.warning(f"Invalid API key attempted")
            raise AuthenticationFailed('Invalid API key')
        except Exception as e:
            logger.error(f"Error authenticating with API key: {e}")
            raise AuthenticationFailed('Authentication failed')
    
    def authenticate_header(self, request):
        return 'X-API-Key'


class ServiceToServiceAuthentication(BaseAuthentication):
    """
    Authenticate service-to-service calls using shared secrets.
    
    Expected format: X-Service-ID: <service_id>, X-Service-Secret: <secret>
    """
    
    # Map of service IDs to shared secrets
    SERVICES = {
        'node-backend': settings.COSKIP_BACKEND_API_KEY,
        'frontend': getattr(settings, 'FRONTEND_SERVICE_SECRET', ''),
    }
    
    def authenticate(self, request) -> Optional[Tuple]:
        service_id = request.META.get('HTTP_X_SERVICE_ID')
        service_secret = request.META.get('HTTP_X_SERVICE_SECRET')
        
        if not service_id or not service_secret:
            return None
        
        if service_id not in self.SERVICES:
            raise AuthenticationFailed('Unknown service')
        
        if self.SERVICES[service_id] != service_secret:
            raise AuthenticationFailed('Invalid service secret')
        
        user = CoSkipUser(
            user_id=f'service:{service_id}',
            tenant_id='system',
            role='system',
        )
        
        return (user, service_id)
    
    def authenticate_header(self, request):
        return 'X-Service-ID'
