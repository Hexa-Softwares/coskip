"""URLs for ai-core."""
from django.urls import path

app_name = 'ai-core'

urlpatterns = []
