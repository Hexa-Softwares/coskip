"""Tests for voice_gateway."""
from django.test import TestCase

# Tests will be added here
