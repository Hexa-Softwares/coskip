"""Django app configuration for voice_gateway."""
from django.apps import AppConfig

class Voice_gatewayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'voice_gateway'
    verbose_name = 'Voice_Gateway'
