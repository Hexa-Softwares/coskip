from django.urls import re_path

websocket_urlpatterns = [
    # Add your websocket URL patterns here, e.g.:
    # re_path(r'ws/voice/$', consumers.VoiceConsumer.as_asgi()),
]
