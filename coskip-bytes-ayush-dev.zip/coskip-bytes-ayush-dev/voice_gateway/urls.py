"""URLs for voice_gateway."""
from django.urls import path

urlpatterns = []
