"""Serializers for voice_gateway."""
from rest_framework import serializers

# Serializers will be added here
