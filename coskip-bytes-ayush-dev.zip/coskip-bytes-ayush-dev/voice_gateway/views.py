"""Views for voice_gateway."""
from rest_framework import viewsets

# Views will be added here
