"""Admin configuration for voice_gateway."""
from django.contrib import admin

# Admin configurations will be added here
