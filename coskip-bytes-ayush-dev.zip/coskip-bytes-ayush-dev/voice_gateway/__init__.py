"""
voice_gateway App
"""
default_app_config = 'voice_gateway.apps.Voice_gatewayConfig'
