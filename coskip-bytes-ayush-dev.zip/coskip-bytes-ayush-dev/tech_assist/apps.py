"""Django app configuration for tech-assist."""
from django.apps import AppConfig

class TechAssistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tech_assist'
    verbose_name = 'Tech Assist'
