"""Tests for tech-assist."""
from django.test import TestCase

# Tests will be added here
