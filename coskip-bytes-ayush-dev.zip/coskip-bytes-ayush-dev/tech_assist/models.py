"""Models for tech-assist."""
from django.db import models
from ai_core.models import TenantAwareModel

# Models will be added here
