"""Admin configuration for tech-assist."""
from django.contrib import admin

# Admin configurations will be added here
