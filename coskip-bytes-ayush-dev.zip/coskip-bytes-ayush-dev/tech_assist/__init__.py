"""
tech-assist App
"""
default_app_config = 'tech_assist.apps.TechAssistConfig'
