"""URLs for tech-assist."""
from django.urls import path
from . import views

app_name = 'tech-assist'

urlpatterns = [
    path('query', views.QueryAssistantView.as_view(), name='query'),
]
