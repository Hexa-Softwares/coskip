"""Serializers for tech-assist."""
from rest_framework import serializers

# Serializers will be added here
