# CoSkip AI Platform - Deployment & Integration Report

## Executive Summary

This is a production-grade Django AI orchestration platform for CoSkip field operations. It integrates with:
- **Existing Node.js/Azure backend** (Source of truth for Jobs, Steps, Evidence, Issues)
- **Vertex AI / Gemini 2.5** (Evidence analysis, Tech assistance, Voice commands)
- **Existing React Frontend** (ai.coskip.com)

**Key Principle**: Django is an AI layer, NOT a data layer. All data operations go through Node backend.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    React Frontend                            │
│              (ai.coskip.com - unchanged)                    │
└────────────────────────────┬────────────────────────────────┘
                             │
                ┌────────────┴────────────┐
                │                         │
        ┌───────▼──────────┐     ┌───────▼──────────┐
        │  Node Backend    │     │   Django AI      │
        │  (Source Truth)  │◄───►│   (Orchestration)│
        │  - Jobs          │     │ - Gemini 2.5 Pro │
        │  - Steps         │     │ - Gemini Vision  │
        │  - Evidence      │     │ - Speech STT/TTS │
        │  - Issues        │     │ - WebSockets     │
        └──────────────────┘     └────────┬─────────┘
                                         │
                            ┌────────────┴────────────┐
                            │                         │
                    ┌───────▼──────┐        ┌────────▼──────┐
                    │ Vertex AI    │        │ PostgreSQL    │
                    │ (Gemini 2.5) │        │ (Audit/Cache) │
                    └──────────────┘        └───────────────┘
```

---

## Installation & Setup

### Prerequisites

- Python 3.11+
- PostgreSQL 14+
- Redis 6+
- Google Cloud credentials (for Vertex AI)
- Docker & Docker Compose (for containerized deployment)

### Step 1: Clone & Install Dependencies

```bash
# Clone or extract the Django app
cd coskip-ai-platform

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Configure Environment

```bash
# Copy template
cp .env.example .env

# Edit with your values
nano .env
```

See **Environment Configuration** section below.

### Step 3: Database Setup

```bash
# Run migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Create initial API key (optional)
python manage.py shell
>>> from apps.ai_core.models import APIKey
>>> APIKey.objects.create(key='your-key', name='Bootstrap Key', tenant_id='default')
```

### Step 4: Run Development Server

```bash
# Terminal 1: Django application server
python manage.py runserver

# Terminal 2: Celery worker
celery -A config worker -l info

# Terminal 3: Celery beat (for scheduled tasks)
celery -A config beat -l info
```

Access at: `http://localhost:8000`

---

## Environment Configuration

### .env.example

```properties
# ============================================================================
# SECURITY
# ============================================================================
DEBUG=False
SECRET_KEY=your-secret-key-change-in-production
ALLOWED_HOSTS=api.coskip.ai,localhost,127.0.0.1
IS_PRODUCTION=False

# ============================================================================
# DATABASE
# ============================================================================
# Format: postgresql://user:password@host:port/database
DATABASE_URL=postgresql://coskip_user:secure_password@localhost:5432/coskip_ai

# ============================================================================
# REDIS & CELERY
# ============================================================================
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0

# ============================================================================
# GOOGLE CLOUD / VERTEX AI
# ============================================================================
VERTEX_AI_ENABLED=True
VERTEX_AI_PROJECT=woven-environs-479604-i6
VERTEX_AI_LOCATION=global
GEMINI_PRO_MODEL=gemini-2.5-pro
GEMINI_FLASH_MODEL=gemini-2.5-flash
GEMINI_VISION_MODEL=gemini-2.5-flash-vision

# Timeouts (seconds)
VERTEX_AI_TIMEOUT_SECONDS=30
VERTEX_STT_TIMEOUT_SECONDS=30
VERTEX_TTS_TIMEOUT_SECONDS=30
ASSIST_TIMEOUT_SECONDS=15
VOICE_TIMEOUT_SECONDS=20

# ============================================================================
# NODE BACKEND INTEGRATION
# ============================================================================
COSKIP_BACKEND_BASE_URL=http://localhost:3000
COSKIP_BACKEND_API_KEY=your-api-key-for-backend
COSKIP_BACKEND_TIMEOUT_SECONDS=10

# ============================================================================
# CORS & FRONTEND
# ============================================================================
CORS_ALLOWED_ORIGINS=http://localhost:7073,https://ai.coskip.com
CORS_ALLOW_ALL_ORIGINS=False

# ============================================================================
# RATE LIMITING
# ============================================================================
RATE_LIMIT_EVIDENCE_ANALYSIS=60/60
RATE_LIMIT_VOICE=120/60
RATE_LIMIT_ASSIST=60/60
RATE_LIMIT_LIVE_VOICE=20/60

# ============================================================================
# OBSERVABILITY
# ============================================================================
ENABLE_OTEL=False
MULTI_TENANCY_ENABLED=True

# ============================================================================
# BOOTSTRAP (Initial Setup)
# ============================================================================
BOOTSTRAP_API_KEY=
```

---

## Docker Deployment

### docker-compose.yml

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: coskip_user
      POSTGRES_PASSWORD: secure_password
      POSTGRES_DB: coskip_ai
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U coskip_user"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  django:
    build: .
    command: gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 4
    environment:
      DATABASE_URL: postgresql://coskip_user:secure_password@postgres:5432/coskip_ai
      REDIS_HOST: redis
      VERTEX_AI_PROJECT: ${VERTEX_AI_PROJECT}
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./logs:/app/logs
    env_file: .env

  celery:
    build: .
    command: celery -A config worker -l info
    environment:
      DATABASE_URL: postgresql://coskip_user:secure_password@postgres:5432/coskip_ai
      REDIS_HOST: redis
      VERTEX_AI_PROJECT: ${VERTEX_AI_PROJECT}
    depends_on:
      - postgres
      - redis
    env_file: .env

  celery-beat:
    build: .
    command: celery -A config beat -l info --scheduler django_celery_beat.schedulers:DatabaseScheduler
    environment:
      DATABASE_URL: postgresql://coskip_user:secure_password@postgres:5432/coskip_ai
      REDIS_HOST: redis
      VERTEX_AI_PROJECT: ${VERTEX_AI_PROJECT}
    depends_on:
      - postgres
      - redis
    env_file: .env

volumes:
  postgres_data:
```

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Collect static files
RUN python manage.py collectstatic --noinput

# Create logs directory
RUN mkdir -p logs

EXPOSE 8000

CMD ["gunicorn", "config.wsgi:application", "--bind", "0.0.0.0:8000"]
```

---

## API Endpoints

### Evidence Analysis
```
POST /api/v1/evidence/analyze
  Analyze field evidence image for compliance
  Request: image file, job_id, step_id, evidence_type
  Response: decision, confidence, issues, required_actions

GET /api/v1/evidence/{id}
  Get analysis result
  
POST /api/v1/evidence/{id}/retry
  Retry failed analysis
```

### Tech Assistance
```
POST /api/v1/assistant/query
  Ask workflow-aware assistant a question
  Request: job_id, step_id, question
  Response: answer, suggested_actions, references

GET /api/v1/assistant/history
  Get conversation history
```

### Voice Commands
```
POST /api/v1/voice/transcribe
  Transcribe audio to text
  Request: audio file, locale
  Response: transcript, confidence

POST /api/v1/voice/process
  Process voice command (intent extraction)
  Request: transcript, context
  Response: intent, entities, action, confidence
```

### Live Voice (WebSocket)
```
WS /ws/assistant/live
  Real-time voice conversation
  Streaming audio input → streaming text responses
  Full duplex with interruption support
```

### Reviews & Overrides
```
GET /api/v1/reviews
  List AI analysis for review

POST /api/v1/reviews/{id}/override
  Override AI decision with reason

POST /api/v1/reviews/{id}/retry
  Retry AI analysis
```

---

## REQUIRED CHANGES: Frontend

### 1. Update API Endpoints

The frontend currently calls Node backend directly. For AI features, it should call Django AI platform:

**Before (Evidence Upload)**
```javascript
// Old - direct to Node backend
POST /api/jobs/{id}/evidence
```

**After (With AI Analysis)**
```javascript
// 1. Upload evidence to Node backend (unchanged)
POST /api/jobs/{id}/evidence → { evidence_id }

// 2. Trigger AI analysis via Django
POST /api/v1/evidence/analyze
  {
    job_id, step_id, evidence_id,
    image_file,  evidence_type, playbook_id
  }

// 3. Poll for results
GET /api/v1/evidence/{analysis_id}
```

### 2. WebSocket for Live Voice

Add WebSocket client for real-time voice:

```javascript
const ws = new WebSocket('ws://api.coskip.ai/ws/assistant/live');
ws.onopen = () => {
  // Start streaming audio
  navigator.mediaDevices.getUserMedia({audio: true})
    .then(stream => {
      const recorder = new MediaRecorder(stream);
      recorder.ondataavailable = (event) => {
        ws.send(event.data);  // Send audio chunks
      };
      recorder.start(100);  // Send every 100ms
    });
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  if (data.type === 'transcript') {
    updateUI(data.text, data.interim);
  }
  if (data.type === 'response') {
    playAudio(data.audio);  // TTS response
  }
};
```

### 3. Add Authorization Headers

All requests to Django must include tenant/auth headers:

```javascript
const headers = {
  'Authorization': `Bearer ${jwt_token}`,  // or X-API-Key
  'X-Tenant-ID': tenant_id,
  'X-Correlation-ID': generateCorrelationId(),
  'Content-Type': 'application/json',
};
```

---

## REQUIRED CHANGES: Node Backend

### 1. Add Callback Webhook for AI Events

Django will notify Node backend of AI decisions that affect workflow:

```javascript
// In Node backend, add endpoint to receive AI webhooks

POST /api/webhooks/ai/evidence-decision
  {
    evidence_id, analysis_id,
    decision: 'pass|fail|needs_action',
    confidence, issues, required_actions
  }

POST /api/webhooks/ai/assistant-action
  {
    assist_id, job_id, step_id,
    action: 'complete_step|request_approval|report_issue',
    metadata: { ... }
  }

POST /api/webhooks/ai/voice-command
  {
    voice_command_id,
    intent, entities, action,
    confirmation_required: boolean
  }
```

### 2. Implement Webhook Integration

```javascript
// config/webhooks.js
const webhookConfig = {
  aiEvidenceDecision: 'https://api.coskip.ai/webhooks/ai/evidence-decision',
  aiAssistantAction: 'https://api.coskip.ai/webhooks/ai/assistant-action',
  aiVoiceCommand: 'https://api.coskip.ai/webhooks/ai/voice-command',
};

async function handleAIWebhook(event, payload) {
  switch(event) {
    case 'evidence-decision':
      await updateEvidenceWithAnalysis(payload);
      await checkIfStepComplete(payload.job_id, payload.step_id);
      break;
    case 'assistant-action':
      await executeAssistantRecommendation(payload);
      break;
    case 'voice-command':
      await processVoiceCommandExecution(payload);
      break;
  }
}
```

### 3. Add API Key for Django

Django needs an API key to call Node backend securely:

```javascript
// In Node admin, create API key
POST /admin/api-keys
  {
    name: 'django-ai-platform',
    service: 'coskip-ai-django',
    permissions: ['read:jobs', 'read:steps', 'write:evidence', 'write:issues']
  }

// Provide to Django env: COSKIP_BACKEND_API_KEY=<key>
```

---

## Django Apps Overview

### apps/ai_core/
**Shared infrastructure**
- Models: APIKey, HealthCheck, BaseModel
- Services: VertexClientManager, CoskipBackendClient, PromptBuilder
- Middleware: CorrelationId, Tenant, RateLimit
- Authentication: BearerToken, APIKey, ServiceToService

### apps/evidence_ai/
**Evidence analysis for compliance**
- Models: AIAnalysis, AIRequirementCheck, AIOverlay
- Services: Gemini Vision integration
- Tasks: async_analyze_evidence, retry_failed_analysis
- Endpoints: POST /analyze, GET /status, POST /retry

### apps/tech_assist/
**Workflow-aware technician assistant**
- Models: AssistantRequest, Conversation
- Services: Context loading from Node backend + Gemini
- Endpoints: POST /query, GET /history

### apps/voice_ai/
**Voice command processing**
- Models: VoiceCommand, VoiceExecution
- Services: Vertex STT + Gemini intent classification
- Endpoints: POST /transcribe, POST /process

### apps/voice_gateway/
**Real-time WebSocket voice conversations**
- Consumers: AudioStreamConsumer
- Services: RealtimeTranscriber, GeminiLiveSession
- WebSocket: /ws/assistant/live

### apps/decision_engine/
**Decision logic and confidence policies**
- Models: DecisionPolicy, DecisionResult
- Services: Confidence evaluation, pass/fail logic
- Used by all AI modules

### apps/review_center/
**Review and override AI decisions**
- Models: AIReview, AIOverride
- Services: Audit trail for overrides
- Endpoints: GET /reviews, POST /override

### apps/audit_ai/
**Audit trail for all AI operations**
- Models: AIAuditEvent
- Services: Event logging
- Endpoints: GET /events

---

## Database Models Summary

Each app extends the base multi-tenant models with:
- `tenant_id` for isolation
- `correlation_id` for tracing
- `created_at`, `updated_at` for auditing
- Proper indexes for performance

---

## Celery Tasks

Async processing for long-running operations:

```python
# apps/evidence_ai/tasks.py
@shared_task
def async_analyze_evidence(analysis_id, image_path, requirements):
    # Analyze with Gemini Vision
    # Update AI Analysis record
    # Create alerts if needed
    pass

# apps/tech_assist/tasks.py
@shared_task
def generate_assistant_response(assist_id, context):
    # Load job/step/playbook context
    # Query Gemini 2.5 Pro
    # Save response
    pass

# apps/voice_gateway/tasks.py
@shared_task
def cleanup_expired_sessions():
    # Clean up WebSocket sessions
    pass
```

---

## Monitoring & Health

### Health Check Endpoints
```
GET /health/ → {status: 'healthy'}
GET /ready/ → {status: 'ready', database: 'connected'}
```

### Logging
All requests logged with correlation_id to:
- Console (development)
- JSON files + Sentry (production)

### Metrics
- Response times
- Rate limits
- Error rates
- Model latency (Vertex AI)
- Queue depth (Celery)

---

## Security Checklist

- [ ] Set SECRET_KEY to strong random value
- [ ] Set DEBUG=False in production
- [ ] Configure SSL/TLS (SECURE_SSL_REDIRECT=True)
- [ ] Set ALLOWED_HOSTS to exact domains
- [ ] Rotate API keys regularly
- [ ] Enable multi-factor auth for admin
- [ ] Use strong database passwords
- [ ] Enable query parameter validation
- [ ] Rate limit all endpoints
- [ ] Log all AI decisions for audit

---

## Performance Tuning

### Database
```sql
-- Add indexes for common queries
CREATE INDEX idx_analysis_tenant_status ON evidence_ai_aianalysis(tenant_id, status);
CREATE INDEX idx_audit_entity ON audit_ai_aiauditevent(entity_type, entity_id);
```

### Caching
- Job/Step context: 5 min cache
- Playbook definitions: 1 hour cache
- API responses: Redis layer

### Async Processing
- Evidence analysis: Celery background job
- Long conversations: WebSocket instead of polling

---

## Troubleshooting

### Vertex AI connection fails
```
VERTEX_AI_ENABLED=False → Falls back to heuristics
Check: gcloud auth application-default login
```

### Rate limiting too strict
```
Adjust in .env:
RATE_LIMIT_EVIDENCE_ANALYSIS=100/60
```

### WebSocket connection drops
```
Check: CHANNEL_LAYERS Redis connection
Verify: ASGI application running (not WSGI)
```

---

## Support & Documentation

- Django settings: `config/settings.py`
- API docs: Postman collection included
- Admin interface: `/admin/`
- Architecture diagram: See top of this document

---

## Next Steps

1. **Week 1**: Deploy PostgreSQL + Redis infrastructure
2. **Week 2**: Deploy Django platform, run migrations
3. **Week 3**: Integrate Frontend with new API endpoints
4. **Week 4**: Test end-to-end workflow with Vertex AI
5. **Week 5**: Load testing and performance tuning
6. **Week 6**: Production deployment

---

**Version**: 1.0  
**Last Updated**: June 2026  
**Maintained By**: CoSkip AI Platform Team
