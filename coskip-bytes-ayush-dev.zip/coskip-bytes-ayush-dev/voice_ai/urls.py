"""URLs for voice-ai."""
from django.urls import path
from . import views

app_name = 'voice-ai'

urlpatterns = [
    path('process', views.ProcessVoiceView.as_view(), name='process'),
    path('tts', views.VoiceTTSView.as_view(), name='tts'),
]
