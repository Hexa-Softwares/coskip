"""Serializers for voice-ai."""
from rest_framework import serializers

# Serializers will be added here
