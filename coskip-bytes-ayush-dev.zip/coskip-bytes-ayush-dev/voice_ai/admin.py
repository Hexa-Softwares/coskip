"""Admin configuration for voice-ai."""
from django.contrib import admin

# Admin configurations will be added here
