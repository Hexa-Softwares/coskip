"""Views for voice-ai."""
from rest_framework import views, status
from rest_framework.response import Response
from .services import VoiceCommandService, VoiceTTSService



class ProcessVoiceView(views.APIView):
    """
    Endpoint for processing voice commands from transcripts.
    """
    def post(self, request, *args, **kwargs):
        transcript = request.data.get('transcript', '').lower()
        job_id = request.data.get('job_id', '')
        step_id = request.data.get('step_id', '')
        
        # Simple simulated intent extraction based on keyword
        intent = "unknown"
        action = "none"
        
        if "next" in transcript or "step" in transcript:
            intent = "next_step"
            action = "advance_workflow"
        elif "photo" in transcript or "evidence" in transcript:
            intent = "take_photo"
            action = "open_camera"
        elif "submit" in transcript or "done" in transcript:
            intent = "submit_evidence"
            action = "submit_evidence"
            
        return Response({
            "intent": intent,
            "confidence": 0.92 if intent != "unknown" else 0.4,
            "action": action,
            "requires_confirmation": False,
            "original_transcript": transcript
        }, status=status.HTTP_200_OK)

class VoiceTTSView(views.APIView):
    """POST /api/v1/voice/tts"""
    authentication_classes = []
    permission_classes = []
    renderer_classes = []

    def post(self, request):
        text = str(request.data.get('text', '')).strip()
        language = str(request.data.get('language', 'en-US'))
        speed = float(request.data.get('speed', 1.0))

        if not text:
            return Response({'detail': 'text is required'}, status=400)

        try:
            service = VoiceTTSService()
            audio_bytes = service.generate_tts(text, language, speed)
            from django.http import FileResponse
            response = FileResponse(audio_bytes, content_type='audio/mpeg')
            response['Content-Disposition'] = 'attachment; filename="response.mp3"'
            return response
        except Exception as e:
            return Response({'detail': f'TTS failed: {str(e)}'}, status=500)
