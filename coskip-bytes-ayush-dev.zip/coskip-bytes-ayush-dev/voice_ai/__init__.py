"""
voice-ai App
"""
default_app_config = 'voice_ai.apps.VoiceAiConfig'
