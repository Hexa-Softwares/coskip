"""Voice command processing and TTS service."""
import json
import logging
import io
from django.conf import settings
from ai_core.services.vertex_client import get_gemini_flash

logger = logging.getLogger(__name__)

INTENT_MAP = {
    'submit': ('submit_evidence', False),
    'upload': ('submit_evidence', False),
    'photo': ('take_photo', False),
    'next': ('next_step', True),
    'complete': ('complete_step', True),
    'note': ('add_note', False),
    'issue': ('flag_issue', False),
    'help': ('get_help', False),
    'cancel': ('cancel_action', False),
}


class VoiceCommandService:
    def process(self, transcript: str, job_id: str, step_id: str = '') -> dict:
        try:
            if settings.VERTEX_AI_ENABLED:
                return self._classify_with_gemini(transcript, job_id, step_id)
            return self._classify_local(transcript)
        except Exception as e:
            logger.error(f"Voice processing failed: {e}")
            return self._classify_local(transcript)

    def _classify_with_gemini(self, transcript, job_id, step_id):
        model = get_gemini_flash()
        prompt = f"""Classify this voice command from a field technician:
Transcript: "{transcript}"
Job: {job_id}, Step: {step_id}

Available intents: submit_evidence, take_photo, next_step, complete_step, add_note, flag_issue, get_help, cancel_action, unknown

Respond ONLY with JSON: {{"intent": str, "confidence": float, "action": str, "requires_confirmation": bool, "response_text": str}}"""
        resp = model.generate_content(prompt)
        text = resp.text.strip()
        if text.startswith('```'):
            text = text.split('\n', 1)[-1].rsplit('```', 1)[0].strip()
        return json.loads(text)

    def _classify_local(self, transcript):
        t = transcript.lower()
        for keyword, (action, confirm) in INTENT_MAP.items():
            if keyword in t:
                return {
                    'intent': action,
                    'confidence': 0.80,
                    'action': action,
                    'requires_confirmation': confirm,
                    'response_text': f"Got it, I'll {action.replace('_', ' ')}.",
                }
        return {
            'intent': 'unknown',
            'confidence': 0.40,
            'action': 'get_help',
            'requires_confirmation': False,
            'response_text': "I didn't catch that. Try saying 'submit photo' or 'next step'.",
        }


class VoiceTTSService:
    """Generate speech from text using Google Cloud Text-to-Speech"""
    
    def generate_tts(self, text: str, language: str = 'en-US', speed: float = 1.0) -> io.BytesIO:
        """
        Generate audio from text.
        Returns: BytesIO object containing MP3 audio
        """
        try:
            if settings.VERTEX_AI_ENABLED:
                return self._generate_with_google_tts(text, language, speed)
            else:
                # Fallback: return mock audio or error
                return self._generate_mock_audio(text)
        except Exception as e:
            logger.error(f"TTS generation failed: {e}")
            raise

    def _generate_with_google_tts(self, text: str, language: str, speed: float):
        """Use Google Cloud Text-to-Speech API"""
        try:
            # pyrefly: ignore [missing-import]
            from google.cloud import texttospeech
            
            client = texttospeech.TextToSpeechClient()
            
            synthesis_input = texttospeech.SynthesisInput(text=text)
            
            voice = texttospeech.VoiceSelectionParams(
                language_code=language,
                ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL,
            )
            
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.MP3,
                speaking_rate=speed,
            )
            
            response = client.synthesize_speech(
                input=synthesis_input,
                voice=voice,
                audio_config=audio_config,
            )
            
            # Return BytesIO object
            audio_io = io.BytesIO(response.audio_content)
            audio_io.seek(0)
            return audio_io
        except Exception as e:
            logger.error(f"Google TTS failed: {e}")
            raise

    def _generate_mock_audio(self, text: str):
        """Return mock silent MP3 for testing"""
        # This is a minimal valid MP3 header (ID3v2)
        mock_mp3 = b'ID3\x04\x00\x00\x00\x00\x00\x00'
        return io.BytesIO(mock_mp3)