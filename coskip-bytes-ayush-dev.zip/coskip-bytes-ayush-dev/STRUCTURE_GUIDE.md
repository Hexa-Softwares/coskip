# CoSkip Bytes - Restructured Project Guide

## 📁 Project Structure

```
coskip-bytes/
│
├── config/                          # Django configuration
│   ├── __init__.py
│   ├── settings.py                 # Main settings (INSTALLED_APPS updated)
│   ├── urls.py                     # URL routing (updated imports)
│   ├── asgi.py                     # WebSocket (updated imports)
│   ├── wsgi.py                     # Production server
│   ├── celery.py                   # Celery configuration
│   ├── static/                     # Static files
│   ├── templates/                  # HTML templates
│   └── logs/                       # Log files
│
├── ai-core/                        # Shared Infrastructure
│   ├── models.py                  # BaseModel, APIKey, HealthCheck
│   ├── authentication.py          # JWT, API Key auth
│   ├── middleware.py              # Correlation ID, Tenant, Rate Limit
│   ├── exceptions.py              # Exception handler
│   ├── apps.py                    # App configuration
│   ├── admin.py
│   ├── views.py
│   ├── urls.py
│   ├── serializers.py
│   ├── migrations/
│   └── services/
│       ├── vertex_client.py       # Gemini/Speech clients
│       └── backend_client.py      # Node backend integration
│
├── evidence-ai/                    # Evidence Analysis
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── urls.py
│   ├── apps.py
│   ├── admin.py
│   ├── tests.py
│   ├── migrations/
│   └── services/
│       └── analysis_service.py
│
├── tech-assist/                    # Tech Assistance
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── urls.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── voice-ai/                       # Voice Commands
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── urls.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── voice_gateway/                  # Real-time Voice WebSocket
│   ├── consumers.py               # WebSocket consumers
│   ├── models.py
│   ├── urls.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── decision-engine/               # Decision Logic
│   ├── models.py
│   ├── views.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── review-centre/                 # Review & Override
│   ├── models.py
│   ├── views.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── audit-ai/                      # Audit Trail
│   ├── models.py
│   ├── views.py
│   ├── apps.py
│   ├── migrations/
│   └── services/
│
├── manage.py                      # Django CLI
├── docker.yaml                    # Docker Compose (renamed from docker-compose.yml)
├── Dockerfile                     # Container image
├── requirements.txt               # Python dependencies
├── .env.example                   # Environment template
├── README.md                      # Quick start
├── STRUCTURE_GUIDE.md            # This file
└── Documentation/
    ├── DEPLOYMENT_GUIDE.md
    ├── TEAM_INTEGRATION_REPORT.md
    ├── INDEX_AND_GUIDE.md
    └── ... (other docs)
```

---

## 🔄 Updated Import Paths

### Before (Original Structure with apps/ prefix)
```python
# apps/ai_core/models.py
from apps.ai_core.models import TenantAwareModel

# config/settings.py
INSTALLED_APPS = [
    'apps.ai_core',
    'apps.evidence_ai',
    ...
]

# config/urls.py
path('api/v1/evidence/', include('apps.evidence_ai.urls'))
```

### After (Restructured - No apps/ prefix)
```python
# ai-core/models.py
from ai_core.models import TenantAwareModel

# config/settings.py
INSTALLED_APPS = [
    'ai_core',
    'evidence_ai',
    'tech_assist',
    'voice_ai',
    'voice_gateway',
    'decision_engine',
    'review_centre',
    'audit_ai',
]

# config/urls.py
path('api/v1/evidence/', include('evidence_ai.urls'))
path('api/v1/assistant/', include('tech_assist.urls'))
path('api/v1/voice/', include('voice_ai.urls'))
path('api/v1/reviews/', include('review_centre.urls'))
path('api/v1/audits/', include('audit_ai.urls'))
path('api/v1/decisions/', include('decision_engine.urls'))
path('api/v1/core/', include('ai_core.urls'))
```

---

## 🚀 Quick Start

### 1. Setup Environment
```bash
cp .env.example .env
nano .env  # Edit with your values
```

### 2. Run with Docker
```bash
docker-compose -f docker.yaml up -d
# or simply
docker-compose up -d  # if docker.yaml is recognized
```

### 3. Run Migrations
```bash
docker-compose exec django python manage.py migrate
```

### 4. Create Superuser
```bash
docker-compose exec django python manage.py createsuperuser
```

### 5. Access
- API: http://localhost:8000
- Admin: http://localhost:8000/admin/
- Health: http://localhost:8000/health/

---

## 📝 Python Module Names vs Folder Names

Important: Python imports use underscores, but folder names use hyphens for readability.

| Folder Name | Python Module Name | Import Statement |
|-------------|-------------------|------------------|
| ai-core | ai_core | from ai_core.models import |
| evidence-ai | evidence_ai | from evidence_ai.views import |
| tech-assist | tech_assist | from tech_assist.views import |
| voice-ai | voice_ai | from voice_ai.models import |
| voice_gateway | voice_gateway | from voice_gateway.consumers import |
| decision-engine | decision_engine | from decision_engine.models import |
| review-centre | review_centre | from review_centre.models import |
| audit-ai | audit_ai | from audit_ai.models import |

---

## 🔌 API Endpoints (Updated Routes)

```
POST   /api/v1/evidence/analyze          # Analyze field evidence
GET    /api/v1/evidence/{id}              # Get analysis result
POST   /api/v1/evidence/{id}/retry        # Retry analysis

POST   /api/v1/assistant/query            # Ask assistant
GET    /api/v1/assistant/history          # Chat history

POST   /api/v1/voice/transcribe           # Transcribe audio
POST   /api/v1/voice/process              # Process intent

WS     /ws/assistant/live                 # Real-time voice

GET    /api/v1/reviews                    # List pending reviews
POST   /api/v1/reviews/{id}/override      # Override decision

GET    /api/v1/audits                     # Audit events

GET    /api/v1/decisions                  # Decision engine

GET    /health/                           # Health check
GET    /ready/                            # Readiness check
```

---

## 🐳 Docker Commands

```bash
# Start all services
docker-compose -f docker.yaml up -d

# Or if Docker recognizes docker.yaml as default
docker-compose up -d

# View logs
docker-compose -f docker.yaml logs -f django

# Stop all services
docker-compose -f docker.yaml down

# Run Django commands
docker-compose exec django python manage.py shell

# Run migrations
docker-compose exec django python manage.py migrate

# Create superuser
docker-compose exec django python manage.py createsuperuser
```

---

## 📦 INSTALLED_APPS Order (Important!)

In `config/settings.py`, the order matters:

```python
INSTALLED_APPS = [
    # Django core
    'daphne',  # Must be before channels
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party
    'rest_framework',
    'corsheaders',
    'channels',
    'django_celery_beat',
    'django_celery_results',
    
    # CoSkip apps (must be last, in any order)
    'ai_core',           # Should be first as other apps depend on it
    'evidence_ai',
    'tech_assist',
    'voice_ai',
    'voice_gateway',
    'decision_engine',
    'review_centre',
    'audit_ai',
]
```

---

## 🧪 Testing

```bash
# Run all tests
python manage.py test

# Run tests for specific app
python manage.py test ai_core
python manage.py test evidence_ai

# Run with coverage
coverage run --source='.' manage.py test
coverage report
```

---

## 🔐 Security Notes

1. **Never commit `.env`** - Use environment variables
2. **Generate new SECRET_KEY** for production
3. **Use strong passwords** for database and Redis
4. **Update ALLOWED_HOSTS** with actual domains
5. **Configure SSL/TLS** in production
6. **Rotate API keys** regularly

---

## 📚 Documentation Files

- **README.md** - Quick start (5 min)
- **DEPLOYMENT_GUIDE.md** - Complete setup (40+ pages)
- **TEAM_INTEGRATION_REPORT.md** - Team checklists
- **INDEX_AND_GUIDE.md** - Navigation guide
- **STRUCTURE_GUIDE.md** - This file

---

## 🎯 Next Steps

1. Read README.md for quick start
2. Copy .env.example to .env
3. Run `docker-compose -f docker.yaml up -d`
4. Access http://localhost:8000
5. Read DEPLOYMENT_GUIDE.md for production setup

---

**Restructured CoSkip Bytes - Production Ready** ✅
