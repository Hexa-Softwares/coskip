"""
Production Django settings for CoSkip AI Platform (Restructured).

Vertex AI orchestration layer for field operations.
"""

from pathlib import Path
from decouple import config, Csv
import logging
import os
# pyrefly: ignore [missing-import]
from dotenv import load_dotenv  

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


BASE_DIR = Path(__file__).resolve().parent.parent

from pathlib import Path
print("SETTINGS FILE:", __file__)
print("BASE_DIR:", BASE_DIR)


# ============================================================================
# SECURITY
# ============================================================================

SECRET_KEY = config('SECRET_KEY', default='django-insecure-change-in-production')
DEBUG = config('DEBUG', default=False, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1', cast=Csv())
IS_PRODUCTION = config('IS_PRODUCTION', default=False, cast=bool)

# ============================================================================
# INSTALLED APPS (Restructured - No apps/ prefix)
# ============================================================================

INSTALLED_APPS = [
    'daphne',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'channels',
    'django_celery_beat',
    'django_celery_results',
    
    # CoSkip AI modules (flattened structure)
    'ai_core',
    'evidence_ai',
    'tech_assist',
    'voice_ai',
    'voice_gateway',
    'decision_engine',
    'review_centre',
    'audit_ai',
]

# ============================================================================
# MIDDLEWARE
# ============================================================================

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    
    # CoSkip middleware (updated import paths)
    'ai_core.middleware.CorrelationIdMiddleware',
    'ai_core.middleware.TenantMiddleware',
    'ai_core.middleware.RateLimitMiddleware',
]

# ============================================================================
# URLS & TEMPLATES
# ============================================================================

ROOT_URLCONF = 'config.urls'
ASGI_APPLICATION = 'config.asgi.application'
WSGI_APPLICATION = 'config.wsgi.application'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'config/templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# ============================================================================
# DATABASE
# ============================================================================

DATABASE_URL = config('DATABASE_URL', default=None)
if DATABASE_URL:
    from urllib.parse import urlparse
    db_url = urlparse(DATABASE_URL)
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': db_url.path[1:],
            'USER': db_url.username,
            'PASSWORD': db_url.password,
            'HOST': db_url.hostname,
            'PORT': db_url.port or 5432,
            'CONN_MAX_AGE': 600,
            'ATOMIC_REQUESTS': False,
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ============================================================================
# PASSWORD VALIDATION
# ============================================================================

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ============================================================================
# INTERNATIONALIZATION
# ============================================================================

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# ============================================================================
# STATIC & MEDIA FILES
# ============================================================================

STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'config/staticfiles'
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'config/media'

# ============================================================================
# REST FRAMEWORK
# ============================================================================

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'ai_core.authentication.BearerTokenAuthentication',
        'ai_core.authentication.APIKeyAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PARSER_CLASSES': [
        'rest_framework.parsers.JSONParser',
        'rest_framework.parsers.MultiPartParser',
    ],
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.LimitOffsetPagination',
    'PAGE_SIZE': 100,
    'EXCEPTION_HANDLER': 'ai_core.exceptions.coskip_exception_handler',
}

# ============================================================================
# DJANGO CHANNELS
# ============================================================================

CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            'hosts': [(config('REDIS_HOST', default='localhost'), config('REDIS_PORT', default=6379, cast=int))],
        },
    },
}

# ============================================================================
# CORS
# ============================================================================

CORS_ALLOWED_ORIGINS = config(
    'CORS_ALLOWED_ORIGINS',
    default='http://localhost:7073,http://127.0.0.1:7073',
    cast=Csv(),
)
CORS_ALLOW_ALL_ORIGINS = config('CORS_ALLOW_ALL_ORIGINS', default=False, cast=bool)
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOW_HEADERS = [
    'accept',
    'authorization',
    'content-type',
    'x-api-key',
    'x-correlation-id',
    'x-tenant-id',
    'x-forwarded-for',
    'x-requested-with',
]

# ============================================================================
# FILE UPLOAD
# ============================================================================

FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024

# ============================================================================
# IMAGE ANALYSIS
# ============================================================================

IMAGE_MAX_SIZE_MB = 10
IMAGE_MIN_LONG_EDGE_PX = 1
IMAGE_PREFERRED_LONG_EDGE_MIN_PX = 2000
IMAGE_PREFERRED_LONG_EDGE_MAX_PX = 4000
IMAGE_ALLOWED_FORMATS = ['JPEG', 'PNG', 'HEIC']

# ============================================================================
# VERTEX AI & GEMINI
# ============================================================================

VERTEX_AI_ENABLED = config('VERTEX_AI_ENABLED', default=True, cast=bool)
VERTEX_AI_PROJECT = config('VERTEX_AI_PROJECT', default='woven-environs-479604-i6')
VERTEX_AI_LOCATION = config('VERTEX_AI_LOCATION', default='us-central1')
GOOGLE_APPLICATION_CREDENTIALS=config('GOOGLE_APPLICATION_CREDENTIALS')
print("GOOGLE_APPLICATION_CREDENTIALS from decouple =", GOOGLE_APPLICATION_CREDENTIALS)

GEMINI_PRO_MODEL = config('GEMINI_PRO_MODEL', default='gemini-2.5-pro')
GEMINI_FLASH_MODEL = config('GEMINI_FLASH_MODEL', default='gemini-2.5-flash')
GEMINI_VISION_MODEL = config('GEMINI_VISION_MODEL', default='gemini-2.5-flash-vision')

VERTEX_AI_TIMEOUT_SECONDS = config('VERTEX_AI_TIMEOUT_SECONDS', default=30, cast=int)
VERTEX_STT_TIMEOUT_SECONDS = config('VERTEX_STT_TIMEOUT_SECONDS', default=30, cast=int)
VERTEX_TTS_TIMEOUT_SECONDS = config('VERTEX_TTS_TIMEOUT_SECONDS', default=30, cast=int)
ASSIST_TIMEOUT_SECONDS = config('ASSIST_TIMEOUT_SECONDS', default=15, cast=int)
VOICE_TIMEOUT_SECONDS = config('VOICE_TIMEOUT_SECONDS', default=20, cast=int)

# ============================================================================
# CELERY
# ============================================================================

CELERY_BROKER_URL = config('CELERY_BROKER_URL', default='redis://localhost:6379/0')
CELERY_RESULT_BACKEND = config('CELERY_RESULT_BACKEND', default='redis://localhost:6379/0')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 30 * 60
CELERY_RESULT_EXPIRES = 3600

CELERY_BEAT_SCHEDULE = {
    'cleanup-expired-voice-sessions': {
        'task': 'voice_gateway.tasks.cleanup_expired_sessions',
        'schedule': 300.0,
    },
    'cleanup-failed-analyses': {
        'task': 'evidence_ai.tasks.cleanup_failed_analyses',
        'schedule': 3600.0,
    },
}

# ============================================================================
# REDIS
# ============================================================================

REDIS_HOST = config('REDIS_HOST', default='localhost')
REDIS_PORT = config('REDIS_PORT', default=6379, cast=int)
REDIS_DB = config('REDIS_DB', default=0, cast=int)

CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': f'redis://{REDIS_HOST}:{REDIS_PORT}/{REDIS_DB}',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'CONNECTION_POOL_KWARGS': {'max_connections': 50},
        }
    }
}

SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'default'

# ============================================================================
# RATE LIMITING
# ============================================================================

RATE_LIMIT_EVIDENCE_ANALYSIS = config('RATE_LIMIT_EVIDENCE_ANALYSIS', default='60/60')
RATE_LIMIT_VOICE = config('RATE_LIMIT_VOICE', default='120/60')
RATE_LIMIT_ASSIST = config('RATE_LIMIT_ASSIST', default='60/60')
RATE_LIMIT_LIVE_VOICE = config('RATE_LIMIT_LIVE_VOICE', default='20/60')

# ============================================================================
# SECURITY
# ============================================================================

if IS_PRODUCTION and not DEBUG:
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
    SECURE_SSL_REDIRECT = config('SECURE_SSL_REDIRECT', default=True, cast=bool)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    X_FRAME_OPTIONS = 'DENY'
    SECURE_HSTS_SECONDS = config('SECURE_HSTS_SECONDS', default=31536000, cast=int)
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
else:
    SECURE_SSL_REDIRECT = False
    SESSION_COOKIE_SECURE = False
    CSRF_COOKIE_SECURE = False

# ============================================================================
# NODE BACKEND INTEGRATION
# ============================================================================

COSKIP_BACKEND_BASE_URL = config('COSKIP_BACKEND_BASE_URL', default='http://localhost:3000')
COSKIP_BACKEND_API_KEY = config('COSKIP_BACKEND_API_KEY', default='')
COSKIP_BACKEND_TIMEOUT_SECONDS = config('COSKIP_BACKEND_TIMEOUT_SECONDS', default=10, cast=int)

# ============================================================================
# LOGGING
# ============================================================================

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'json': {
            '()': 'pythonjsonlogger.jsonlogger.JsonFormatter',
            'format': '%(asctime)s %(name)s %(levelname)s %(message)s',
        },
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'json' if IS_PRODUCTION else 'verbose',
        },
        'file': {
            'level': 'INFO',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': BASE_DIR / 'config/logs/coskip_ai.log',
            'maxBytes': 1024 * 1024 * 10,
            'backupCount': 5,
            'formatter': 'json',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'coskip': {
            'handlers': ['console', 'file'],
            'level': 'DEBUG' if DEBUG else 'INFO',
            'propagate': False,
        },
        'celery': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

os.makedirs(BASE_DIR / 'config/logs', exist_ok=True)

# ============================================================================
# MULTI-TENANCY
# ============================================================================

MULTI_TENANCY_ENABLED = config('MULTI_TENANCY_ENABLED', default=True, cast=bool)

# ============================================================================
# BOOTSTRAP API KEY
# ============================================================================

BOOTSTRAP_API_KEY = config('BOOTSTRAP_API_KEY', default='').strip()
