"""
URL routing for CoSkip AI Platform (Restructured).
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET'])
def health_check(request):
    """Health check endpoint for load balancers."""
    return Response({'status': 'healthy', 'service': 'coskip-ai-platform'})

@api_view(['GET'])
def readiness_check(request):
    """Readiness check endpoint."""
    from django.db import connection
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        return Response({'status': 'ready', 'database': 'connected'})
    except Exception as e:
        return Response({'status': 'not_ready', 'error': str(e)}, status=503)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('health/', health_check, name='health-check'),
    path('ready/', readiness_check, name='readiness-check'),
    
    # API versioning - Updated routes for new app names
    path('api/v1/evidence/', include('evidence_ai.urls', namespace='evidence-ai')),
    path('api/v1/assistant/', include('tech_assist.urls', namespace='tech-assist')),
    path('api/v1/voice/', include('voice_ai.urls', namespace='voice-ai')),
    path('api/v1/reviews/', include('review_centre.urls', namespace='review-centre')),
    path('api/v1/audits/', include('audit_ai.urls', namespace='audit-ai')),
    path('api/v1/decisions/', include('decision_engine.urls', namespace='decision-engine')),
    path('api/v1/core/', include('ai_core.urls', namespace='ai-core')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
