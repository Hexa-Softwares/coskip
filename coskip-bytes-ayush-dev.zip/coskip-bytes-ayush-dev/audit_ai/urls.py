"""URLs for audit-ai."""
from django.urls import path

app_name = 'audit-ai'

urlpatterns = []
