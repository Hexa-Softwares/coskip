"""
audit-ai App
"""
default_app_config = 'audit_ai.apps.AuditAiConfig'
