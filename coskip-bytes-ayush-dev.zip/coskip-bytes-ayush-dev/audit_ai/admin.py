"""Admin configuration for audit-ai."""
from django.contrib import admin

# Admin configurations will be added here
