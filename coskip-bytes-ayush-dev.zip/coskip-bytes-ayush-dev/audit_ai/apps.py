"""Django app configuration for audit-ai."""
from django.apps import AppConfig

class AuditAiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'audit_ai'
    verbose_name = 'Audit Ai'
