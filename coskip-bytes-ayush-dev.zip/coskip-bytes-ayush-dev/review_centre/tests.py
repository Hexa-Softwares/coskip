"""Tests for review-centre."""
from django.test import TestCase

# Tests will be added here
