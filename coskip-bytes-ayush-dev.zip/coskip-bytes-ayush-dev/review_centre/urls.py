"""URLs for review-centre."""
from django.urls import path

app_name = 'review-centre'

urlpatterns = []
