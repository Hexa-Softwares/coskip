"""
review-centre App
"""
default_app_config = 'review_centre.apps.ReviewCentreConfig'
