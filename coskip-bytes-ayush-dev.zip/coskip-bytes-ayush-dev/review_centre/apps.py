"""Django app configuration for review-centre."""
from django.apps import AppConfig

class ReviewCentreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'review_centre'
    verbose_name = 'Review Centre'
