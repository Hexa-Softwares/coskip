"""Views for review-centre."""
from rest_framework import viewsets

# Views will be added here
