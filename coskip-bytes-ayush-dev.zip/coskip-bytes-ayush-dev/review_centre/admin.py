"""Admin configuration for review-centre."""
from django.contrib import admin

# Admin configurations will be added here
