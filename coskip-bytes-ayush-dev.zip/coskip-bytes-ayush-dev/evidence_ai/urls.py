"""URLs for evidence-ai."""
from django.urls import path
from . import views

app_name = 'evidence-ai'

urlpatterns = [
    path('analyze', views.AnalyzeEvidenceView.as_view(), name='analyze'),
]
