"""
evidence-ai App
"""
default_app_config = 'evidence_ai.apps.EvidenceAiConfig'
