"""Admin configuration for evidence-ai."""
from django.contrib import admin

# Admin configurations will be added here
