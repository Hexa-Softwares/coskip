"""Tests for evidence-ai."""
from django.test import TestCase

# Tests will be added here
