"""Django app configuration for evidence-ai."""
from django.apps import AppConfig

class EvidenceAiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'evidence_ai'
    verbose_name = 'Evidence Ai'
