"""
Lightweight models for persisting voice session metadata and logs.
Not required for the WebSocket pipeline to work — useful for debugging
and for the FE to pre-create session IDs via the REST endpoint.
"""
import uuid

from django.db import models


def _generate_session_id() -> str:
    return f"vsn_{uuid.uuid4().hex[:16]}"


class VoiceSession(models.Model):
    """
    Represents a voice interaction session.
    Created by the FE via POST /api/v1/voice/sessions/ before opening a WebSocket.
    """
    session_id = models.CharField(
        max_length=32,
        unique=True,
        default=_generate_session_id,
        db_index=True,
    )
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    user_id = models.CharField(max_length=128, null=True, blank=True)
    language_code = models.CharField(max_length=16, default="en-US")
    voice_profile = models.CharField(max_length=32, default="default")

    # Store last snapshot of conversation history (JSON array)
    history_snapshot = models.JSONField(default=list, blank=True)

    # Metrics
    total_turns = models.PositiveIntegerField(default=0)
    total_images = models.PositiveIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Voice Session"
        verbose_name_plural = "Voice Sessions"
        ordering = ["-created_at"]

    def __str__(self) -> str:  # pragma: no cover
        return f"VoiceSession({self.session_id})"


class VoiceTurnLog(models.Model):
    """Log of individual voice exchange turns for debugging / audit."""

    class TurnType(models.TextChoices):
        VOICE = "voice", "Voice"
        IMAGE = "image", "Image"
        TEXT = "text", "Text"

    session = models.ForeignKey(
        VoiceSession,
        on_delete=models.CASCADE,
        related_name="turns",
        null=True,
        blank=True,
    )
    turn_type = models.CharField(max_length=16, choices=TurnType.choices, default=TurnType.VOICE)

    # STT output
    transcript = models.TextField(blank=True)
    transcript_confidence = models.FloatField(null=True, blank=True)
    stt_engine = models.CharField(max_length=32, blank=True)

    # AI output
    ai_response = models.TextField(blank=True)

    # Flags
    tts_generated = models.BooleanField(default=False)
    had_image = models.BooleanField(default=False)
    error_code = models.CharField(max_length=64, blank=True)

    processing_ms = models.PositiveIntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Voice Turn Log"
        verbose_name_plural = "Voice Turn Logs"
        ordering = ["-created_at"]

    def __str__(self) -> str:  # pragma: no cover
        return f"VoiceTurnLog({self.session_id or 'anon'} {self.turn_type})"
