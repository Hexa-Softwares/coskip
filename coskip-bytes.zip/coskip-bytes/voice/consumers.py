"""
VoiceConsumer — Django Channels WebSocket consumer.

WebSocket URL: ws(s)://<host>/ws/voice/<session_id>/

──────────────────────────────────────────────────
CLIENT → SERVER messages (JSON)
──────────────────────────────────────────────────
  { "type": "audio_chunk",
    "data":      "<base64-encoded audio>",
    "mime_type": "audio/webm;codecs=opus" }       ← called once or many times

  { "type": "end_stream" }                        ← signals end of recording

  { "type": "image",
    "data":      "<base64-encoded image>",
    "mime_type": "image/jpeg",
    "prompt":    "optional text question" }        ← analyse image (+ optional voice prompt)

  { "type": "text_message",
    "content": "raw text question" }              ← text-only query (no audio)

  { "type": "reset" }                             ← clear conversation history
  { "type": "ping" }                              ← keepalive

──────────────────────────────────────────────────
SERVER → CLIENT messages (JSON)
──────────────────────────────────────────────────
  { "type": "connected",  "session_id": "...",
    "capabilities": {"stt":bool, "tts":bool, "image_analysis":bool} }

  { "type": "processing", "stage": "stt"|"ai"|"tts" }

  { "type": "transcription", "text": "...", "confidence": 0.95, "engine": "cloud_speech"|"gemini" }

  { "type": "ai_response", "text": "...", "source": "voice"|"image_analysis"|"text" }

  { "type": "audio_response", "data": "<base64 MP3>", "mime_type": "audio/mp3" }

  { "type": "error", "code": "SNAKE_CASE_CODE", "message": "human readable" }

  { "type": "reset_confirmed" }
  { "type": "pong" }
──────────────────────────────────────────────────
"""
import asyncio
import base64
import json
import logging
import uuid
from io import BytesIO

from channels.generic.websocket import AsyncWebsocketConsumer
from django.conf import settings

from .services import get_ai_response, synthesize_speech, transcribe_audio

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────
MAX_AUDIO_BYTES: int = 4 * 1024 * 1024    # 4 MB — same limit as existing voice endpoint
MAX_IMAGE_BYTES: int = 10 * 1024 * 1024   # 10 MB
MAX_HISTORY_PAIRS: int = 20               # kept turns in memory (user + model per pair)


class VoiceConsumer(AsyncWebsocketConsumer):
    """
    Async WebSocket consumer that drives the full STT → AI → TTS pipeline.

    One consumer instance = one technician WebRTC session.
    State is kept in instance variables — no shared state between connections.
    """

    # ── Connection lifecycle ──────────────────────────────────────────────────

    async def connect(self) -> None:
        self.session_id: str = (
            self.scope["url_route"]["kwargs"].get("session_id")
            or str(uuid.uuid4())
        )

        # In-memory audio accumulation buffer (reset after each end_stream)
        self._audio_buffer = BytesIO()
        self._audio_mime: str = "audio/webm;codecs=opus"

        # Conversation history: [{"role": "user"|"model", "content": str}, …]
        self._history: list[dict] = []

        # Guard flag to prevent concurrent pipeline runs
        self._is_processing: bool = False

        await self.accept()
        logger.info("[VoiceConsumer] Connected: session=%s", self.session_id)

        await self._send_json({
            "type": "connected",
            "session_id": self.session_id,
            "message": "Voice assistant ready.",
            "capabilities": {
                "stt": True,
                "tts": True,
                "image_analysis": bool(getattr(settings, "VERTEX_AI_ENABLED", False)),
            },
        })

    async def disconnect(self, close_code: int) -> None:
        logger.info("[VoiceConsumer] Disconnected: session=%s code=%s", self.session_id, close_code)
        try:
            self._audio_buffer.close()
        except Exception:
            pass

    # ── Incoming message dispatcher ───────────────────────────────────────────

    async def receive(self, text_data: str | None = None, bytes_data: bytes | None = None) -> None:
        """Route incoming frames to the appropriate handler."""

        if bytes_data:
            # Raw binary frame — treat as raw audio chunk (no base64 overhead)
            await self._append_audio(bytes_data)
            return

        if not text_data:
            return

        try:
            msg = json.loads(text_data)
        except json.JSONDecodeError:
            await self._send_error("INVALID_JSON", "Message is not valid JSON.")
            return

        msg_type: str = msg.get("type", "")

        dispatch = {
            "audio_chunk":   self._handle_audio_chunk,
            "end_stream":    self._handle_end_stream,
            "image":         self._handle_image,
            "text_message":  self._handle_text_message,
            "reset":         self._handle_reset,
            "ping":          self._handle_ping,
        }

        handler = dispatch.get(msg_type)
        if handler:
            await handler(msg)
        else:
            await self._send_error("UNKNOWN_TYPE", f"Unknown message type: {msg_type!r}")

    # ── Audio accumulation ────────────────────────────────────────────────────

    async def _handle_audio_chunk(self, msg: dict) -> None:
        """Decode and buffer a base64-encoded audio chunk."""
        encoded: str = msg.get("data", "")
        if not encoded:
            return

        try:
            chunk = base64.b64decode(encoded)
        except Exception:
            await self._send_error("DECODE_ERROR", "Could not decode audio chunk (bad base64).")
            return

        self._audio_mime = msg.get("mime_type", self._audio_mime) or self._audio_mime
        await self._append_audio(chunk)

    async def _append_audio(self, chunk: bytes) -> None:
        """Append raw bytes to the audio buffer, enforcing the size cap."""
        current = self._audio_buffer.tell()
        if current + len(chunk) > MAX_AUDIO_BYTES:
            await self._send_error(
                "AUDIO_TOO_LARGE",
                f"Audio buffer exceeded {MAX_AUDIO_BYTES // (1024 * 1024)} MB limit.",
            )
            return
        self._audio_buffer.write(chunk)

    # ── End of audio stream: full STT → AI → TTS pipeline ────────────────────

    async def _handle_end_stream(self, _msg: dict | None = None) -> None:
        """Run the full pipeline once the client signals the recording is complete."""
        if self._is_processing:
            await self._send_error("BUSY", "A request is already being processed.")
            return

        audio_bytes = self._audio_buffer.getvalue()
        # Reset buffer immediately so the user can start speaking again during processing
        self._audio_buffer = BytesIO()

        if not audio_bytes:
            await self._send_error("EMPTY_AUDIO", "No audio data received.")
            return

        self._is_processing = True
        loop = asyncio.get_event_loop()

        try:
            # ── Stage 1: Speech-to-Text ───────────────────────────────────────
            await self._send_json({"type": "processing", "stage": "stt"})

            mime = self._audio_mime
            stt_result: dict = await loop.run_in_executor(
                None, lambda: transcribe_audio(audio_bytes, mime)
            )

            transcript: str = stt_result.get("transcript", "")
            confidence: float = stt_result.get("confidence", 0.0)
            engine: str = stt_result.get("engine", "unknown")

            await self._send_json({
                "type": "transcription",
                "text": transcript,
                "confidence": confidence,
                "engine": engine,
            })

            if not transcript:
                await self._send_error(
                    "TRANSCRIPTION_EMPTY",
                    "Could not understand the audio. Please speak clearly and try again.",
                )
                return

            # ── Stage 2: AI Response ──────────────────────────────────────────
            await self._send_json({"type": "processing", "stage": "ai"})

            history_snapshot = list(self._history)  # snapshot for thread safety
            ai_text: str = await loop.run_in_executor(
                None,
                lambda: get_ai_response(
                    transcript=transcript,
                    conversation_history=history_snapshot,
                ),
            )

            # Persist turn
            self._history.append({"role": "user",  "content": transcript})
            self._history.append({"role": "model", "content": ai_text})
            self._trim_history()

            await self._send_json({"type": "ai_response", "text": ai_text, "source": "voice"})

            # ── Stage 3: Text-to-Speech ───────────────────────────────────────
            await self._send_json({"type": "processing", "stage": "tts"})

            audio_out: bytes | None = await loop.run_in_executor(
                None, lambda: synthesize_speech(ai_text)
            )

            if audio_out:
                await self._send_json({
                    "type": "audio_response",
                    "data": base64.b64encode(audio_out).decode("utf-8"),
                    "mime_type": "audio/mp3",
                })
            else:
                logger.warning(
                    "[VoiceConsumer] TTS failed; text-only response for session=%s", self.session_id
                )

        finally:
            self._is_processing = False

    # ── Image analysis ────────────────────────────────────────────────────────

    async def _handle_image(self, msg: dict) -> None:
        """
        Analyse an image via Vertex AI Gemini, with an optional voice prompt.
        Sends back text + TTS audio.
        """
        if self._is_processing:
            await self._send_error("BUSY", "A request is already being processed.")
            return

        encoded: str = msg.get("data", "")
        mime_type: str = msg.get("mime_type", "image/jpeg")
        prompt: str = (msg.get("prompt") or "").strip()

        if not encoded:
            await self._send_error("INVALID_IMAGE", "No image data provided.")
            return

        try:
            image_bytes = base64.b64decode(encoded)
        except Exception:
            await self._send_error("DECODE_ERROR", "Could not decode image (bad base64).")
            return

        if len(image_bytes) > MAX_IMAGE_BYTES:
            await self._send_error(
                "IMAGE_TOO_LARGE",
                f"Image exceeds {MAX_IMAGE_BYTES // (1024 * 1024)} MB limit.",
            )
            return

        self._is_processing = True
        loop = asyncio.get_event_loop()

        try:
            await self._send_json({"type": "processing", "stage": "ai"})

            query = prompt or "Analyse this image for maintenance or repair issues and describe your findings."
            history_snapshot = list(self._history)

            ai_text: str = await loop.run_in_executor(
                None,
                lambda: get_ai_response(
                    transcript=query,
                    image_bytes=image_bytes,
                    image_mime=mime_type,
                    conversation_history=history_snapshot,
                ),
            )

            # Persist image turn (store prompt, not raw bytes, in history)
            self._history.append({"role": "user",  "content": f"[Image] {query}"})
            self._history.append({"role": "model", "content": ai_text})
            self._trim_history()

            await self._send_json({
                "type": "ai_response",
                "text": ai_text,
                "source": "image_analysis",
            })

            # TTS
            await self._send_json({"type": "processing", "stage": "tts"})

            audio_out: bytes | None = await loop.run_in_executor(
                None, lambda: synthesize_speech(ai_text)
            )

            if audio_out:
                await self._send_json({
                    "type": "audio_response",
                    "data": base64.b64encode(audio_out).decode("utf-8"),
                    "mime_type": "audio/mp3",
                })

        finally:
            self._is_processing = False

    # ── Text-only query ───────────────────────────────────────────────────────

    async def _handle_text_message(self, msg: dict) -> None:
        """Handle a typed (non-audio) query from the technician."""
        if self._is_processing:
            await self._send_error("BUSY", "A request is already being processed.")
            return

        content: str = (msg.get("content") or "").strip()
        if not content:
            await self._send_error("EMPTY_MESSAGE", "Message content is empty.")
            return

        self._is_processing = True
        loop = asyncio.get_event_loop()

        try:
            await self._send_json({"type": "processing", "stage": "ai"})

            history_snapshot = list(self._history)
            ai_text: str = await loop.run_in_executor(
                None,
                lambda: get_ai_response(
                    transcript=content,
                    conversation_history=history_snapshot,
                ),
            )

            self._history.append({"role": "user",  "content": content})
            self._history.append({"role": "model", "content": ai_text})
            self._trim_history()

            await self._send_json({"type": "ai_response", "text": ai_text, "source": "text"})

            await self._send_json({"type": "processing", "stage": "tts"})
            audio_out: bytes | None = await loop.run_in_executor(
                None, lambda: synthesize_speech(ai_text)
            )

            if audio_out:
                await self._send_json({
                    "type": "audio_response",
                    "data": base64.b64encode(audio_out).decode("utf-8"),
                    "mime_type": "audio/mp3",
                })

        finally:
            self._is_processing = False

    # ── Utility handlers ──────────────────────────────────────────────────────

    async def _handle_reset(self, _msg: dict | None = None) -> None:
        self._history = []
        self._audio_buffer = BytesIO()
        await self._send_json({"type": "reset_confirmed", "message": "Conversation history cleared."})
        logger.info("[VoiceConsumer] Reset: session=%s", self.session_id)

    async def _handle_ping(self, _msg: dict | None = None) -> None:
        await self._send_json({"type": "pong"})

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _trim_history(self) -> None:
        """Keep at most MAX_HISTORY_PAIRS pairs (user + model messages)."""
        max_messages = MAX_HISTORY_PAIRS * 2
        if len(self._history) > max_messages:
            self._history = self._history[-max_messages:]

    async def _send_json(self, data: dict) -> None:
        try:
            await self.send(text_data=json.dumps(data))
        except Exception as exc:
            logger.warning("[VoiceConsumer] send_json failed: %s", exc)

    async def _send_error(self, code: str, message: str) -> None:
        logger.warning("[VoiceConsumer] error %s: %s (session=%s)", code, message, self.session_id)
        await self._send_json({"type": "error", "code": code, "message": message})
