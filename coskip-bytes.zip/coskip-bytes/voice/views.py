"""
REST views for the voice module.

POST /api/v1/voice/sessions/
    Create a new VoiceSession and return a session_id.
    The FE uses this session_id to open a WebSocket:
        ws://host/ws/voice/<session_id>/

GET  /api/v1/voice/sessions/<session_id>/
    Retrieve session metadata (useful for reconnection scenarios).

DELETE /api/v1/voice/sessions/<session_id>/
    Soft-delete (clear history) or hard-delete a session.
"""
import uuid

from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import VoiceSession


class VoiceSessionCreateView(APIView):
    """POST /api/v1/voice/sessions/ — create a new session."""

    parser_classes = [JSONParser]

    def post(self, request) -> Response:
        tenant_id = request.data.get("tenant_id") or request.headers.get("X-Tenant-Id")
        user_id = request.data.get("user_id")
        language_code = request.data.get("language_code", "en-US")
        voice_profile = request.data.get("voice_profile", "default")

        session = VoiceSession.objects.create(
            tenant_id=tenant_id,
            user_id=user_id,
            language_code=language_code,
            voice_profile=voice_profile,
        )

        return Response(
            {
                "session_id": session.session_id,
                "websocket_path": f"/ws/voice/{session.session_id}/",
                "language_code": session.language_code,
                "voice_profile": session.voice_profile,
            },
            status=status.HTTP_201_CREATED,
        )


class VoiceSessionDetailView(APIView):
    """GET / DELETE /api/v1/voice/sessions/<session_id>/"""

    def get(self, request, session_id: str) -> Response:
        session = get_object_or_404(VoiceSession, session_id=session_id)
        return Response(
            {
                "session_id": session.session_id,
                "tenant_id": session.tenant_id,
                "language_code": session.language_code,
                "voice_profile": session.voice_profile,
                "total_turns": session.total_turns,
                "total_images": session.total_images,
                "created_at": session.created_at.isoformat(),
                "updated_at": session.updated_at.isoformat(),
            }
        )

    def delete(self, request, session_id: str) -> Response:
        session = get_object_or_404(VoiceSession, session_id=session_id)
        session.history_snapshot = []
        session.save(update_fields=["history_snapshot", "updated_at"])
        return Response({"message": "Session history cleared."}, status=status.HTTP_200_OK)
