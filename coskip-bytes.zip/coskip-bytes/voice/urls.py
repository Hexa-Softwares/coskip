from django.urls import path
from .views import VoiceSessionCreateView, VoiceSessionDetailView

urlpatterns = [
    path("voice/sessions/", VoiceSessionCreateView.as_view(), name="voice-session-create"),
    path("voice/sessions/<str:session_id>/", VoiceSessionDetailView.as_view(), name="voice-session-detail"),
]
