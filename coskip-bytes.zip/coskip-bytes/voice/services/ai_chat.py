"""
Conversational AI service for the field technician voice assistant.

Uses Vertex AI Gemini 2.0 Flash — reuses the _ensure_initialised() already in
image_analysis.services.vertex_ai so we don't double-initialise the SDK.

Supports:
  • Text-only queries
  • Image + text (multimodal) queries
  • Conversation history (up to MAX_HISTORY_TURNS)
"""
import logging
import threading

from django.conf import settings

logger = logging.getLogger(__name__)

MAX_HISTORY_TURNS = 10        # Each turn = 1 user + 1 model message pair
_VERTEX_TIMEOUT = 25          # Seconds before we give up and return a fallback

_SYSTEM_PROMPT = """\
You are an expert field technician AI assistant for maintenance and repair operations (CoSkip platform).

ROLE:
- Help technicians diagnose problems, guide repairs, and give technical advice.
- Analyse equipment photos when provided and identify faults, components, and next actions.

RESPONSE RULES:
1. Keep voice responses concise: 2–4 sentences unless step-by-step instructions are needed.
2. For safety-critical issues (electrical faults, gas leaks, pressurised systems) lead with the safety warning.
3. When providing steps, number them clearly: "Step 1 … Step 2 …"
4. If the question is ambiguous, ask ONE specific clarifying question.
5. Use technical but plain language — no markdown, no bullet symbols in voice output.
6. When analysing an image, call out: component name, observed fault/condition, recommended action.

DOMAIN: HVAC, plumbing, electrical distribution, building automation, industrial equipment, fire suppression.\
"""


def get_ai_response(
    transcript: str,
    image_bytes: bytes | None = None,
    image_mime: str | None = None,
    conversation_history: list | None = None,
    timeout: int | None = None,
) -> str:
    """
    Get an AI response for a technician query.

    Args:
        transcript:           The technician's question / transcribed speech.
        image_bytes:          Raw image bytes (optional).
        image_mime:           MIME type of the image, e.g. "image/jpeg".
        conversation_history: List of {"role": "user"|"model", "content": str}.
        timeout:              Override default Vertex AI timeout (seconds).

    Returns:
        AI response string. Never raises — returns a safe fallback message on any error.
    """
    if not getattr(settings, "VERTEX_AI_ENABLED", False):
        return "AI assistant is not available. Please check configuration."

    timeout = timeout or int(getattr(settings, "VERTEX_AI_TIMEOUT_SECONDS", _VERTEX_TIMEOUT))
    conversation_history = conversation_history or []

    try:
        from image_analysis.services.vertex_ai import _ensure_initialised  # noqa: PLC0415
        _ensure_initialised()
    except Exception as exc:
        logger.error("Vertex AI init failed in ai_chat: %s", exc)
        return "Could not connect to the AI assistant. Please try again."

    try:
        from vertexai.generative_models import (  # noqa: PLC0415
            Content,
            GenerationConfig,
            GenerativeModel,
            Part,
        )

        model = GenerativeModel(
            model_name=getattr(settings, "VERTEX_AI_MODEL", "gemini-2.0-flash"),
            system_instruction=_SYSTEM_PROMPT,
        )

        generation_config = GenerationConfig(
            temperature=0.3,
            max_output_tokens=512,
            # No JSON mode — we want natural language
        )

        # ── Build message parts ──────────────────────────────────────────────
        user_parts: list = []

        if image_bytes and image_mime:
            user_parts.append(Part.from_data(data=image_bytes, mime_type=image_mime))

        user_text = transcript.strip() if transcript else (
            "Please analyse this image." if image_bytes else "Hello."
        )
        user_parts.append(Part.from_text(user_text))

        # ── Build chat history (last N turns to stay within context window) ──
        history_contents: list[Content] = []
        trimmed = conversation_history[-(MAX_HISTORY_TURNS * 2):]  # pairs of user/model
        for entry in trimmed:
            role = entry.get("role", "user")
            content_text = entry.get("content", "")
            if content_text:
                history_contents.append(
                    Content(role=role, parts=[Part.from_text(content_text)])
                )

        # ── Thread-guarded Vertex AI call ────────────────────────────────────
        result_holder: list = [None]
        error_holder: list = [None]

        def _call() -> None:
            try:
                if history_contents:
                    chat = model.start_chat(history=history_contents)
                    resp = chat.send_message(user_parts, generation_config=generation_config)
                else:
                    resp = model.generate_content(user_parts, generation_config=generation_config)
                result_holder[0] = resp
            except Exception as exc:  # noqa: BLE001
                error_holder[0] = exc

        thread = threading.Thread(target=_call, daemon=True)
        thread.start()
        thread.join(timeout=timeout)

        if thread.is_alive():
            logger.warning("AI chat timed out after %ss (session context=%d turns)", timeout, len(history_contents))
            return "I'm taking too long to respond. Please ask again."

        if error_holder[0] is not None:
            logger.error("AI chat Vertex error: %s", error_holder[0], exc_info=True)
            return "I encountered an error processing your request. Please try again."

        response = result_holder[0]
        if not response or not getattr(response, "text", None):
            logger.warning("AI chat returned empty response")
            return "I couldn't generate a response. Please rephrase your question."

        return response.text.strip()

    except Exception as exc:
        logger.error("Unexpected error in get_ai_response: %s", exc, exc_info=True)
        return "An unexpected error occurred. Please try again."
