"""
Text-to-Speech service using Google Cloud Text-to-Speech.

Returns MP3 audio bytes. Returns None on failure so callers can degrade
gracefully to text-only responses.
"""
import logging

from django.conf import settings

logger = logging.getLogger(__name__)

# Preset voice profiles. The FE can request a profile name or the raw voice_name.
_VOICE_PROFILES = {
    "default": "en-US-Neural2-D",   # Neutral male — clear for noisy field environments
    "female":  "en-US-Neural2-F",
    "male":    "en-US-Neural2-D",
}

# Cloud TTS has a per-request 5 000 character limit.
_MAX_CHARS = 4_800


def synthesize_speech(
    text: str,
    language_code: str | None = None,
    voice_name: str | None = None,
    voice_profile: str = "default",
    speaking_rate: float = 1.05,     # Slightly faster → sounds crisp in field settings
    pitch: float = -1.0,             # Slightly lower → easier to hear over background noise
) -> bytes | None:
    """
    Convert *text* to MP3 audio bytes.

    Args:
        text:          Input text (truncated to 4 800 chars).
        language_code: BCP-47 code, e.g. "en-US". Falls back to
                       VOICE_DEFAULT_LANGUAGE setting → "en-US".
        voice_name:    Explicit Cloud TTS voice name.  Overrides voice_profile.
        voice_profile: "default" | "female" | "male".
        speaking_rate: 0.25 – 4.0.
        pitch:         -20.0 – 20.0 semitones.

    Returns:
        Raw MP3 bytes, or None if synthesis fails.
    """
    if not text or not text.strip():
        return None

    language_code = language_code or getattr(settings, "VOICE_DEFAULT_LANGUAGE", "en-US")
    if not voice_name:
        voice_name = (
            getattr(settings, "TTS_VOICE_NAME", None)
            or _VOICE_PROFILES.get(voice_profile, _VOICE_PROFILES["default"])
        )

    try:
        from google.cloud import texttospeech  # noqa: PLC0415
    except ImportError:
        logger.error("google-cloud-texttospeech not installed; TTS unavailable.")
        return None

    try:
        client = texttospeech.TextToSpeechClient()

        synthesis_input = texttospeech.SynthesisInput(text=text[:_MAX_CHARS])

        voice = texttospeech.VoiceSelectionParams(
            language_code=language_code,
            name=voice_name,
        )

        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3,
            speaking_rate=max(0.25, min(4.0, speaking_rate)),
            pitch=max(-20.0, min(20.0, pitch)),
            # Slightly boost volume for field environments
            volume_gain_db=1.0,
            effects_profile_id=["headphone-class-device"],  # Optimise for earphones
        )

        response = client.synthesize_speech(
            input=synthesis_input,
            voice=voice,
            audio_config=audio_config,
        )

        return response.audio_content

    except Exception as exc:
        logger.error("TTS synthesis error: %s", exc, exc_info=True)
        return None
