"""
Speech-to-Text service.

Primary  : Google Cloud Speech-to-Text v2 (synchronous recognize).
Fallback : Gemini 2.0 Flash audio understanding (reuses existing Vertex AI init).

Both paths are guarded — if a library isn't installed or a call fails the
function returns None so the caller can decide what to do.
"""
import logging

from django.conf import settings

logger = logging.getLogger(__name__)

# Maps WebRTC / browser audio MIME types → Cloud Speech AudioEncoding enum names.
# Keep lower-cased so we can normalise before lookup.
_MIME_TO_ENCODING = {
    "audio/webm": "WEBM_OPUS",
    "audio/webm;codecs=opus": "WEBM_OPUS",
    "audio/webm; codecs=opus": "WEBM_OPUS",
    "audio/ogg": "OGG_OPUS",
    "audio/ogg;codecs=opus": "OGG_OPUS",
    "audio/ogg; codecs=opus": "OGG_OPUS",
    "audio/mp4": "MP4",                      # Cloud Speech v2 supports MP4/AAC
    "audio/wav": "LINEAR16",
    "audio/x-wav": "LINEAR16",
    "audio/flac": "FLAC",
    "audio/mpeg": "MP3",
    "audio/mp3": "MP3",
    "audio/pcm": "LINEAR16",
}


def transcribe_audio(
    audio_bytes: bytes,
    mime_type: str = "audio/webm;codecs=opus",
    language_code: str | None = None,
    sample_rate_hertz: int | None = None,
) -> dict:
    """
    Transcribe audio bytes to text.

    Returns:
        {
            "transcript": str,       # may be empty string
            "confidence": float,     # 0.0 – 1.0
            "language_code": str,
            "engine": str,           # "cloud_speech" | "gemini" | "none"
        }
    """
    language_code = language_code or getattr(settings, "VOICE_DEFAULT_LANGUAGE", "en-US")

    empty = {"transcript": "", "confidence": 0.0, "language_code": language_code, "engine": "none"}

    if not audio_bytes:
        return empty

    # ── Primary: Google Cloud Speech-to-Text ──────────────────────────────────
    if getattr(settings, "GOOGLE_CLOUD_STT_ENABLED", True):
        result = _cloud_speech_transcribe(audio_bytes, mime_type, language_code, sample_rate_hertz)
        if result is not None:
            return result

    # ── Fallback: Gemini audio understanding ──────────────────────────────────
    if getattr(settings, "VERTEX_AI_ENABLED", False):
        result = _gemini_transcribe(audio_bytes, mime_type, language_code)
        if result is not None:
            return result

    logger.warning("Both STT engines unavailable; returning empty transcript.")
    return empty


# ── Cloud Speech ──────────────────────────────────────────────────────────────

def _cloud_speech_transcribe(
    audio_bytes: bytes,
    mime_type: str,
    language_code: str,
    sample_rate_hertz: int | None,
) -> dict | None:
    """Google Cloud Speech-to-Text synchronous recognise call."""
    try:
        from google.cloud import speech  # noqa: PLC0415
    except ImportError:
        logger.info("google-cloud-speech not installed; skipping Cloud STT.")
        return None

    try:
        client = speech.SpeechClient()

        mime_clean = mime_type.lower().strip()
        encoding_name = (
            _MIME_TO_ENCODING.get(mime_clean)
            or _MIME_TO_ENCODING.get(mime_clean.split(";")[0].strip())
            or "WEBM_OPUS"
        )

        encoding = getattr(
            speech.RecognitionConfig.AudioEncoding,
            encoding_name,
            speech.RecognitionConfig.AudioEncoding.WEBM_OPUS,
        )

        config_kwargs: dict = {
            "encoding": encoding,
            "language_code": language_code,
            "enable_automatic_punctuation": True,
            "model": "latest_long",          # Best accuracy for technical speech
            "use_enhanced": True,
        }
        if sample_rate_hertz:
            config_kwargs["sample_rate_hertz"] = sample_rate_hertz

        config = speech.RecognitionConfig(**config_kwargs)
        audio = speech.RecognitionAudio(content=audio_bytes)

        response = client.recognize(config=config, audio=audio)

        if not response.results:
            return {
                "transcript": "",
                "confidence": 0.0,
                "language_code": language_code,
                "engine": "cloud_speech",
            }

        # Concatenate all result alternatives (handles multi-utterance audio)
        transcript_parts = []
        total_confidence = 0.0
        for result in response.results:
            if result.alternatives:
                alt = result.alternatives[0]
                transcript_parts.append(alt.transcript.strip())
                total_confidence += float(alt.confidence)

        avg_confidence = total_confidence / len(response.results) if response.results else 0.0

        return {
            "transcript": " ".join(transcript_parts).strip(),
            "confidence": round(avg_confidence, 4),
            "language_code": language_code,
            "engine": "cloud_speech",
        }

    except Exception as exc:
        logger.error("Cloud STT error: %s", exc, exc_info=True)
        return None


# ── Gemini fallback ───────────────────────────────────────────────────────────

def _gemini_transcribe(
    audio_bytes: bytes,
    mime_type: str,
    language_code: str,
) -> dict | None:
    """Transcription via Gemini 2.0 Flash audio understanding."""
    try:
        from image_analysis.services.vertex_ai import _ensure_initialised  # noqa: PLC0415
        _ensure_initialised()

        from vertexai.generative_models import (  # noqa: PLC0415
            GenerativeModel,
            GenerationConfig,
            Part,
        )

        model = GenerativeModel(
            getattr(settings, "VERTEX_AI_MODEL", "gemini-2.0-flash")
        )
        audio_part = Part.from_data(data=audio_bytes, mime_type=mime_type)
        prompt = (
            "Transcribe every word spoken in this audio clip as accurately as possible. "
            "Return ONLY the transcribed text with no additional commentary. "
            "If the audio is empty, inaudible, or contains only noise, return an empty string."
        )

        response = model.generate_content(
            [audio_part, prompt],
            generation_config=GenerationConfig(temperature=0.0, max_output_tokens=512),
        )

        transcript = (getattr(response, "text", None) or "").strip()

        return {
            "transcript": transcript,
            "confidence": 0.82 if transcript else 0.0,   # estimated
            "language_code": language_code,
            "engine": "gemini",
        }

    except Exception as exc:
        logger.error("Gemini STT fallback error: %s", exc, exc_info=True)
        return None
