from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    # ws://host/ws/voice/<session_id>/
    re_path(r"^ws/voice/(?P<session_id>[a-zA-Z0-9_\-]{1,64})/$", consumers.VoiceConsumer.as_asgi()),
    # Allow connecting without a pre-existing session_id (consumer will auto-generate one)
    re_path(r"^ws/voice/$", consumers.VoiceConsumer.as_asgi()),
]
