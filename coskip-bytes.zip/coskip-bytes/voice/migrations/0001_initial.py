import django.db.models.deletion
from django.db import migrations, models
import voice.models


class Migration(migrations.Migration):

    initial = True

    dependencies: list = []

    operations = [
        migrations.CreateModel(
            name="VoiceSession",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("session_id", models.CharField(db_index=True, default=voice.models._generate_session_id, max_length=32, unique=True)),
                ("tenant_id", models.CharField(blank=True, db_index=True, max_length=128, null=True)),
                ("user_id", models.CharField(blank=True, max_length=128, null=True)),
                ("language_code", models.CharField(default="en-US", max_length=16)),
                ("voice_profile", models.CharField(default="default", max_length=32)),
                ("history_snapshot", models.JSONField(blank=True, default=list)),
                ("total_turns", models.PositiveIntegerField(default=0)),
                ("total_images", models.PositiveIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"verbose_name": "Voice Session", "verbose_name_plural": "Voice Sessions", "ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="VoiceTurnLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("session", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="turns", to="voice.voicesession")),
                ("turn_type", models.CharField(choices=[("voice", "Voice"), ("image", "Image"), ("text", "Text")], default="voice", max_length=16)),
                ("transcript", models.TextField(blank=True)),
                ("transcript_confidence", models.FloatField(blank=True, null=True)),
                ("stt_engine", models.CharField(blank=True, max_length=32)),
                ("ai_response", models.TextField(blank=True)),
                ("tts_generated", models.BooleanField(default=False)),
                ("had_image", models.BooleanField(default=False)),
                ("error_code", models.CharField(blank=True, max_length=64)),
                ("processing_ms", models.PositiveIntegerField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"verbose_name": "Voice Turn Log", "verbose_name_plural": "Voice Turn Logs", "ordering": ["-created_at"]},
        ),
    ]
