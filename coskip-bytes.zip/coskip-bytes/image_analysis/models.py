import uuid
from django.db import models


def generate_request_id():
    return f"imgreq_{uuid.uuid4().hex[:12]}"


def generate_voice_id():
    return f"vcr_{uuid.uuid4().hex[:12]}"


def generate_assist_id():
    return f"ast_{uuid.uuid4().hex[:12]}"


def generate_audit_id():
    return f"aud_{uuid.uuid4().hex[:12]}"


def generate_alert_id():
    return f"alrt_{uuid.uuid4().hex[:12]}"


def generate_correlation_id():
    return f"corr_{uuid.uuid4().hex[:16]}"


class APIKey(models.Model):
    """API key for Bearer or x-api-key auth."""
    key = models.CharField(max_length=64, unique=True, db_index=True)
    name = models.CharField(max_length=128, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def is_authenticated(self):
        return True

    @property
    def is_anonymous(self):
        return False

    class Meta:
        verbose_name = 'API Key'
        verbose_name_plural = 'API Keys'

    def __str__(self):
        return self.name or f"Key {self.key[:8]}..."


class AnalysisRequest(models.Model):
    class Status(models.TextChoices):
        QUEUED = 'queued', 'Queued'
        PROCESSING = 'processing', 'Processing'
        COMPLETE = 'complete', 'Complete'
        FAILED = 'failed', 'Failed'

    request_id = models.CharField(max_length=32, unique=True, default=generate_request_id, db_index=True)
    correlation_id = models.CharField(max_length=64, default=generate_correlation_id, db_index=True)
    idempotency_key = models.CharField(max_length=255, null=True, blank=True, unique=True, db_index=True)
    provider_request_id = models.CharField(max_length=255, null=True, blank=True)
    retry_count = models.PositiveSmallIntegerField(default=0)
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)

    job_id = models.CharField(max_length=128)
    step_id = models.CharField(max_length=128)
    step_title = models.CharField(max_length=255, blank=True)
    evidence_id = models.CharField(max_length=128, null=True, blank=True)
    evidence_label = models.CharField(max_length=255)
    evidence_type = models.CharField(max_length=32, null=True, blank=True)
    playbook_id = models.CharField(max_length=128, null=True, blank=True)
    playbook_requirement_ids = models.JSONField(default=list, blank=True)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.QUEUED, db_index=True)
    payload = models.JSONField(default=dict)
    result = models.JSONField(null=True, blank=True)
    error = models.JSONField(null=True, blank=True)

    image_path = models.CharField(max_length=512, null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', 'created_at']),
            models.Index(fields=['tenant_id', 'status']),
            models.Index(fields=['job_id', 'step_id']),
        ]
        verbose_name = 'Analysis Request'
        verbose_name_plural = 'Analysis Requests'

    def __str__(self):
        return f"{self.request_id} ({self.status})"


class VoiceCommandLog(models.Model):
    class Status(models.TextChoices):
        PROCESSING = 'processing', 'Processing'
        CONFIRMATION_REQUIRED = 'confirmation_required', 'Confirmation Required'
        CONFIRMED = 'confirmed', 'Confirmed'
        EXECUTED = 'executed', 'Executed'
        FAILED = 'failed', 'Failed'
        CANCELLED = 'cancelled', 'Cancelled'

    voice_command_id = models.CharField(max_length=32, unique=True, default=generate_voice_id, db_index=True)
    correlation_id = models.CharField(max_length=64, default=generate_correlation_id, db_index=True)
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    user_id = models.CharField(max_length=128, null=True, blank=True)
    job_id = models.CharField(max_length=128, null=True, blank=True)
    step_id = models.CharField(max_length=128, null=True, blank=True)
    screen = models.CharField(max_length=128, null=True, blank=True)
    locale = models.CharField(max_length=16, default='en')
    source_app = models.CharField(max_length=32, default='tech')

    transcript_redacted = models.CharField(max_length=512, null=True, blank=True)
    transcript_confidence = models.FloatField(null=True, blank=True)
    intent_name = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    intent_confidence = models.FloatField(null=True, blank=True)
    entities_json = models.JSONField(default=list)
    action_json = models.JSONField(null=True, blank=True)

    confirmation_required = models.BooleanField(default=False)
    confirmation_token = models.CharField(max_length=64, null=True, blank=True)
    confirmation_status = models.CharField(max_length=32, null=True, blank=True)
    execution_status = models.CharField(max_length=32, null=True, blank=True)
    client_action_type = models.CharField(max_length=64, null=True, blank=True)
    client_action_name = models.CharField(max_length=128, null=True, blank=True)

    status = models.CharField(max_length=32, choices=Status.choices, default=Status.PROCESSING, db_index=True)
    latency_ms = models.IntegerField(null=True, blank=True)
    device_family = models.CharField(max_length=64, null=True, blank=True)
    browser_family = models.CharField(max_length=64, null=True, blank=True)
    error_json = models.JSONField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user_id', 'created_at']),
            models.Index(fields=['intent_name', 'created_at']),
            models.Index(fields=['tenant_id', 'status']),
        ]
        verbose_name = 'Voice Command Log'
        verbose_name_plural = 'Voice Command Logs'

    def __str__(self):
        return f"{self.voice_command_id} ({self.intent_name or 'unknown'})"


class AssistRequest(models.Model):
    class Status(models.TextChoices):
        COMPLETE = 'complete', 'Complete'
        FAILED = 'failed', 'Failed'

    assist_id = models.CharField(max_length=32, unique=True, default=generate_assist_id, db_index=True)
    correlation_id = models.CharField(max_length=64, default=generate_correlation_id, db_index=True)
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    user_id = models.CharField(max_length=128, null=True, blank=True)
    job_id = models.CharField(max_length=128)
    step_id = models.CharField(max_length=128)
    question = models.TextField(null=True, blank=True)
    source_app = models.CharField(max_length=32, default='tech')

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.COMPLETE, db_index=True)
    response_json = models.JSONField(null=True, blank=True)
    error_json = models.JSONField(null=True, blank=True)
    latency_ms = models.IntegerField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['job_id', 'step_id']),
            models.Index(fields=['tenant_id', 'created_at']),
        ]
        verbose_name = 'Assist Request'
        verbose_name_plural = 'Assist Requests'

    def __str__(self):
        return f"{self.assist_id} ({self.job_id}/{self.step_id})"


class DecisionOverride(models.Model):
    override_id = models.CharField(max_length=32, unique=True, db_index=True)
    analysis_request = models.ForeignKey(AnalysisRequest, on_delete=models.CASCADE, related_name='overrides')
    playbook_requirement_id = models.CharField(max_length=128, null=True, blank=True)
    previous_decision = models.CharField(max_length=32)
    new_decision = models.CharField(max_length=32)
    reason_code = models.CharField(max_length=64)
    reason_text = models.TextField(blank=True)
    actor_user_id = models.CharField(max_length=128)
    actor_role = models.CharField(max_length=32, default='ops')
    correlation_id = models.CharField(max_length=64, default=generate_correlation_id)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Decision Override'
        verbose_name_plural = 'Decision Overrides'

    def save(self, *args, **kwargs):
        if not self.override_id:
            self.override_id = f"ovr_{uuid.uuid4().hex[:12]}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.override_id}: {self.previous_decision} → {self.new_decision}"


class AuditEvent(models.Model):
    audit_event_id = models.CharField(max_length=32, unique=True, default=generate_audit_id, db_index=True)
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    actor_user_id = models.CharField(max_length=128, null=True, blank=True)
    actor_role = models.CharField(max_length=32, null=True, blank=True)
    feature = models.CharField(max_length=64, db_index=True)
    action = models.CharField(max_length=64, db_index=True)
    entity_type = models.CharField(max_length=64, db_index=True)
    entity_id = models.CharField(max_length=128, db_index=True)
    before_json = models.JSONField(null=True, blank=True)
    after_json = models.JSONField(null=True, blank=True)
    reason_code = models.CharField(max_length=64, null=True, blank=True)
    reason_text = models.TextField(blank=True)
    correlation_id = models.CharField(max_length=64, default=generate_correlation_id, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['entity_type', 'entity_id', 'created_at']),
            models.Index(fields=['tenant_id', 'created_at']),
            models.Index(fields=['feature', 'action']),
        ]
        verbose_name = 'Audit Event'
        verbose_name_plural = 'Audit Events'

    def __str__(self):
        return f"{self.audit_event_id}: {self.feature}.{self.action} on {self.entity_type}/{self.entity_id}"


class AlertItem(models.Model):
    class Severity(models.TextChoices):
        LOW = 'low', 'Low'
        MEDIUM = 'medium', 'Medium'
        HIGH = 'high', 'High'
        CRITICAL = 'critical', 'Critical'

    class Status(models.TextChoices):
        OPEN = 'open', 'Open'
        RESOLVED = 'resolved', 'Resolved'
        DISMISSED = 'dismissed', 'Dismissed'

    alert_id = models.CharField(max_length=32, unique=True, default=generate_alert_id, db_index=True)
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True)
    severity = models.CharField(max_length=16, choices=Severity.choices, default=Severity.MEDIUM, db_index=True)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.OPEN, db_index=True)
    alert_type = models.CharField(max_length=64, db_index=True)
    feature_type = models.CharField(max_length=64, default='evidence_analysis')
    analysis_request = models.ForeignKey(
        AnalysisRequest, on_delete=models.SET_NULL, null=True, blank=True, related_name='alerts'
    )
    subject_type = models.CharField(max_length=64, null=True, blank=True)
    subject_id = models.CharField(max_length=128, null=True, blank=True)
    assigned_to_user_id = models.CharField(max_length=128, null=True, blank=True)
    recommended_action = models.CharField(max_length=255, null=True, blank=True)
    opened_at = models.DateTimeField(auto_now_add=True, db_index=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-opened_at']
        indexes = [
            models.Index(fields=['status', 'severity', 'opened_at']),
            models.Index(fields=['tenant_id', 'status']),
        ]
        verbose_name = 'Alert Item'
        verbose_name_plural = 'Alert Items'

    def __str__(self):
        return f"{self.alert_id} [{self.severity}] {self.alert_type} ({self.status})"
