from django.contrib import admin
from .models import (
    APIKey, AnalysisRequest, VoiceCommandLog,
    AssistRequest, DecisionOverride, AuditEvent, AlertItem,
)


@admin.register(APIKey)
class APIKeyAdmin(admin.ModelAdmin):
    list_display = ('name', 'key_preview', 'is_active', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('name', 'key')

    def key_preview(self, obj):
        return f"{obj.key[:8]}..." if obj.key else "-"
    key_preview.short_description = 'Key'


@admin.register(AnalysisRequest)
class AnalysisRequestAdmin(admin.ModelAdmin):
    list_display = ('request_id', 'job_id', 'step_id', 'status', 'retry_count', 'tenant_id', 'created_at')
    list_filter = ('status', 'tenant_id')
    search_fields = ('request_id', 'job_id', 'step_id', 'correlation_id')
    readonly_fields = ('request_id', 'correlation_id', 'created_at', 'updated_at')


@admin.register(VoiceCommandLog)
class VoiceCommandLogAdmin(admin.ModelAdmin):
    list_display = ('voice_command_id', 'user_id', 'intent_name', 'status', 'latency_ms', 'created_at')
    list_filter = ('status', 'intent_name', 'source_app')
    search_fields = ('voice_command_id', 'user_id', 'job_id', 'correlation_id')
    readonly_fields = ('voice_command_id', 'correlation_id', 'created_at')


@admin.register(AssistRequest)
class AssistRequestAdmin(admin.ModelAdmin):
    list_display = ('assist_id', 'job_id', 'step_id', 'status', 'latency_ms', 'created_at')
    list_filter = ('status', 'source_app')
    search_fields = ('assist_id', 'job_id', 'step_id')
    readonly_fields = ('assist_id', 'correlation_id', 'created_at')


@admin.register(DecisionOverride)
class DecisionOverrideAdmin(admin.ModelAdmin):
    list_display = ('override_id', 'analysis_request', 'previous_decision', 'new_decision', 'reason_code', 'actor_user_id', 'created_at')
    list_filter = ('new_decision', 'reason_code', 'actor_role')
    search_fields = ('override_id', 'actor_user_id')
    readonly_fields = ('override_id', 'created_at')


@admin.register(AuditEvent)
class AuditEventAdmin(admin.ModelAdmin):
    list_display = ('audit_event_id', 'feature', 'action', 'entity_type', 'entity_id', 'actor_user_id', 'created_at')
    list_filter = ('feature', 'action', 'entity_type')
    search_fields = ('audit_event_id', 'entity_id', 'actor_user_id', 'correlation_id')
    readonly_fields = ('audit_event_id', 'created_at')


@admin.register(AlertItem)
class AlertItemAdmin(admin.ModelAdmin):
    list_display = ('alert_id', 'severity', 'status', 'alert_type', 'feature_type', 'opened_at')
    list_filter = ('severity', 'status', 'feature_type')
    search_fields = ('alert_id', 'subject_id')
    readonly_fields = ('alert_id', 'opened_at')
