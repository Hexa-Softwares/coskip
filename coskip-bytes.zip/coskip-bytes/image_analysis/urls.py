from django.urls import path
from .views import (
    ImageAnalysisSubmitView,
    ImageAnalysisResultView,
    VoiceCommandSubmitView,
    VoiceCommandResultView,
    AssistAnalyzeView,
    EvidenceAnalysisRetryView,
    EvidenceAnalysisOverrideView,
    InboxView,
    AuditView,
)

urlpatterns = [
    path('evidence-analyses', ImageAnalysisSubmitView.as_view(), name='image-analysis-submit'),
    path('evidence-analyses/<str:request_id>', ImageAnalysisResultView.as_view(), name='image-analysis-result'),
    path('evidence-analyses/<str:request_id>/retry', EvidenceAnalysisRetryView.as_view(), name='evidence-analysis-retry'),
    path('evidence-analyses/<str:request_id>/override', EvidenceAnalysisOverrideView.as_view(), name='evidence-analysis-override'),

    path('image-analysis', ImageAnalysisSubmitView.as_view(), name='image-analysis-submit-legacy'),
    path('image-analysis/<str:request_id>', ImageAnalysisResultView.as_view(), name='image-analysis-result-legacy'),

    path('voice/commands', VoiceCommandSubmitView.as_view(), name='voice-command-submit'),
    path('voice/commands/<str:command_id>', VoiceCommandResultView.as_view(), name='voice-command-result'),

    path('assist/analyze', AssistAnalyzeView.as_view(), name='assist-analyze'),

    path('inbox', InboxView.as_view(), name='inbox'),
    path('audit', AuditView.as_view(), name='audit'),
]
