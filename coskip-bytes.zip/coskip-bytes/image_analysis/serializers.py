from rest_framework import serializers


class ImageAnalysisPayloadSerializer(serializers.Serializer):
    job_id = serializers.CharField(required=True)
    step_id = serializers.CharField(required=True)
    step_title = serializers.CharField(required=False, allow_blank=True)
    evidence_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    evidence_label = serializers.CharField(required=True)
    evidence_type = serializers.ChoiceField(
        choices=['photo', 'reading', 'note', 'photo_set'],
        required=False,
        allow_blank=True,
        allow_null=True,
    )
    uploader_user_id = serializers.CharField(required=True)
    uploader_role = serializers.ChoiceField(choices=['tech', 'ops', 'admin'], required=True)
    requirement_ids = serializers.ListField(child=serializers.CharField(), required=False, default=list)
    requirements = serializers.ListField(required=False, allow_null=True)
    reading_range = serializers.DictField(required=False, allow_null=True)
    sync = serializers.BooleanField(required=False, default=False)
    callback_url = serializers.URLField(required=False, allow_blank=True, allow_null=True)
    idempotency_key = serializers.CharField(required=False, allow_blank=True, allow_null=True)

    playbook_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    playbook_requirement_ids = serializers.ListField(
        child=serializers.CharField(), required=False, default=list
    )
    tenant_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    correlation_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)


class ImageAnalysisSubmitResponseSerializer(serializers.Serializer):
    request_id = serializers.CharField()
    correlation_id = serializers.CharField()
    status = serializers.CharField()
    received_at = serializers.CharField()
    estimated_seconds = serializers.IntegerField(required=False)


class VoiceCommandSubmitSerializer(serializers.Serializer):
    job_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    step_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    screen = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    locale = serializers.CharField(required=False, default='en')
    source_app = serializers.ChoiceField(
        choices=['tech', 'ops', 'admin'], required=False, default='tech'
    )
    tenant_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    user_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    correlation_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)


class VoiceCommandResponseSerializer(serializers.Serializer):
    voice_command_id = serializers.CharField()
    correlation_id = serializers.CharField()
    status = serializers.CharField()
    transcript = serializers.CharField(allow_null=True)
    transcript_confidence = serializers.FloatField(allow_null=True)
    intent = serializers.DictField(allow_null=True)
    entities = serializers.ListField()
    action = serializers.DictField(allow_null=True)
    confirmation_required = serializers.BooleanField()
    confirmation_token = serializers.CharField(allow_null=True)
    ui_message = serializers.CharField(allow_null=True)
    error = serializers.DictField(allow_null=True, required=False)


class AssistAnalyzeSerializer(serializers.Serializer):
    job_id = serializers.CharField(required=True)
    step_id = serializers.CharField(required=True)
    question = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    requirements = serializers.ListField(required=False, default=list)
    evidence_state = serializers.ListField(required=False, default=list)
    recent_ai_outcomes = serializers.ListField(required=False, default=list)
    source_app = serializers.ChoiceField(
        choices=['tech', 'ops', 'admin'], required=False, default='tech'
    )
    tenant_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    user_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    correlation_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)


class AssistAnalyzeResponseSerializer(serializers.Serializer):
    assist_id = serializers.CharField()
    correlation_id = serializers.CharField()
    status = serializers.CharField()
    summary = serializers.CharField(allow_null=True)
    suggestions = serializers.ListField()
    gaps = serializers.ListField()
    latency_ms = serializers.IntegerField(allow_null=True)


class DecisionOverrideSerializer(serializers.Serializer):
    new_decision = serializers.ChoiceField(
        choices=['pass', 'fail', 'needs_action', 'review_required']
    )
    reason_code = serializers.ChoiceField(
        choices=[
            'human_judgement', 'site_condition', 'equipment_age',
            'photo_quality_acceptable', 'wrong_ai_decision', 'other'
        ]
    )
    reason_text = serializers.CharField(required=False, allow_blank=True, default='')
    actor_user_id = serializers.CharField(required=True)
    actor_role = serializers.ChoiceField(choices=['ops', 'admin'], default='ops')
    playbook_requirement_id = serializers.CharField(
        required=False, allow_blank=True, allow_null=True
    )
    correlation_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)


class AlertItemSerializer(serializers.Serializer):
    alert_id = serializers.CharField()
    severity = serializers.CharField()
    status = serializers.CharField()
    alert_type = serializers.CharField()
    feature_type = serializers.CharField()
    subject_type = serializers.CharField(allow_null=True)
    subject_id = serializers.CharField(allow_null=True)
    request_id = serializers.CharField(allow_null=True)
    recommended_action = serializers.CharField(allow_null=True)
    opened_at = serializers.DateTimeField()
    closed_at = serializers.DateTimeField(allow_null=True)


class AuditEventSerializer(serializers.Serializer):
    audit_event_id = serializers.CharField()
    tenant_id = serializers.CharField(allow_null=True)
    actor_user_id = serializers.CharField(allow_null=True)
    actor_role = serializers.CharField(allow_null=True)
    feature = serializers.CharField()
    action = serializers.CharField()
    entity_type = serializers.CharField()
    entity_id = serializers.CharField()
    reason_code = serializers.CharField(allow_null=True)
    correlation_id = serializers.CharField()
    created_at = serializers.DateTimeField()
