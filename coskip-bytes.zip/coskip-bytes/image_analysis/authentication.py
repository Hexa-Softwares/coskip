from rest_framework import authentication, exceptions


def _get_key_from_request(request):
    key = request.META.get('HTTP_X_API_KEY', '').strip()
    if key:
        return key
    auth = request.META.get('HTTP_AUTHORIZATION') or ''
    if auth.startswith('Bearer '):
        return auth[7:].strip()
    return None


class BearerTokenAuthentication(authentication.BaseAuthentication):
    def authenticate(self, request):
        key = _get_key_from_request(request)
        if not key:
            return None
        from .models import APIKey
        api_key = APIKey.objects.filter(key=key, is_active=True).first()
        if not api_key:
            raise exceptions.AuthenticationFailed('Invalid or inactive API key.')
        return (api_key, key)


class APIKeyAuthentication(authentication.BaseAuthentication):
    def authenticate(self, request):
        key = request.META.get('HTTP_X_API_KEY', '').strip()
        if not key:
            return None
        from .models import APIKey
        api_key = APIKey.objects.filter(key=key, is_active=True).first()
        if not api_key:
            raise exceptions.AuthenticationFailed('Invalid or inactive API key.')
        return (api_key, key)
