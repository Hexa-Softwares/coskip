import json
import logging
import threading
import uuid

from django.conf import settings

logger = logging.getLogger(__name__)

INTENT_CATALOG = [
    # Navigation
    {'name': 'navigate_next_step', 'category': 'navigation', 'description': 'Move to the next step'},
    {'name': 'navigate_previous_step', 'category': 'navigation', 'description': 'Go back to previous step'},
    {'name': 'navigate_to_step', 'category': 'navigation', 'description': 'Jump to a specific step by number or name'},
    {'name': 'navigate_to_section', 'category': 'navigation', 'description': 'Navigate to a named section'},
    # Capture
    {'name': 'capture_photo', 'category': 'capture', 'description': 'Take a photo for current evidence requirement'},
    {'name': 'retake_photo', 'category': 'capture', 'description': 'Retake the last photo'},
    {'name': 'submit_evidence', 'category': 'capture', 'description': 'Submit current evidence for analysis'},
    # Notes
    {'name': 'add_note', 'category': 'notes', 'description': 'Add a voice note to the current step'},
    {'name': 'edit_note', 'category': 'notes', 'description': 'Edit an existing note'},
    # Issues
    {'name': 'report_issue', 'category': 'issues', 'description': 'Flag a problem at the current step'},
    {'name': 'mark_unsafe', 'category': 'issues', 'description': 'Mark current site condition as unsafe'},
    # Approvals
    {'name': 'request_approval', 'category': 'approvals', 'description': 'Request ops/admin approval for an action'},
    {'name': 'confirm_action', 'category': 'approvals', 'description': 'Confirm a pending action'},
    # Wrap-up
    {'name': 'complete_step', 'category': 'wrap_up', 'description': 'Mark current step as complete'},
    {'name': 'complete_job', 'category': 'wrap_up', 'description': 'Wrap up and close the job'},
    # Undo
    {'name': 'undo_last_action', 'category': 'undo', 'description': 'Undo the most recent action'},
    # Help / query
    {'name': 'ask_help', 'category': 'help', 'description': 'Ask for guidance or what to do next'},
    {'name': 'read_requirement', 'category': 'help', 'description': 'Read out the current requirement'},
    {'name': 'unknown', 'category': 'unknown', 'description': 'Intent could not be determined'},
]

TRANSCRIPT_CONFIDENCE_THRESHOLD = 0.85
INTENT_CONFIDENCE_THRESHOLD = 0.90
CONFIRM_REQUIRED_INTENTS = {
    'complete_job', 'submit_evidence', 'mark_unsafe', 'request_approval',
}


def _build_voice_prompt(context: dict) -> str:
    intent_list = '\n'.join(
        f'  - {i["name"]} ({i["category"]}): {i["description"]}'
        for i in INTENT_CATALOG
        if i['name'] != 'unknown'
    )
    job_id = context.get('job_id') or 'unknown'
    step_id = context.get('step_id') or 'unknown'
    screen = context.get('screen') or 'unknown'
    locale = context.get('locale') or 'en'

    return f"""You are the voice command processor for CoSkip, a field technician guidance platform.

CONTEXT:
  job_id: {job_id}
  step_id: {step_id}
  screen: {screen}
  locale: {locale}

TASK:
1. Transcribe the audio accurately.
2. Classify the intent from the catalog below.
3. Extract any named entities (step numbers, requirement IDs, etc.).
4. Determine if the action requires user confirmation before executing.

INTENT CATALOG:
{intent_list}

RULES:
- transcript_confidence: float 0.0–1.0 indicating transcription certainty.
- intent.confidence: float 0.0–1.0 indicating intent classification certainty.
- entities: array of extracted entities with keys "type" and "value".
- action: object with keys "type" (matches intent name) and any relevant parameters.
- If audio is inaudible, empty, or contains only noise: set intent.name="unknown", transcript="", both confidences=0.0.
- Do NOT include markdown. Return ONLY the JSON object.

RETURN THIS EXACT JSON STRUCTURE:
{{
  "transcript": "the transcribed text",
  "transcript_confidence": 0.95,
  "intent": {{
    "name": "capture_photo",
    "category": "capture",
    "confidence": 0.97
  }},
  "entities": [
    {{"type": "step_number", "value": "3"}}
  ],
  "action": {{
    "type": "capture_photo",
    "parameters": {{}}
  }},
  "confirmation_required": false,
  "ui_message": "Taking photo for current step."
}}"""


def _call_gemini_audio(audio_bytes: bytes, mime_type: str, context: dict, timeout: int):
    """Send audio to Gemini 2.0 Flash and return parsed JSON dict or None."""
    from .vertex_ai import _ensure_initialised
    try:
        _ensure_initialised()
    except Exception as exc:
        logger.error("Vertex AI init failed for voice: %s", exc)
        return None

    try:
        from vertexai.generative_models import GenerativeModel, Part, GenerationConfig

        model_name = getattr(settings, 'VERTEX_AI_MODEL', 'gemini-2.0-flash')
        model = GenerativeModel(model_name)

        audio_part = Part.from_data(data=audio_bytes, mime_type=mime_type)
        prompt = _build_voice_prompt(context)

        generation_config = GenerationConfig(
            response_mime_type='application/json',
            temperature=0.0,
            max_output_tokens=512,
        )

        result_holder = [None]
        error_holder = [None]

        def _call():
            try:
                response = model.generate_content(
                    [audio_part, prompt],
                    generation_config=generation_config,
                )
                result_holder[0] = response
            except Exception as exc:
                error_holder[0] = exc

        thread = threading.Thread(target=_call, daemon=True)
        thread.start()
        thread.join(timeout=timeout)

        if thread.is_alive():
            logger.warning("Gemini voice call timed out after %ss", timeout)
            return None

        if error_holder[0] is not None:
            logger.error("Gemini voice call error: %s", error_holder[0])
            return None

        response = result_holder[0]
        if not response or not hasattr(response, 'text') or not response.text:
            return None

        raw = response.text.strip()
        if raw.startswith('```'):
            lines = raw.splitlines()
            if lines[0].startswith('```'):
                lines = lines[1:]
            if lines and lines[-1].strip() == '```':
                lines = lines[:-1]
            raw = '\n'.join(lines).strip()

        return json.loads(raw)

    except Exception as exc:
        logger.error("Unexpected error in _call_gemini_audio: %s", exc, exc_info=True)
        return None


def _apply_confidence_policy(parsed: dict) -> dict:
    """
    SOW §5.4: Apply thresholds to decide action vs confirmation vs reject.
    Mutates and returns parsed dict.
    """
    transcript_conf = float(parsed.get('transcript_confidence') or 0.0)
    intent = parsed.get('intent') or {}
    intent_conf = float(intent.get('confidence') or 0.0)
    intent_name = intent.get('name') or 'unknown'

    if transcript_conf < TRANSCRIPT_CONFIDENCE_THRESHOLD:
        parsed['status'] = 'failed'
        parsed['confirmation_required'] = False
        parsed['ui_message'] = "I didn't catch that clearly. Please try again."
        parsed['action'] = None
        return parsed

    if intent_conf < INTENT_CONFIDENCE_THRESHOLD:
        parsed['status'] = 'confirmation_required'
        parsed['confirmation_required'] = True
        parsed['confirmation_token'] = f"conf_{uuid.uuid4().hex[:8]}"
        parsed['ui_message'] = f"Did you mean: {intent_name.replace('_', ' ')}?"
        return parsed

    if intent_name in CONFIRM_REQUIRED_INTENTS:
        parsed['status'] = 'confirmation_required'
        parsed['confirmation_required'] = True
        parsed['confirmation_token'] = f"conf_{uuid.uuid4().hex[:8]}"
        parsed['ui_message'] = (
            parsed.get('ui_message') or
            f"Confirm: {intent_name.replace('_', ' ')}?"
        )
        return parsed

    parsed['status'] = 'executed'
    parsed['confirmation_required'] = False
    parsed['confirmation_token'] = None
    return parsed


def _fallback_response(error_code: str, message: str) -> dict:
    return {
        'transcript': '',
        'transcript_confidence': 0.0,
        'intent': {'name': 'unknown', 'category': 'unknown', 'confidence': 0.0},
        'entities': [],
        'action': None,
        'confirmation_required': False,
        'confirmation_token': None,
        'ui_message': message,
        'status': 'failed',
        'error': {'code': error_code, 'message': message},
    }


def process_voice_command(audio_bytes: bytes, mime_type: str, context: dict) -> dict:
    """
    Main entry point for voice command processing.

    Returns a dict matching the VoiceCommandResponseSerializer contract.
    Never raises — always returns a response (fallback on any error).
    """
    if not getattr(settings, 'VERTEX_AI_ENABLED', False):
        return _fallback_response('VOICE_DISABLED', 'Voice processing is not enabled.')

    if not audio_bytes:
        return _fallback_response('EMPTY_AUDIO', 'No audio received.')

    max_bytes = 4 * 1024 * 1024  # 4 MB
    if len(audio_bytes) > max_bytes:
        return _fallback_response('AUDIO_TOO_LARGE', 'Audio exceeds maximum allowed size.')

    timeout = int(getattr(settings, 'VERTEX_AI_TIMEOUT_SECONDS', 25))

    parsed = _call_gemini_audio(audio_bytes, mime_type, context, timeout)

    if parsed is None:
        return _fallback_response('GEMINI_ERROR', 'Could not process audio. Please try again.')

    # Sanitise fields
    parsed.setdefault('transcript', '')
    parsed.setdefault('transcript_confidence', 0.0)
    parsed.setdefault('intent', {'name': 'unknown', 'category': 'unknown', 'confidence': 0.0})
    parsed.setdefault('entities', [])
    parsed.setdefault('action', None)
    parsed.setdefault('confirmation_required', False)
    parsed.setdefault('confirmation_token', None)
    parsed.setdefault('ui_message', '')
    parsed.setdefault('error', None)

    parsed = _apply_confidence_policy(parsed)
    return parsed
