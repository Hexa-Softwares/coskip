import json
import logging
import threading

from django.conf import settings

logger = logging.getLogger(__name__)

ASSIST_TIMEOUT_SECONDS = 12

SUGGESTION_TYPES = frozenset([
    'retake_photo', 'add_note', 'mark_complete', 'escalate',
    'request_approval', 'navigate_step', 'capture_reading', 'other',
])

SUGGESTION_PRIORITIES = frozenset(['high', 'medium', 'low'])


def _build_assist_prompt(job_id: str, step_id: str, question: str | None,
                         requirements: list, evidence_state: list,
                         recent_outcomes: list) -> str:
    req_text = 'None specified.'
    if requirements:
        lines = []
        for r in requirements:
            status = 'PENDING'
            label = r.get('label') or r.get('id', '')
            required = r.get('required', True)
            lines.append(f'  - id={r.get("id","")!r}, label={label!r}, required={required}, status={status}')
        req_text = '\n'.join(lines)

    evidence_text = 'None.'
    if evidence_state:
        lines = []
        for e in evidence_state:
            decision = e.get('decision') or 'pending'
            label = e.get('evidence_label') or e.get('evidence_id', '')
            lines.append(f'  - label={label!r}, decision={decision!r}')
        evidence_text = '\n'.join(lines)

    outcomes_text = 'None.'
    if recent_outcomes:
        lines = []
        for o in recent_outcomes:
            lines.append(f'  - {o.get("type","unknown")}: {o.get("summary","")[:80]}')
        outcomes_text = '\n'.join(lines)

    user_question = question.strip() if question else 'What should I do next to complete this step?'

    return f"""You are the Tech Assist AI for CoSkip, a field technician guidance platform.
Your role is to analyze the current state of a job step and guide the technician.

JOB CONTEXT:
  job_id: {job_id}
  step_id: {step_id}

PLAYBOOK REQUIREMENTS FOR THIS STEP:
{req_text}

CURRENT EVIDENCE STATE:
{evidence_text}

RECENT AI OUTCOMES:
{outcomes_text}

TECHNICIAN QUESTION:
  "{user_question}"

TASK:
1. Analyze what is missing or still needs to be done.
2. Provide a plain-language summary (1-3 sentences, jargon-free).
3. List concrete suggestions with priorities.
4. List any gaps in evidence.

SUGGESTION TYPE VALUES (use only these):
  retake_photo, add_note, mark_complete, escalate, request_approval, navigate_step, capture_reading, other

PRIORITY VALUES: high, medium, low

RULES:
- Keep summary to 1-3 sentences. Be direct and practical.
- suggestions array: max 5 items.
- gaps array: list evidence IDs or labels that are missing or failed.
- Do NOT include markdown. Return ONLY the JSON object.

RETURN THIS EXACT JSON STRUCTURE:
{{
  "summary": "You still need to capture a clear photo of the HVAC condensate drain. The previous photo was blurry.",
  "suggestions": [
    {{
      "type": "retake_photo",
      "label": "Retake condensate drain photo",
      "priority": "high",
      "playbook_requirement_id": "req_001",
      "reason": "Previous photo was blurry and failed AI analysis."
    }}
  ],
  "gaps": ["req_001"]
}}"""


def _call_gemini_text(prompt: str, timeout: int) -> dict | None:
    """Call Gemini with text-only prompt; return parsed JSON or None."""
    from .vertex_ai import _ensure_initialised
    try:
        _ensure_initialised()
    except Exception as exc:
        logger.error("Vertex AI init failed for assist: %s", exc)
        return None

    try:
        from vertexai.generative_models import GenerativeModel, GenerationConfig

        model_name = getattr(settings, 'VERTEX_AI_MODEL', 'gemini-2.0-flash')
        model = GenerativeModel(model_name)

        generation_config = GenerationConfig(
            response_mime_type='application/json',
            temperature=0.2,
            max_output_tokens=512,
        )

        result_holder = [None]
        error_holder = [None]

        def _call():
            try:
                response = model.generate_content(prompt, generation_config=generation_config)
                result_holder[0] = response
            except Exception as exc:
                error_holder[0] = exc

        thread = threading.Thread(target=_call, daemon=True)
        thread.start()
        thread.join(timeout=timeout)

        if thread.is_alive():
            logger.warning("Gemini assist call timed out after %ss", timeout)
            return None

        if error_holder[0] is not None:
            logger.error("Gemini assist call error: %s", error_holder[0])
            return None

        response = result_holder[0]
        if not response or not hasattr(response, 'text') or not response.text:
            return None

        raw = response.text.strip()
        if raw.startswith('```'):
            lines = raw.splitlines()
            if lines[0].startswith('```'):
                lines = lines[1:]
            if lines and lines[-1].strip() == '```':
                lines = lines[:-1]
            raw = '\n'.join(lines).strip()

        return json.loads(raw)

    except Exception as exc:
        logger.error("Unexpected error in _call_gemini_text: %s", exc, exc_info=True)
        return None


def _sanitise_assist_response(data: dict) -> dict:
    """Validate and sanitise the Gemini assist response."""
    summary = str(data.get('summary') or '')[:600]

    suggestions = []
    for s in (data.get('suggestions') or [])[:5]:
        if not isinstance(s, dict):
            continue
        stype = str(s.get('type') or 'other').lower()
        if stype not in SUGGESTION_TYPES:
            stype = 'other'
        priority = str(s.get('priority') or 'medium').lower()
        if priority not in SUGGESTION_PRIORITIES:
            priority = 'medium'
        suggestions.append({
            'type': stype,
            'label': str(s.get('label') or '')[:200],
            'priority': priority,
            'playbook_requirement_id': str(s.get('playbook_requirement_id') or '') or None,
            'reason': str(s.get('reason') or '')[:400],
        })

    gaps = []
    for g in (data.get('gaps') or []):
        if isinstance(g, str):
            gaps.append(g[:128])

    return {'summary': summary, 'suggestions': suggestions, 'gaps': gaps}


def _deterministic_fallback(job_id: str, step_id: str) -> dict:
    return {
        'summary': (
            'Unable to retrieve AI guidance at this time. '
            'Please review the playbook requirements manually and ensure all required evidence is captured.'
        ),
        'suggestions': [
            {
                'type': 'other',
                'label': 'Review playbook requirements',
                'priority': 'high',
                'playbook_requirement_id': None,
                'reason': 'AI guidance unavailable. Fall back to manual review.',
            }
        ],
        'gaps': [],
    }


def get_assist_guidance(job_id: str, step_id: str, question: str | None,
                        requirements: list, evidence_state: list,
                        recent_outcomes: list) -> dict:
    """
    Main entry point for Tech Assist.

    Returns sanitised guidance dict. Never raises — falls back to deterministic
    guidance if Gemini is unavailable or returns invalid output.
    """
    if not getattr(settings, 'VERTEX_AI_ENABLED', False):
        return _deterministic_fallback(job_id, step_id)

    timeout = int(getattr(settings, 'ASSIST_TIMEOUT_SECONDS', ASSIST_TIMEOUT_SECONDS))
    prompt = _build_assist_prompt(
        job_id, step_id, question, requirements, evidence_state, recent_outcomes
    )

    raw = _call_gemini_text(prompt, timeout)

    if raw is None or not isinstance(raw, dict):
        logger.warning("Assist fallback for job_id=%s step_id=%s", job_id, step_id)
        return _deterministic_fallback(job_id, step_id)

    try:
        return _sanitise_assist_response(raw)
    except Exception as exc:
        logger.error("Assist sanitise error: %s", exc)
        return _deterministic_fallback(job_id, step_id)
