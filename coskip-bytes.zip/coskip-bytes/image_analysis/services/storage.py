"""
Save uploaded image; fetch image from HTTPS URL.
"""
import uuid
from pathlib import Path

import httpx
from django.conf import settings
from PIL import Image, ImageOps

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pillow_heif = None

MAX_URL_SIZE_BYTES = (getattr(settings, 'IMAGE_MAX_SIZE_MB', 10) or 10) * 1024 * 1024
URL_TIMEOUT = 30


def _ensure_media_subdir(subdir='analysis'):
    base = getattr(settings, 'MEDIA_ROOT', None) or Path(settings.BASE_DIR) / 'media'
    path = Path(base) / subdir
    path.mkdir(parents=True, exist_ok=True)
    return path


def save_uploaded_image(uploaded_file):
    """
    Save uploaded file to MEDIA_ROOT/analysis as JPEG.
    All formats (JPEG, PNG, HEIC/HEIF) are converted to JPEG so that the
    .jpg path always contains valid JPEG bytes (correct for MIME detection).
    """
    upload_path = _ensure_media_subdir()
    out_path = upload_path / f"{uuid.uuid4().hex}.jpg"
    try:
        uploaded_file.seek(0)
        img = Image.open(uploaded_file)
        img = ImageOps.exif_transpose(img)
        if img.mode in ('RGBA', 'P', 'LA', 'PA'):
            img = img.convert('RGB')
        elif img.mode != 'RGB':
            img = img.convert('RGB')
        img.save(out_path, 'JPEG', quality=90)
        return str(out_path)
    except Exception:
        # Last-resort: write raw bytes (upload stays on disk; Pillow open failed)
        uploaded_file.seek(0)
        with open(out_path, 'wb') as f:
            for chunk in uploaded_file.chunks():
                f.write(chunk)
        return str(out_path)


def fetch_image_from_url(url):
    """
    Fetch image from HTTPS URL (stream, max 10MB). Save to MEDIA_ROOT/analysis as JPEG.
    Converts to JPEG after download so the .jpg path always contains valid JPEG bytes.
    """
    if not url.startswith('https://'):
        raise ValueError('Only HTTPS URLs are allowed.')
    path = _ensure_media_subdir() / f"{uuid.uuid4().hex}.jpg"
    size = 0
    with httpx.stream('GET', url, timeout=URL_TIMEOUT, follow_redirects=True) as r:
        r.raise_for_status()
        with open(path, 'wb') as f:
            for chunk in r.iter_bytes(chunk_size=65536):
                size += len(chunk)
                if size > MAX_URL_SIZE_BYTES:
                    if path.exists():
                        path.unlink()
                    raise ValueError('Image from URL exceeds maximum size.')
                f.write(chunk)
    # Convert downloaded file to JPEG in-place so MIME always matches the .jpg extension
    try:
        img = Image.open(path)
        img = ImageOps.exif_transpose(img)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        img.save(path, 'JPEG', quality=90)
    except Exception:
        pass  # Leave raw bytes; validate_image_from_path will reject unreadable files
    return str(path)
