"""
Vertex AI / Gemini vision analysis service.

Sends the image + evidence context to Gemini 2.0 Flash and returns a structured
dict that maps directly to the API contract fields. Returns None on any error so
the caller can fall back to heuristics without crashing.
"""
import json
import logging
import mimetypes
import sys
import threading
from pathlib import Path

from django.conf import settings

logger = logging.getLogger(__name__)

# Cached initialisation flag to avoid repeated vertexai.init() calls
_vertexai_initialised = False
_init_lock = threading.Lock()

# Required top-level keys in the Gemini JSON response
_REQUIRED_KEYS = frozenset([
    'decision', 'overall_score', 'confidence', 'summary',
    'is_wrong_subject', 'issues', 'objects', 'review_decision',
    'required_actions', 'checks', 'notes',
])

_VALID_DECISIONS = {'pass', 'needs_action', 'fail'}
_VALID_REVIEW_DECISIONS = {'accept', 'retry_photo', 'manual_review'}
_VALID_SEVERITIES = {'high', 'medium', 'low'}
# Contract v1: blur, occlusion, glare, low_light, missing_element, wrong_subject
_VALID_ISSUE_TYPES = {
    'blur', 'low_light', 'glare', 'wrong_subject',
    'missing_element', 'obstructed', 'occlusion', 'quality',
}


def _ensure_initialised():
    global _vertexai_initialised
    if _vertexai_initialised:
        return
    with _init_lock:
        if _vertexai_initialised:
            return
        import vertexai
        project = getattr(settings, 'VERTEX_AI_PROJECT', None)
        location = getattr(settings, 'VERTEX_AI_LOCATION', 'global')
        vertexai.init(project=project, location=location)
        _vertexai_initialised = True


def _warmup_worker():
    """
    Send a minimal text-only ping to Gemini in the background at startup.
    This establishes the HTTPS connection, caches auth tokens, and warms the
    model endpoint so the first real image request does not hit cold-start
    latency and time out, causing a spurious fallback to vision-v2.
    """
    try:
        _ensure_initialised()
        from vertexai.generative_models import GenerativeModel, GenerationConfig
        model_name = getattr(settings, 'VERTEX_AI_MODEL', 'gemini-2.0-flash')
        model = GenerativeModel(model_name)
        model.generate_content(
            "Reply with exactly one word: ready",
            generation_config=GenerationConfig(max_output_tokens=5, temperature=0.0),
        )
        logger.info("Vertex AI warm-up complete.")
    except Exception as exc:
        logger.warning("Vertex AI warm-up failed (non-fatal): %s", exc)


def _should_warmup_at_startup():
    """
    Only warm up for long-lived server processes. Skip manage.py commands
    (createsuperuser, migrate, test, etc.) so local/admin tasks do not need GCP
    credentials and logs do not interleave with interactive prompts.
    """
    argv = sys.argv
    if len(argv) >= 2 and argv[0].endswith('manage.py'):
        return argv[1] == 'runserver'
    return True


def warmup_vertex_ai():
    """
    Called from AppConfig.ready() to pre-warm the Vertex AI connection.
    Runs in a daemon thread so Django startup is never blocked.
    Only fires when VERTEX_AI_ENABLED=True.
    """
    if not getattr(settings, 'VERTEX_AI_ENABLED', False):
        return
    if not _should_warmup_at_startup():
        return
    t = threading.Thread(target=_warmup_worker, daemon=True, name='vertex-ai-warmup')
    t.start()


def _build_prompt(evidence_label: str, requirements: list) -> str:
    req_text = 'None specified.'
    if requirements:
        lines = []
        for r in requirements:
            rid = r.get('id', '')
            label = r.get('label', rid)
            required = r.get('required', True)
            lines.append(f'  - id={rid!r}, label={label!r}, required={required}')
        req_text = '\n'.join(lines)

    return f"""You are an automated image evidence validator for insurance and maintenance claims.

Analyze the attached image. Use the context below to decide whether this image is valid proof/evidence.

CONTEXT:
  evidence_label: {evidence_label!r}
  requirements:
{req_text}

TASK:
1. Decide: is this a valid, clear evidence photo for the stated evidence type?
2. Identify quality issues: blur, poor lighting, glare, or occlusion (critical area blocked or partially hidden). Use issue type "occlusion" when the required evidence is partially obstructed.
3. Identify if the image shows the wrong subject (e.g. a selfie, a random room photo, a logo, an animal) rather than relevant evidence (pipes, HVAC, structural damage, fixtures, etc.).
4. Detect and list all relevant objects visible in the image with approximate bounding boxes.
5. Evaluate each requirement individually.

RULES:
- "pass" = image clearly shows the required evidence with acceptable quality; ALL required checks must be passed.
- "needs_action" = image shows the subject but has quality issues or is partially unclear.
- "fail" = image is completely wrong subject, empty, or unreadable.
- For evidence involving "HVAC condensate drain", "air handler", or "condensate drain PVC": pass ONLY if BOTH the air handler unit (or equivalent HVAC equipment) AND the PVC condensate drain pipe or its connection are clearly visible in the image. A floor drain, sink drain, or generic drain alone is NOT sufficient — the image must show the HVAC equipment and its condensate drain together.
- When the image is wrong subject (e.g. wrong room, logo, unrelated equipment), set "wrong_subject" issue with severity "high".
- Bounding box coordinates (x, y, w, h) must be normalised to [0.0, 1.0] relative to image width/height.
  x, y = top-left corner; w = width; h = height.
- overall_score and confidence must be floats between 0.0 and 1.0.
- CRITICAL: You MUST return exactly one entry in "checks" for EACH requirement listed above, using the SAME "id" as given. Set "passed" to true only if that specific requirement is clearly satisfied by the image; set "score" between 0.0 and 1.0 accordingly. If the image is wrong subject or does not show the required evidence, set passed=false and score low for every requirement.
- If there are no requirements, return an empty "checks" array.
- "issues" array may be empty if image is good.
- "objects" array should list every relevant object with a bounding box; may be empty only if the image is completely wrong/unreadable.
- Do NOT include any markdown or explanation — return ONLY the JSON object below.

RETURN THIS EXACT JSON STRUCTURE (no extra keys, no missing keys):
{{
  "decision": "pass",
  "overall_score": 0.85,
  "confidence": 0.9,
  "summary": "Single sentence summary of the analysis.",
  "is_wrong_subject": false,
  "issues": [
    {{"type": "blur", "severity": "medium", "message": "Image appears slightly blurry."}}
  ],
  "objects": [
    {{"label": "pipe", "x": 0.1, "y": 0.2, "w": 0.4, "h": 0.3, "confidence": 0.92}}
  ],
  "review_decision": "accept",
  "required_actions": [],
  "checks": [
    {{"id": "req_001", "passed": true, "score": 0.9, "notes": null}}
  ],
  "notes": "Additional reviewer notes if any, otherwise null."
}}"""


def _load_image_bytes(image_path: str):
    """Read image file and return (bytes, mime_type)."""
    path = Path(image_path)
    mime, _ = mimetypes.guess_type(str(path))
    if not mime or mime not in ('image/jpeg', 'image/png', 'image/webp', 'image/heic'):
        mime = 'image/jpeg'
    data = path.read_bytes()
    return data, mime


def _validate_response(data: dict) -> bool:
    """
    Return True if the parsed dict has the required structure (types only).
    Enum values are normalised in _sanitise_response — we don't hard-reject here
    so that minor Gemini enum variations (e.g. "reject" vs "retry_photo") don't
    cause an unnecessary fallback to heuristics.
    """
    if not isinstance(data, dict):
        return False
    if not _REQUIRED_KEYS.issubset(data.keys()):
        missing = _REQUIRED_KEYS - data.keys()
        logger.warning("Gemini response missing keys: %s", missing)
        return False
    # Must be numeric (coercible)
    try:
        float(data.get('overall_score', 'x'))
        float(data.get('confidence', 'x'))
    except (TypeError, ValueError):
        return False
    # Must be lists
    if not isinstance(data.get('issues'), list):
        return False
    if not isinstance(data.get('objects'), list):
        return False
    if not isinstance(data.get('checks'), list):
        return False
    if not isinstance(data.get('required_actions'), list):
        return False
    return True


# Map of Gemini free-text decision → canonical value
_DECISION_MAP = {
    'pass': 'pass',
    'passed': 'pass',
    'accept': 'pass',
    'needs_action': 'needs_action',
    'needs action': 'needs_action',
    'action_needed': 'needs_action',
    'action needed': 'needs_action',
    'fail': 'fail',
    'failed': 'fail',
    'reject': 'fail',
    'rejected': 'fail',
    'deny': 'fail',
}
_REVIEW_DECISION_MAP = {
    'accept': 'accept',
    'accepted': 'accept',
    'pass': 'accept',
    'retry_photo': 'retry_photo',
    'retry photo': 'retry_photo',
    'retry': 'retry_photo',
    'retake': 'retry_photo',
    'retake_photo': 'retry_photo',
    'manual_review': 'manual_review',
    'manual review': 'manual_review',
    'review': 'manual_review',
    'reject': 'retry_photo',
    'rejected': 'retry_photo',
    'fail': 'retry_photo',
    'deny': 'retry_photo',
}


def _sanitise_response(data: dict) -> dict:
    """Normalise enum values and clamp numeric fields to safe ranges."""
    data['overall_score'] = max(0.0, min(1.0, float(data['overall_score'])))
    data['confidence'] = max(0.0, min(1.0, float(data['confidence'])))
    data['is_wrong_subject'] = bool(data.get('is_wrong_subject', False))
    data['summary'] = str(data.get('summary') or '')[:500]
    data['notes'] = str(data['notes']) if data.get('notes') else None

    # Normalise decision — derive from is_wrong_subject if unknown
    raw_decision = str(data.get('decision') or '').lower().strip()
    data['decision'] = _DECISION_MAP.get(raw_decision) or (
        'fail' if data['is_wrong_subject'] else 'needs_action'
    )

    # Normalise review_decision — derive from decision if unknown
    raw_review = str(data.get('review_decision') or '').lower().strip()
    data['review_decision'] = _REVIEW_DECISION_MAP.get(raw_review) or (
        'accept' if data['decision'] == 'pass' else 'retry_photo'
    )

    # Sanitise issues (wrong_subject is always high severity)
    clean_issues = []
    for issue in data.get('issues', []):
        if not isinstance(issue, dict):
            continue
        itype = str(issue.get('type', 'quality')).lower()
        if itype not in _VALID_ISSUE_TYPES:
            itype = 'quality'
        severity = str(issue.get('severity', 'low')).lower()
        if severity not in _VALID_SEVERITIES:
            severity = 'low'
        if itype == 'wrong_subject':
            severity = 'high'
        clean_issues.append({
            'type': itype,
            'severity': severity,
            'message': str(issue.get('message', ''))[:300],
        })
    data['issues'] = clean_issues

    # Sanitise objects (bounding boxes)
    clean_objects = []
    for obj in data.get('objects', []):
        if not isinstance(obj, dict):
            continue
        try:
            clean_objects.append({
                'label': str(obj.get('label', 'object'))[:100],
                'x': max(0.0, min(1.0, float(obj.get('x', 0)))),
                'y': max(0.0, min(1.0, float(obj.get('y', 0)))),
                'w': max(0.0, min(1.0, float(obj.get('w', 0)))),
                'h': max(0.0, min(1.0, float(obj.get('h', 0)))),
                'confidence': max(0.0, min(1.0, float(obj.get('confidence', 0.5)))),
            })
        except (TypeError, ValueError):
            continue
    data['objects'] = clean_objects

    # Sanitise checks
    clean_checks = []
    for chk in data.get('checks', []):
        if not isinstance(chk, dict):
            continue
        try:
            clean_checks.append({
                'id': str(chk.get('id', ''))[:128],
                'passed': bool(chk.get('passed', False)),
                'score': max(0.0, min(1.0, float(chk.get('score', 0.0)))),
                'notes': str(chk['notes'])[:300] if chk.get('notes') else None,
            })
        except (TypeError, ValueError):
            continue
    data['checks'] = clean_checks

    # Sanitise required_actions
    clean_actions = []
    for act in data.get('required_actions', []):
        if not isinstance(act, dict):
            continue
        clean_actions.append({
            'action': str(act.get('action', 'retake_photo'))[:100],
            'reason': str(act.get('reason', ''))[:300],
        })
    data['required_actions'] = clean_actions

    return data


def analyze_with_gemini(image_path: str, payload: dict):
    """
    Call Gemini with the image and evidence context.

    Returns a sanitised dict on success, or None if Vertex AI is disabled,
    the model call fails, or the response cannot be parsed/validated.
    The caller must treat None as "fall back to heuristics".
    """
    if not getattr(settings, 'VERTEX_AI_ENABLED', False):
        return None

    timeout = int(getattr(settings, 'VERTEX_AI_TIMEOUT_SECONDS', 25))
    model_name = getattr(settings, 'VERTEX_AI_MODEL', 'gemini-2.0-flash')

    try:
        _ensure_initialised()
    except Exception as exc:
        logger.error("Vertex AI init failed: %s", exc)
        return None

    try:
        from vertexai.generative_models import GenerativeModel, Part, GenerationConfig

        evidence_label = payload.get('evidence_label') or ''
        requirements = payload.get('requirements') or []

        image_bytes, mime_type = _load_image_bytes(image_path)
        image_part = Part.from_data(data=image_bytes, mime_type=mime_type)
        prompt = _build_prompt(evidence_label, requirements)

        model = GenerativeModel(model_name)
        generation_config = GenerationConfig(
            response_mime_type='application/json',
            temperature=0.1,
            max_output_tokens=1024,
        )

        result_holder = [None]
        error_holder = [None]

        def _call():
            try:
                response = model.generate_content(
                    [image_part, prompt],
                    generation_config=generation_config,
                )
                result_holder[0] = response
            except Exception as exc:
                error_holder[0] = exc

        thread = threading.Thread(target=_call, daemon=True)
        thread.start()
        thread.join(timeout=timeout)

        if thread.is_alive():
            logger.warning("Gemini call timed out after %ss; falling back to heuristics.", timeout)
            return None

        if error_holder[0] is not None:
            logger.error("Gemini call error: %s", error_holder[0])
            return None

        response = result_holder[0]
        if response is None:
            return None

        # Safely access response.text (defensive check)
        if not hasattr(response, 'text') or response.text is None:
            logger.warning("Gemini response missing text attribute")
            return None

        raw_text = response.text.strip()

        # Strip markdown code fences if Gemini wraps the JSON despite the instruction.
        # Only remove the opening fence (first line) and closing fence (last line) so
        # that ``` appearing inside a JSON string value is never accidentally dropped.
        if raw_text.startswith('```'):
            lines = raw_text.splitlines()
            if lines and lines[0].strip().startswith('```'):
                lines = lines[1:]
            if lines and lines[-1].strip() == '```':
                lines = lines[:-1]
            raw_text = '\n'.join(lines).strip()

        try:
            parsed = json.loads(raw_text)
        except json.JSONDecodeError as exc:
            logger.error("Gemini returned invalid JSON: %s | raw: %.200s", exc, raw_text)
            return None

        if not _validate_response(parsed):
            logger.warning("Gemini response failed validation; falling back. raw: %.500s", raw_text)
            return None

        sanitised = _sanitise_response(parsed)
        logger.debug(
            "Gemini result: decision=%s review_decision=%s score=%.2f wrong_subject=%s objects=%d",
            sanitised['decision'], sanitised['review_decision'],
            sanitised['overall_score'], sanitised['is_wrong_subject'],
            len(sanitised['objects']),
        )
        return sanitised

    except Exception as exc:
        logger.error("Unexpected error in analyze_with_gemini: %s", exc, exc_info=True)
        return None
