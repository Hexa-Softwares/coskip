"""
Input validation: format, size, resolution. HEIC supported via pillow-heif.
"""
from pathlib import Path

from django.conf import settings
from PIL import Image, ImageOps

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pillow_heif = None


class ValidationError(Exception):
    def __init__(self, code, message):
        self.code = code
        self.message = message
        super().__init__(message)


def _open_image(file_or_path):
    if hasattr(file_or_path, 'read'):
        file_or_path.seek(0)
        img = Image.open(file_or_path)
    else:
        img = Image.open(file_or_path)
    img.load()
    img = ImageOps.exif_transpose(img)
    return img


def _long_edge_px(img):
    return max(img.size[0], img.size[1])


def validate_image_file(uploaded_file):
    """Validate uploaded file. Raises ValidationError. Returns (image, long_edge_px)."""
    max_bytes = (getattr(settings, 'IMAGE_MAX_SIZE_MB', 10) or 10) * 1024 * 1024
    if uploaded_file.size > max_bytes:
        raise ValidationError(
            'IMAGE_TOO_LARGE',
            f'Image exceeds maximum size ({getattr(settings, "IMAGE_MAX_SIZE_MB", 10)}MB).',
        )
    if uploaded_file.size == 0:
        raise ValidationError('INVALID_IMAGE', 'Image file is empty.')

    try:
        img = _open_image(uploaded_file)
    except Exception as e:
        raise ValidationError('IMAGE_UNREADABLE', f'Image could not be read: {e}')

    long_edge = _long_edge_px(img)
    min_edge = getattr(settings, 'IMAGE_MIN_LONG_EDGE_PX', 1280) or 1280
    if long_edge < min_edge:
        raise ValidationError(
            'IMAGE_TOO_SMALL',
            f'Image long edge must be at least {min_edge}px (got {long_edge}px).',
        )

    allowed = getattr(settings, 'IMAGE_ALLOWED_FORMATS', ['JPEG', 'PNG', 'HEIC']) or ['JPEG', 'PNG', 'HEIC']
    fmt = (img.format or '').upper()
    if fmt and fmt not in [f.upper() for f in allowed]:
        name = getattr(uploaded_file, 'name', '') or ''
        if not name.upper().endswith('.HEIC') and not name.upper().endswith('.HEIF'):
            raise ValidationError('INVALID_IMAGE', f'Format not allowed. Allowed: {allowed}.')

    return img, long_edge


def validate_image_from_path(path):
    """Validate image at path. Raises ValidationError. Returns (image, long_edge_px)."""
    path = Path(path)
    if not path.exists():
        raise ValidationError('INVALID_IMAGE', 'Image file not found.')
    size_bytes = path.stat().st_size
    max_bytes = (getattr(settings, 'IMAGE_MAX_SIZE_MB', 10) or 10) * 1024 * 1024
    if size_bytes > max_bytes:
        raise ValidationError('IMAGE_TOO_LARGE', f'Image exceeds maximum size ({getattr(settings, "IMAGE_MAX_SIZE_MB", 10)}MB).')

    try:
        img = _open_image(path)
    except Exception as e:
        raise ValidationError('IMAGE_UNREADABLE', f'Image could not be read: {e}')

    long_edge = _long_edge_px(img)
    min_edge = getattr(settings, 'IMAGE_MIN_LONG_EDGE_PX', 1280) or 1280
    if long_edge < min_edge:
        raise ValidationError(
            'IMAGE_TOO_SMALL',
            f'Image long edge must be at least {min_edge}px (got {long_edge}px).',
        )
    return img, long_edge
