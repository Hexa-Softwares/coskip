"""
Analysis pipeline: Vertex AI (Gemini) primary path + heuristics fallback.

Flow:
  1. Load image, run blur + brightness heuristics (always, fast).
  2. If VERTEX_AI_ENABLED, call analyze_with_gemini(); merge result into contract response.
  3. If Gemini returns None (disabled / timeout / error), fall back to heuristics-only path.
  4. Optional MediaPipe classifier / detector remain as supplementary layers when configured.
"""
import logging
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from django.conf import settings
from PIL import Image, ImageOps

try:
    import pillow_heif
    pillow_heif.register_heif_opener()
except ImportError:
    pass

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------- #
#  MediaPipe (optional) — cached instances
# --------------------------------------------------------------------------- #
_detector_instance = None
_classifier_instance = None

_WRONG_SUBJECT_BLOCKLIST = frozenset([
    'animal', 'dog', 'cat', 'wolf', 'bird', 'fish', 'horse', 'elephant', 'bear', 'lion', 'tiger', 'pet',
    'person', 'man', 'woman', 'child', 'people', 'face', 'portrait',
    'vehicle', 'car', 'truck', 'bus', 'bicycle', 'motorcycle', 'airplane', 'boat',
    'food', 'pizza', 'burger', 'fruit', 'vegetable', 'meal', 'dish', 'cake', 'bread',
    'furniture', 'chair', 'table', 'sofa', 'bed', 'desk', 'couch', 'lamp',
    'room', 'bedroom', 'living room', 'office', 'kitchen', 'bathroom', 'indoor', 'interior',
    'outdoor', 'nature', 'tree', 'grass', 'sky', 'landscape', 'garden', 'flower',
    'sport', 'game', 'ball', 'player',
    'electronic', 'phone', 'computer', 'screen', 'tv', 'monitor', 'laptop', 'keyboard', 'mouse',
    'clothing', 'shirt', 'dress', 'shoe', 'hat',
    'logo', 'symbol', 'icon', 'graphic', 'sign', 'text', 'letter',
])
_EVIDENCE_ALLOWLIST = frozenset([
    'pipe', 'drain', 'plumb', 'pump', 'tank', 'heater', 'coil', 'duct', 'vent', 'valve',
    'machine', 'mechanical', 'motor', 'engine', 'equipment', 'appliance',
    'boiler', 'furnace', 'condenser', 'evaporator', 'air conditioner', 'hvac',
    'wall', 'foundation', 'concrete', 'crack', 'metal', 'copper', 'pvc',
    'basin', 'sink', 'faucet', 'stainless', 'water',
])


def _get_mediapipe_image_classifier():
    global _classifier_instance
    if _classifier_instance is not None:
        return _classifier_instance
    try:
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision
        base = getattr(settings, 'MEDIAPIPE_IMAGE_CLASSIFIER_MODEL', None)
        if base and Path(base).exists():
            opts = vision.ImageClassifierOptions(
                base_options=mp_python.BaseOptions(model_asset_path=base),
                max_results=10,
                score_threshold=0.01,
            )
            _classifier_instance = vision.ImageClassifier.create_from_options(opts)
            return _classifier_instance
    except Exception:
        pass
    return None


def _wrong_subject_from_classifier(img_np):
    classifier = _get_mediapipe_image_classifier()
    if classifier is None:
        return None
    try:
        from mediapipe.tasks.python import vision
        mp_image = vision.Image(image_format=vision.ImageFormat.SRGB, data=img_np)
        result = classifier.classify(mp_image)
        classifications = getattr(result, 'classifications', None) or getattr(result, 'classification_result', None)
        if not classifications or len(classifications) == 0:
            return None
        categories = getattr(classifications[0], 'categories', [])[:10]
        labels = []
        for c in categories:
            name = (getattr(c, 'category_name', None) or getattr(c, 'display_name', None) or str(getattr(c, 'index', ''))).strip()
            if name and not name.isdigit():
                labels.append(name.lower())
        if not labels:
            return None
        has_blocklist = any(any(b in label for b in _WRONG_SUBJECT_BLOCKLIST) for label in labels)
        has_allowlist = any(any(a in label for a in _EVIDENCE_ALLOWLIST) for label in labels)
        if has_blocklist and not has_allowlist:
            return (True, f'Image content does not appear to show required evidence (classifier: {labels[0][:50]}).')
        return (False, None)
    except Exception:
        return None


def _get_mediapipe_detector():
    global _detector_instance
    if _detector_instance is not None:
        return _detector_instance
    try:
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision
        base = getattr(settings, 'MEDIAPIPE_OBJECT_DETECTOR_MODEL', None)
        if base and Path(base).exists():
            opts = vision.ObjectDetectorOptions(
                base_options=mp_python.BaseOptions(model_asset_path=base),
                score_threshold=0.3,
                max_results=20,
            )
            _detector_instance = vision.ObjectDetector.create_from_options(opts)
            return _detector_instance
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------- #
#  Image helpers
# --------------------------------------------------------------------------- #

def _load_image_numpy(path):
    img = Image.open(Path(path))
    img = ImageOps.exif_transpose(img)
    if img.mode != 'RGB':
        img = img.convert('RGB')
    return np.array(img)


def _blur_score_gray(img_np):
    """Laplacian variance — lower = more blur."""
    if img_np.ndim == 3:
        gray = np.dot(img_np[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)
    else:
        gray = img_np
    kernel = np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=np.float32)
    h, w = gray.shape
    padded = np.pad(gray.astype(np.float32), 1, mode='edge')
    lap = np.zeros_like(gray, dtype=np.float32)
    for i in range(3):
        for j in range(3):
            lap += kernel[i, j] * padded[i:i + h, j:j + w]
    return float(np.var(lap))


def _brightness_mean(img_np):
    return float(np.mean(img_np))


def _unique_color_count(img_np):
    if img_np.ndim != 3 or img_np.shape[2] != 3:
        return 0
    h, w = img_np.shape[:2]
    step = max(1, int((h * w) ** 0.5 / 450))
    sample = img_np[::step, ::step].reshape(-1, 3).astype(np.uint32)
    q = (sample // 32) & 0xFF
    packed = (q[:, 0] << 16) | (q[:, 1] << 8) | q[:, 2]
    return len(np.unique(packed))


def _heuristic_wrong_subject(img_np):
    """Very low color diversity = logo / silhouette / graphic (not a real photo)."""
    n = _unique_color_count(img_np)
    return n > 0 and n <= 32


# --------------------------------------------------------------------------- #
#  Heuristics-only path (fallback)
# --------------------------------------------------------------------------- #

def _run_heuristics(img_np, payload, req_list, blur_var, brightness):
    """
    Build the full analysis result dict using only local heuristics.
    Used when Vertex AI is disabled or unavailable.
    """
    issues = []

    wrong_subject = _heuristic_wrong_subject(img_np)
    wrong_subject_msg = 'Image does not appear to show the required evidence (possible logo, graphic, or wrong photo).'

    classifier_result = _wrong_subject_from_classifier(img_np)
    if classifier_result is not None:
        is_wrong, msg = classifier_result
        if is_wrong:
            wrong_subject = True
            wrong_subject_msg = msg or wrong_subject_msg

    if wrong_subject:
        issues.append({'type': 'wrong_subject', 'severity': 'high', 'message': wrong_subject_msg})

    blur_threshold = 150.0
    if blur_var < blur_threshold:
        issues.append({
            'type': 'blur',
            'severity': 'medium' if blur_var < 80 else 'low',
            'message': 'Image may be blurry; ensure clear focus.',
        })
    if brightness < 60:
        issues.append({'type': 'low_light', 'severity': 'medium', 'message': 'Image too dark.'})
    elif brightness > 220:
        issues.append({'type': 'glare', 'severity': 'low', 'message': 'Image very bright; possible glare.'})

    overlays = _mediapipe_detections_to_overlays(img_np)

    checks, missing = _build_checks(req_list, wrong_subject, blur_var, blur_threshold, brightness, issues)

    required_count = sum(1 for r in req_list if r.get('required', True))
    required_met = required_count - len(missing)
    overall_score = round(sum(c['score'] for c in checks) / max(len(checks), 1), 2)
    confidence = round(max(0.0, min(1.0, 0.85 - (0.2 if issues else 0))), 2)

    if missing:
        decision = 'needs_action'
        review_decision = 'retry_photo'
        required_actions = [{'action': 'retake_photo', 'reason': f'Required evidence not clearly visible: {", ".join(missing)}.'}]
        review_notes = 'Retake with required elements fully visible and adequate lighting.'
    else:
        decision = 'pass'
        review_decision = 'accept'
        required_actions = []
        review_notes = 'Evidence meets requirements.'

    summary_parts = ['; '.join(i['message'] for i in issues[:3])] if issues else ['Image quality acceptable.']
    if missing:
        summary_parts.append(f'Missing or unclear: {", ".join(missing)}.')
    summary = ' '.join(summary_parts)

    return {
        'decision': decision,
        'overall_score': overall_score,
        'confidence': confidence,
        'summary': summary,
        'issues': issues,
        'overlays': overlays,
        'checks': checks,
        'review_decision': review_decision,
        'required_actions': required_actions,
        'review_notes': review_notes,
        'required_count': required_count,
        'required_met': required_met,
        'missing': missing,
    }




def _build_checks(req_list, wrong_subject, blur_var, blur_threshold, brightness, issues):
    """Build per-requirement check list and missing list from heuristic signals."""
    checks = []
    missing = []
    for req in req_list:
        rid = req.get('id', '')
        label = req.get('label', rid)
        required = req.get('required', True)
        if wrong_subject:
            score = 0.2
            passed = False
            notes = 'Image does not appear to show the required evidence.'
        else:
            score = 0.85
            if blur_var < blur_threshold:
                score -= 0.3
            if brightness < 60 or brightness > 220:
                score -= 0.2
            score = max(0.0, min(1.0, score))
            passed = score >= 0.5
            notes = '; '.join(i.get('message', '') for i in issues[:2]) if issues else None
        if required and not passed:
            missing.append(rid)
        checks.append({
            'id': rid,
            'label': label,
            'required': required,
            'passed': passed,
            'score': round(score, 2),
            **(({'notes': notes} if notes else {})),
        })
    return checks, missing


# --------------------------------------------------------------------------- #
#  Gemini-path helpers
# --------------------------------------------------------------------------- #

def _merge_heuristic_issues(gemini_issues, blur_var, brightness):
    """
    Add blur / low_light / glare issues from heuristics if Gemini missed them.
    Heuristics are a belt-and-suspenders check for clear objective signals.
    """
    existing_types = {i.get('type') for i in gemini_issues}
    extra = []
    if blur_var < 150.0 and 'blur' not in existing_types:
        extra.append({
            'type': 'blur',
            'severity': 'medium' if blur_var < 80 else 'low',
            'message': 'Image may be blurry; ensure clear focus.',
        })
    if brightness < 60 and 'low_light' not in existing_types:
        extra.append({'type': 'low_light', 'severity': 'medium', 'message': 'Image too dark.'})
    elif brightness > 220 and 'glare' not in existing_types:
        extra.append({'type': 'glare', 'severity': 'low', 'message': 'Image very bright; possible glare.'})
    return gemini_issues + extra


def _gemini_objects_to_overlays(objects):
    """Convert Gemini object list → SOW §6.4 overlay list (normalized [0,1] coords, shape=bbox)."""
    overlays = []
    for obj in objects:
        overlays.append({
            'shape': 'bbox',
            'label': obj['label'],
            'x': round(obj['x'], 4),
            'y': round(obj['y'], 4),
            'w': round(obj['w'], 4),
            'h': round(obj['h'], 4),
            'confidence': round(obj['confidence'], 2),
            'color': None,
        })
    return overlays


def _mediapipe_detections_to_overlays(img_np):
    """Run MediaPipe object detector if configured; return SOW §6.4 overlay list."""
    overlays = []
    detector = _get_mediapipe_detector()
    if detector is None:
        return overlays
    try:
        from mediapipe.tasks.python import vision
        mp_image = vision.Image(image_format=vision.ImageFormat.SRGB, data=img_np)
        detections = detector.detect(mp_image)
        if detections and hasattr(detections, 'detections'):
            for d in detections.detections[:15]:
                if not hasattr(d, 'bounding_box') or not hasattr(d, 'categories'):
                    continue
                bbox = d.bounding_box
                x = getattr(bbox, 'origin_x', 0) / max(img_np.shape[1], 1)
                y = getattr(bbox, 'origin_y', 0) / max(img_np.shape[0], 1)
                w = getattr(bbox, 'width', 0) / max(img_np.shape[1], 1)
                h = getattr(bbox, 'height', 0) / max(img_np.shape[0], 1)
                label = 'object'
                conf = 0.5
                if d.categories:
                    cat = d.categories[0]
                    label = getattr(cat, 'category_name', None) or getattr(cat, 'display_name', 'object')
                    conf = getattr(cat, 'score', 0.5) or 0.5
                overlays.append({
                    'shape': 'bbox',
                    'label': label,
                    'x': round(x, 4),
                    'y': round(y, 4),
                    'w': round(w, 4),
                    'h': round(h, 4),
                    'confidence': round(conf, 2),
                    'color': None,
                })
    except Exception:
        pass
    return overlays


def _enrich_checks_with_requirements(gemini_checks, req_list):
    """
    Ensure every requirement from req_list has a check entry.
    Gemini may return checks only for requirements it was given; we fill gaps.
    """
    by_id = {c['id']: c for c in gemini_checks}
    result = []
    for req in req_list:
        rid = req.get('id', '')
        label = req.get('label', rid)
        required = req.get('required', True)
        if rid in by_id:
            chk = dict(by_id[rid])
            chk.setdefault('label', label)
            chk.setdefault('required', required)
            result.append(chk)
        else:
            # Gemini didn't return a check for this requirement — derive from decision
            result.append({
                'id': rid,
                'label': label,
                'required': required,
                'passed': False,
                'score': 0.0,
                'notes': 'Not evaluated by model.',
            })
    return result


# --------------------------------------------------------------------------- #
#  Public entry point
# --------------------------------------------------------------------------- #

def run_analysis(image_path, payload):
    """
    Run the full analysis pipeline and return a contract-compliant result dict.
    """
    from .validation import validate_image_from_path
    from .vertex_ai import analyze_with_gemini

    request_id = payload.get('request_id', '')
    job_id = payload.get('job_id', '')
    step_id = payload.get('step_id', '')
    evidence_id = payload.get('evidence_id', '')
    evidence_label = payload.get('evidence_label', '')
    requirement_ids = payload.get('requirement_ids') or []
    requirements = payload.get('requirements') or []

    created_at = payload.get('created_at') or datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    updated_at = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')

    # Validate image from path (resolution etc.)
    try:
        img_pil, long_edge = validate_image_from_path(image_path)
    except Exception as e:
        return {
            'request_id': request_id,
            'job_id': job_id,
            'step_id': step_id,
            'evidence_id': evidence_id,
            'evidence_label': evidence_label,
            'status': 'failed',
            'error': {'code': getattr(e, 'code', 'INVALID_IMAGE'), 'message': str(e)},
            'timestamps': {'created_at': created_at, 'updated_at': updated_at},
        }

    img_np = np.array(img_pil.convert('RGB'))

    # Always run fast local heuristics (blur, brightness) — used in both paths
    blur_var = _blur_score_gray(img_np)
    brightness = _brightness_mean(img_np)

    # Build requirement list (used by both Gemini prompt and contract response)
    req_list = list(requirements)
    if not req_list and requirement_ids:
        for rid in requirement_ids:
            req_list.append({'id': rid, 'label': rid.replace('_', ' ').title(), 'required': True, 'type': 'photo'})

    # ------------------------------------------------------------------ #
    #  Primary path: Vertex AI / Gemini
    # ------------------------------------------------------------------ #
    # Pass expanded requirements so Gemini returns one check per requirement
    gemini_payload = {**payload, 'requirements': req_list}
    gemini_result = analyze_with_gemini(image_path, gemini_payload)

    if gemini_result is not None:
        issues = _merge_heuristic_issues(gemini_result['issues'], blur_var, brightness)
        overlays = _gemini_objects_to_overlays(gemini_result['objects'])

        # Enrich checks: ensure every req_list entry has a check
        raw_checks = gemini_result['checks']
        if req_list:
            checks = _enrich_checks_with_requirements(raw_checks, req_list)
        else:
            checks = [
                {
                    'id': c['id'],
                    'label': c.get('label', c['id']),
                    'required': c.get('required', True),
                    'passed': c['passed'],
                    'score': c['score'],
                    **(({'notes': c['notes']} if c.get('notes') else {})),
                }
                for c in raw_checks
            ]

        missing = [c['id'] for c in checks if c.get('required', True) and not c.get('passed', False)]
        required_count = sum(1 for c in checks if c.get('required', True))
        required_met = required_count - len(missing)

        # Derive decision and review from checks so response is consistent
        # (Gemini can return decision=pass but checks passed=false; we override by outcome)
        if missing:
            decision = 'needs_action' if gemini_result['decision'] == 'pass' else gemini_result['decision']
            review_decision = 'retry_photo'
            required_actions = list(gemini_result['required_actions']) if gemini_result.get('required_actions') else []
            if not required_actions:
                required_actions = [{'action': 'retake_photo', 'reason': f'Required evidence not clearly visible: {", ".join(missing)}.'}]
            review_notes = gemini_result.get('notes') or 'Retake with required elements fully visible and adequate lighting.'
        else:
            decision = gemini_result['decision']
            review_decision = gemini_result['review_decision']
            required_actions = gemini_result.get('required_actions') or []
            review_notes = gemini_result.get('notes') or 'Evidence meets requirements.'

        if checks:
            overall_score = round(sum(c['score'] for c in checks) / len(checks), 2)
        else:
            overall_score = gemini_result['overall_score']
        confidence = gemini_result['confidence']
        summary = gemini_result['summary']

        analysis_model = f"gemini/{getattr(settings, 'VERTEX_AI_MODEL', 'gemini-2.0-flash')}"

    else:
        # ------------------------------------------------------------------ #
        #  Fallback path: heuristics only
        # ------------------------------------------------------------------ #
        logger.info("Using heuristics fallback for request_id=%s", request_id)
        h = _run_heuristics(img_np, payload, req_list, blur_var, brightness)

        issues = h['issues']
        overlays = h['overlays']
        checks = h['checks']
        missing = h['missing']
        required_count = h['required_count']
        required_met = h['required_met']
        decision = h['decision']
        review_decision = h['review_decision']
        required_actions = h['required_actions']
        review_notes = h['review_notes']
        overall_score = h['overall_score']
        confidence = h['confidence']
        summary = h['summary']
        analysis_model = 'vision-v2'

    correlation_id = payload.get('correlation_id', '')

    return {
        'request_id': request_id,
        'correlation_id': correlation_id,
        'job_id': job_id,
        'step_id': step_id,
        'evidence_id': evidence_id,
        'evidence_label': evidence_label,
        'playbook_id': payload.get('playbook_id'),
        'status': 'complete',
        'analysis': {
            'model': analysis_model,
            'overall_score': overall_score,
            'confidence': confidence,
            'decision': decision,
            'summary': summary,
            'checks': checks,
            'issues': issues,
            'overlays': overlays,
        },
        'review': {
            'status': 'needs_action' if missing else 'pass',
            'decision': review_decision,
            'required_actions': required_actions,
            'notes': review_notes,
        },
        'requirements': {
            'required_count': required_count,
            'required_met': required_met,
            'missing': missing,
        },
        'timestamps': {
            'created_at': created_at,
            'updated_at': updated_at,
        },
    }
