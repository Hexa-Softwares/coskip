import logging

from django.apps import AppConfig
from django.db import IntegrityError, OperationalError

logger = logging.getLogger(__name__)


class ImageAnalysisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'image_analysis'
    verbose_name = 'Image Analysis'

    def ready(self):
        from .services.vertex_ai import warmup_vertex_ai
        warmup_vertex_ai()
        self._bootstrap_api_key()

    def _bootstrap_api_key(self):
        from django.conf import settings

        raw = getattr(settings, 'BOOTSTRAP_API_KEY', '') or ''
        if not raw:
            return
        from .models import APIKey

        try:
            APIKey.objects.get_or_create(
                key=raw,
                defaults={'name': 'BOOTSTRAP_API_KEY', 'is_active': True},
            )
        except OperationalError as exc:
            # migrate runs django.setup() before tables exist → ready() must not crash.
            # Gunicorn loads after migrate; second ready() succeeds.
            err = str(exc).lower()
            if 'no such table' in err or 'does not exist' in err:
                logger.info('BOOTSTRAP_API_KEY skipped (migrations not applied yet).')
                return
            raise
        except IntegrityError:
            # Two Gunicorn workers boot concurrently → SQLite unique races.
            logger.warning(
                'BOOTSTRAP_API_KEY race skipped (key probably inserted by other worker).'
            )
