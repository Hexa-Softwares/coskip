import threading
import time
import uuid

from django.conf import settings
from django.http import JsonResponse


_LOCAL = threading.local()


def get_current_correlation_id() -> str:
    return getattr(_LOCAL, 'correlation_id', '')


class CorrelationIdMiddleware:
    """
    Reads X-Correlation-Id from the inbound request (set by the Node proxy)
    or generates a new one, attaches it to thread-local storage, and echoes
    it back in the response header.
    """
    HEADER = 'X-Correlation-Id'
    META_KEY = 'HTTP_X_CORRELATION_ID'

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        correlation_id = request.META.get(self.META_KEY) or f'corr_{uuid.uuid4().hex[:16]}'
        _LOCAL.correlation_id = correlation_id
        request.correlation_id = correlation_id

        response = self.get_response(request)
        response[self.HEADER] = correlation_id
        return response


_rate_store: dict[str, list[float]] = {}
_rate_lock = threading.Lock()


def _parse_rate(rate_str: str) -> tuple[int, int]:
    """Parse 'N/S' (N requests per S seconds). Returns (requests, window_seconds)."""
    try:
        parts = rate_str.split('/')
        return int(parts[0]), int(parts[1])
    except Exception:
        return 60, 60


def _endpoint_group(path: str) -> str:
    if '/voice/' in path:
        return 'voice'
    if '/assist/' in path:
        return 'assist'
    if '/evidence-analyses' in path or '/image-analysis' in path:
        return 'image_analysis'
    return 'default'


def _get_client_ip(request) -> str:
    forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
    if forwarded:
        return forwarded.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR', '0.0.0.0')


class RateLimitMiddleware:
    """
    Simple sliding-window rate limiter keyed by (client_ip, endpoint_group).
    Only active when RATE_LIMIT_* settings are present.
    Uses in-process memory — suitable for single-process deployments.
    For multi-process/Gunicorn, replace with Redis-backed django-ratelimit.
    """

    _RATE_SETTING_MAP = {
        'image_analysis': 'RATE_LIMIT_IMAGE_ANALYSIS',
        'voice': 'RATE_LIMIT_VOICE',
        'assist': 'RATE_LIMIT_ASSIST',
        'default': 'RATE_LIMIT_IMAGE_ANALYSIS',
    }

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/admin') or request.path.startswith('/static'):
            return self.get_response(request)

        if request.method == 'GET' and any(
            p in request.path for p in ['/inbox', '/audit', '/voice/commands/', '/evidence-analyses/']
        ):
            return self.get_response(request)

        group = _endpoint_group(request.path)
        setting_name = self._RATE_SETTING_MAP.get(group, 'RATE_LIMIT_IMAGE_ANALYSIS')
        rate_str = getattr(settings, setting_name, '60/60')
        max_requests, window_seconds = _parse_rate(rate_str)

        client_ip = _get_client_ip(request)
        key = f'{client_ip}:{group}'
        now = time.time()
        window_start = now - window_seconds

        with _rate_lock:
            timestamps = _rate_store.get(key, [])
            timestamps = [t for t in timestamps if t > window_start]
            if len(timestamps) >= max_requests:
                return JsonResponse(
                    {
                        'error': {
                            'code': 'RATE_LIMIT_EXCEEDED',
                            'message': f'Too many requests. Limit: {max_requests} per {window_seconds}s.',
                        }
                    },
                    status=429,
                )
            timestamps.append(now)
            _rate_store[key] = timestamps

        return self.get_response(request)
