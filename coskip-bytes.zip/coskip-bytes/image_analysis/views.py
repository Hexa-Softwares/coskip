import json
import time
import uuid
from datetime import datetime, timezone

from django.shortcuts import get_object_or_404
from django.utils import timezone as dj_timezone
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import (
    AnalysisRequest, VoiceCommandLog, AssistRequest,
    DecisionOverride, AuditEvent, AlertItem,
    generate_correlation_id,
)
from .serializers import (
    ImageAnalysisPayloadSerializer,
    VoiceCommandSubmitSerializer,
    AssistAnalyzeSerializer,
    DecisionOverrideSerializer,
)
from .services import (
    validate_image_file,
    validate_image_from_path,
    save_uploaded_image,
    fetch_image_from_url,
    run_analysis,
    ValidationError,
)
from .services.voice import process_voice_command
from .services.assist import get_assist_guidance


def _error_response(request_id, code, message, status_code=400, correlation_id=None):
    return Response(
        {
            'request_id': request_id or 'unknown',
            'correlation_id': correlation_id or '',
            'status': 'failed',
            'error': {'code': code, 'message': message},
        },
        status=status_code,
    )


def _now_iso():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def _get_or_create_correlation_id(request):
    """Return X-Correlation-Id header value or generate a new one."""
    return request.headers.get('X-Correlation-Id') or generate_correlation_id()


def _write_audit_event(
    feature, action, entity_type, entity_id,
    actor_user_id=None, actor_role=None,
    before_json=None, after_json=None,
    reason_code=None, reason_text='',
    correlation_id=None, tenant_id=None,
):
    try:
        AuditEvent.objects.create(
            tenant_id=tenant_id,
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            feature=feature,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            before_json=before_json,
            after_json=after_json,
            reason_code=reason_code,
            reason_text=reason_text or '',
            correlation_id=correlation_id or generate_correlation_id(),
        )
    except Exception:
        pass  # Audit must never break the main flow


def _build_payload(data, request_id=None, correlation_id=None):
    payload = dict(data)
    payload['request_id'] = request_id
    payload['correlation_id'] = correlation_id or ''
    payload['created_at'] = _now_iso()
    return payload


class ImageAnalysisSubmitView(APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        correlation_id = _get_or_create_correlation_id(request)

        # Idempotency check
        raw_payload = request.data.get('payload')
        idempotency_key = (
            request.data.get('idempotency_key')
            or (raw_payload and self._payload_idempotency(raw_payload))
        )
        if idempotency_key:
            existing = AnalysisRequest.objects.filter(idempotency_key=idempotency_key).first()
            if existing:
                if existing.status == 'complete' and existing.result:
                    return Response(existing.result, status=status.HTTP_200_OK)
                return Response(
                    {
                        'request_id': existing.request_id,
                        'correlation_id': existing.correlation_id,
                        'status': existing.status,
                        'received_at': existing.created_at.isoformat().replace('+00:00', 'Z'),
                        'estimated_seconds': 5,
                    },
                    status=status.HTTP_202_ACCEPTED,
                )

        # Parse multipart or JSON input
        image_file = request.FILES.get('image')
        image_url = (
            request.data.get('image_url')
            if request.content_type and 'json' in request.content_type
            else None
        )
        payload_raw = request.data.get('payload')

        if image_file:
            if payload_raw is None:
                return _error_response(
                    None, 'INVALID_REQUEST',
                    'Multipart request must include "payload" (JSON string).',
                    400, correlation_id,
                )
            try:
                payload_data = json.loads(payload_raw) if isinstance(payload_raw, str) else dict(payload_raw)
            except (json.JSONDecodeError, TypeError):
                return _error_response(None, 'INVALID_REQUEST', 'Invalid JSON in payload.', 400, correlation_id)
        elif image_url:
            payload_data = {k: v for k, v in request.data.items() if k != 'image_url'}
            if 'payload' in payload_data and isinstance(payload_data['payload'], dict) and 'job_id' not in payload_data:
                payload_data = payload_data['payload']
        else:
            return _error_response(
                None, 'INVALID_REQUEST',
                'Provide either multipart (image + payload) or JSON with image_url and metadata.',
                400, correlation_id,
            )

        serializer = ImageAnalysisPayloadSerializer(data=payload_data)
        if not serializer.is_valid():
            return Response(
                {
                    'request_id': 'unknown',
                    'correlation_id': correlation_id,
                    'status': 'failed',
                    'error': {'code': 'INVALID_REQUEST', 'message': str(serializer.errors)},
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
        payload_data = serializer.validated_data

        # Create DB record
        record = AnalysisRequest(
            correlation_id=correlation_id,
            tenant_id=payload_data.get('tenant_id') or '',
            job_id=payload_data['job_id'],
            step_id=payload_data['step_id'],
            step_title=payload_data.get('step_title') or '',
            evidence_id=payload_data.get('evidence_id') or '',
            evidence_label=payload_data['evidence_label'],
            evidence_type=payload_data.get('evidence_type') or '',
            playbook_id=payload_data.get('playbook_id') or '',
            playbook_requirement_ids=payload_data.get('playbook_requirement_ids') or [],
            payload=payload_data,
            idempotency_key=payload_data.get('idempotency_key'),
        )
        record.save()
        request_id = record.request_id

        # Validate + save image
        if image_file:
            try:
                validate_image_file(image_file)
            except ValidationError as e:
                record.status = AnalysisRequest.Status.FAILED
                record.error = {'code': e.code, 'message': e.message}
                record.save()
                return _error_response(request_id, e.code, e.message, 400, correlation_id)
            try:
                image_path = save_uploaded_image(image_file)
            except Exception as e:
                record.status = AnalysisRequest.Status.FAILED
                record.error = {'code': 'INVALID_IMAGE', 'message': str(e)}
                record.save()
                return _error_response(request_id, 'INVALID_IMAGE', str(e), 400, correlation_id)
        elif image_url:
            try:
                image_path = fetch_image_from_url(image_url)
                validate_image_from_path(image_path)
            except ValidationError as e:
                record.status = AnalysisRequest.Status.FAILED
                record.error = {'code': e.code, 'message': e.message}
                record.save()
                return _error_response(request_id, e.code, e.message, 400, correlation_id)
            except Exception as e:
                record.status = AnalysisRequest.Status.FAILED
                record.error = {'code': 'INVALID_IMAGE', 'message': str(e)}
                record.save()
                return _error_response(request_id, 'INVALID_IMAGE', str(e), 400, correlation_id)
        else:
            return _error_response(request_id, 'INVALID_REQUEST', 'Missing image file or image_url.', 400, correlation_id)

        record.image_path = image_path
        record.save()

        full_payload = _build_payload(payload_data, request_id=request_id, correlation_id=correlation_id)
        full_payload['created_at'] = record.created_at.isoformat().replace('+00:00', 'Z')

        # Run analysis (sync or inline-async)
        record.status = AnalysisRequest.Status.PROCESSING
        record.save()
        result = run_analysis(image_path, full_payload)

        if result.get('status') == 'failed':
            record.status = AnalysisRequest.Status.FAILED
            record.error = result.get('error', {})
            record.save()
        else:
            record.result = result
            record.status = AnalysisRequest.Status.COMPLETE
            record.save()

            # Auto-create alert for failed/needs_action
            decision = (result.get('analysis') or {}).get('decision')
            if decision in ('fail', 'needs_action'):
                AlertItem.objects.create(
                    tenant_id=record.tenant_id,
                    severity='high' if decision == 'fail' else 'medium',
                    alert_type='evidence_analysis_failed' if decision == 'fail' else 'evidence_needs_action',
                    feature_type='evidence_analysis',
                    analysis_request=record,
                    subject_type='evidence',
                    subject_id=record.evidence_id or record.evidence_label,
                    recommended_action='Review evidence and retake photo if required.',
                )

        sync = payload_data.get('sync', False)
        if sync or result.get('status') == 'failed':
            return Response(result, status=status.HTTP_200_OK)

        return Response(
            {
                'request_id': request_id,
                'correlation_id': correlation_id,
                'status': 'queued',
                'received_at': record.created_at.isoformat().replace('+00:00', 'Z'),
                'estimated_seconds': 5,
            },
            status=status.HTTP_202_ACCEPTED,
        )

    def _payload_idempotency(self, payload):
        if isinstance(payload, str):
            try:
                return json.loads(payload).get('idempotency_key')
            except Exception:
                return None
        return payload.get('idempotency_key') if isinstance(payload, dict) else None


class ImageAnalysisResultView(APIView):
    def get(self, request, request_id):
        record = get_object_or_404(AnalysisRequest, request_id=request_id)
        if record.status == 'complete' and record.result:
            return Response(record.result, status=status.HTTP_200_OK)
        if record.status == 'failed' and record.error:
            return Response(
                {
                    'request_id': record.request_id,
                    'correlation_id': record.correlation_id,
                    'status': 'failed',
                    'error': record.error,
                },
                status=status.HTTP_200_OK,
            )
        return Response(
            {
                'request_id': record.request_id,
                'correlation_id': record.correlation_id,
                'status': record.status,
                'job_id': record.job_id,
                'step_id': record.step_id,
                'evidence_id': record.evidence_id,
                'evidence_label': record.evidence_label,
                'received_at': record.created_at.isoformat().replace('+00:00', 'Z'),
                'estimated_seconds': 5,
            },
            status=status.HTTP_200_OK,
        )


class EvidenceAnalysisRetryView(APIView):
    """POST /api/v1/evidence-analyses/<request_id>/retry"""

    def post(self, request, request_id):
        correlation_id = _get_or_create_correlation_id(request)
        record = get_object_or_404(AnalysisRequest, request_id=request_id)

        if record.retry_count >= 3:
            return Response(
                {
                    'request_id': request_id,
                    'correlation_id': correlation_id,
                    'error': {'code': 'MAX_RETRIES_EXCEEDED', 'message': 'Maximum of 3 retries allowed.'},
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not record.image_path:
            return Response(
                {
                    'request_id': request_id,
                    'correlation_id': correlation_id,
                    'error': {'code': 'NO_IMAGE', 'message': 'No stored image to retry analysis on.'},
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        before = dict(record.result or {})
        record.retry_count += 1
        record.status = AnalysisRequest.Status.PROCESSING
        record.save()

        full_payload = dict(record.payload or {})
        full_payload['request_id'] = record.request_id
        full_payload['correlation_id'] = correlation_id
        full_payload['created_at'] = record.created_at.isoformat().replace('+00:00', 'Z')

        result = run_analysis(record.image_path, full_payload)

        if result.get('status') == 'failed':
            record.status = AnalysisRequest.Status.FAILED
            record.error = result.get('error', {})
        else:
            record.result = result
            record.status = AnalysisRequest.Status.COMPLETE
        record.save()

        _write_audit_event(
            feature='evidence_analysis', action='retry',
            entity_type='analysis_request', entity_id=request_id,
            actor_user_id=request.data.get('actor_user_id'),
            before_json=before, after_json=result,
            correlation_id=correlation_id,
        )

        return Response(result, status=status.HTTP_200_OK)


class EvidenceAnalysisOverrideView(APIView):
    """POST /api/v1/evidence-analyses/<request_id>/override"""

    def post(self, request, request_id):
        correlation_id = _get_or_create_correlation_id(request)
        record = get_object_or_404(AnalysisRequest, request_id=request_id)

        serializer = DecisionOverrideSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {'error': {'code': 'INVALID_REQUEST', 'message': str(serializer.errors)}},
                status=status.HTTP_400_BAD_REQUEST,
            )
        data = serializer.validated_data

        previous_decision = (record.result or {}).get('analysis', {}).get('decision') or record.status

        override = DecisionOverride.objects.create(
            analysis_request=record,
            playbook_requirement_id=data.get('playbook_requirement_id'),
            previous_decision=previous_decision,
            new_decision=data['new_decision'],
            reason_code=data['reason_code'],
            reason_text=data.get('reason_text', ''),
            actor_user_id=data['actor_user_id'],
            actor_role=data.get('actor_role', 'ops'),
            correlation_id=correlation_id,
        )

        _write_audit_event(
            feature='evidence_analysis', action='override',
            entity_type='analysis_request', entity_id=request_id,
            actor_user_id=data['actor_user_id'],
            actor_role=data.get('actor_role', 'ops'),
            before_json={'decision': previous_decision},
            after_json={'decision': data['new_decision']},
            reason_code=data['reason_code'],
            reason_text=data.get('reason_text', ''),
            correlation_id=correlation_id,
        )

        # Close related open alerts when overriding to pass
        if data['new_decision'] == 'pass':
            AlertItem.objects.filter(
                analysis_request=record, status=AlertItem.Status.OPEN
            ).update(status=AlertItem.Status.RESOLVED, closed_at=dj_timezone.now())

        return Response(
            {
                'override_id': override.override_id,
                'correlation_id': correlation_id,
                'request_id': request_id,
                'previous_decision': previous_decision,
                'new_decision': data['new_decision'],
                'reason_code': data['reason_code'],
                'created_at': override.created_at.isoformat().replace('+00:00', 'Z'),
            },
            status=status.HTTP_201_CREATED,
        )


class InboxView(APIView):
    """GET /api/v1/inbox — return open alerts needing ops/admin attention."""

    def get(self, request):
        correlation_id = _get_or_create_correlation_id(request)
        tenant_id = request.query_params.get('tenant_id')
        severity = request.query_params.get('severity')
        feature_type = request.query_params.get('feature_type')
        limit = min(int(request.query_params.get('limit', 50)), 200)

        qs = AlertItem.objects.filter(status=AlertItem.Status.OPEN).select_related('analysis_request')
        if tenant_id:
            qs = qs.filter(tenant_id=tenant_id)
        if severity:
            qs = qs.filter(severity=severity)
        if feature_type:
            qs = qs.filter(feature_type=feature_type)
        qs = qs.order_by('-opened_at')[:limit]

        items = []
        for alert in qs:
            request_id = alert.analysis_request.request_id if alert.analysis_request else None
            items.append({
                'alert_id': alert.alert_id,
                'severity': alert.severity,
                'status': alert.status,
                'alert_type': alert.alert_type,
                'feature_type': alert.feature_type,
                'request_id': request_id,
                'subject_type': alert.subject_type,
                'subject_id': alert.subject_id,
                'recommended_action': alert.recommended_action,
                'opened_at': alert.opened_at.isoformat().replace('+00:00', 'Z'),
                'links': {
                    'analysis': f'/api/v1/evidence-analyses/{request_id}' if request_id else None,
                    'override': f'/api/v1/evidence-analyses/{request_id}/override' if request_id else None,
                    'retry': f'/api/v1/evidence-analyses/{request_id}/retry' if request_id else None,
                },
            })

        return Response(
            {
                'correlation_id': correlation_id,
                'count': len(items),
                'items': items,
            },
            status=status.HTTP_200_OK,
        )


class AuditView(APIView):
    """GET /api/v1/audit — immutable audit event log."""

    def get(self, request):
        correlation_id = _get_or_create_correlation_id(request)
        tenant_id = request.query_params.get('tenant_id')
        entity_type = request.query_params.get('entity_type')
        entity_id = request.query_params.get('entity_id')
        feature = request.query_params.get('feature')
        limit = min(int(request.query_params.get('limit', 50)), 500)

        qs = AuditEvent.objects.all()
        if tenant_id:
            qs = qs.filter(tenant_id=tenant_id)
        if entity_type:
            qs = qs.filter(entity_type=entity_type)
        if entity_id:
            qs = qs.filter(entity_id=entity_id)
        if feature:
            qs = qs.filter(feature=feature)
        qs = qs.order_by('-created_at')[:limit]

        events = []
        for ev in qs:
            events.append({
                'audit_event_id': ev.audit_event_id,
                'tenant_id': ev.tenant_id,
                'actor_user_id': ev.actor_user_id,
                'actor_role': ev.actor_role,
                'feature': ev.feature,
                'action': ev.action,
                'entity_type': ev.entity_type,
                'entity_id': ev.entity_id,
                'reason_code': ev.reason_code,
                'correlation_id': ev.correlation_id,
                'created_at': ev.created_at.isoformat().replace('+00:00', 'Z'),
            })

        return Response(
            {
                'correlation_id': correlation_id,
                'count': len(events),
                'events': events,
            },
            status=status.HTTP_200_OK,
        )


class VoiceCommandSubmitView(APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        correlation_id = _get_or_create_correlation_id(request)

        audio_file = request.FILES.get('audio')
        if not audio_file:
            return Response(
                {
                    'error': {
                        'code': 'MISSING_AUDIO',
                        'message': 'Multipart field "audio" is required.',
                    },
                    'correlation_id': correlation_id,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        context_raw = request.data.get('context', '{}')
        if isinstance(context_raw, str):
            try:
                context_data = json.loads(context_raw)
            except json.JSONDecodeError:
                context_data = {}
        else:
            context_data = dict(context_raw) if context_raw else {}

        serializer = VoiceCommandSubmitSerializer(data=context_data)
        if not serializer.is_valid():
            return Response(
                {'error': {'code': 'INVALID_REQUEST', 'message': str(serializer.errors)}, 'correlation_id': correlation_id},
                status=status.HTTP_400_BAD_REQUEST,
            )
        context = serializer.validated_data
        context['correlation_id'] = correlation_id

        audio_bytes = audio_file.read()
        mime_type = audio_file.content_type or 'audio/webm'

        start_ms = int(time.time() * 1000)
        result = process_voice_command(audio_bytes, mime_type, context)
        latency_ms = int(time.time() * 1000) - start_ms

        # Persist log
        log = VoiceCommandLog(
            correlation_id=correlation_id,
            tenant_id=context.get('tenant_id') or '',
            user_id=context.get('user_id') or '',
            job_id=context.get('job_id') or '',
            step_id=context.get('step_id') or '',
            screen=context.get('screen') or '',
            locale=context.get('locale', 'en'),
            source_app=context.get('source_app', 'tech'),
            transcript_redacted=(result.get('transcript') or '')[:512],
            transcript_confidence=result.get('transcript_confidence'),
            intent_name=(result.get('intent') or {}).get('name'),
            intent_confidence=(result.get('intent') or {}).get('confidence'),
            entities_json=result.get('entities') or [],
            action_json=result.get('action'),
            confirmation_required=bool(result.get('confirmation_required')),
            confirmation_token=result.get('confirmation_token'),
            client_action_type=(result.get('action') or {}).get('type'),
            status=result.get('status', 'failed'),
            latency_ms=latency_ms,
            error_json=result.get('error'),
        )
        log.save()

        _write_audit_event(
            feature='voice', action='command_received',
            entity_type='voice_command_log', entity_id=log.voice_command_id,
            actor_user_id=context.get('user_id'),
            after_json={'intent': (result.get('intent') or {}).get('name')},
            correlation_id=correlation_id,
            tenant_id=context.get('tenant_id'),
        )

        return Response(
            {
                'voice_command_id': log.voice_command_id,
                'correlation_id': correlation_id,
                'status': log.status,
                'transcript': result.get('transcript'),
                'transcript_confidence': result.get('transcript_confidence'),
                'intent': result.get('intent'),
                'entities': result.get('entities') or [],
                'action': result.get('action'),
                'confirmation_required': log.confirmation_required,
                'confirmation_token': log.confirmation_token,
                'ui_message': result.get('ui_message'),
                'latency_ms': latency_ms,
                **(({'error': result['error']} if result.get('error') else {})),
            },
            status=status.HTTP_200_OK,
        )


class VoiceCommandResultView(APIView):
    """GET /api/v1/voice/commands/<command_id>"""

    def get(self, request, command_id):
        log = get_object_or_404(VoiceCommandLog, voice_command_id=command_id)
        return Response(
            {
                'voice_command_id': log.voice_command_id,
                'correlation_id': log.correlation_id,
                'status': log.status,
                'intent': {
                    'name': log.intent_name,
                    'confidence': log.intent_confidence,
                } if log.intent_name else None,
                'entities': log.entities_json or [],
                'action': log.action_json,
                'confirmation_required': log.confirmation_required,
                'confirmation_token': log.confirmation_token,
                'execution_status': log.execution_status,
                'latency_ms': log.latency_ms,
            },
            status=status.HTTP_200_OK,
        )


class AssistAnalyzeView(APIView):
    parser_classes = [JSONParser]

    def post(self, request):
        correlation_id = _get_or_create_correlation_id(request)

        serializer = AssistAnalyzeSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(
                {'error': {'code': 'INVALID_REQUEST', 'message': str(serializer.errors)}, 'correlation_id': correlation_id},
                status=status.HTTP_400_BAD_REQUEST,
            )
        data = serializer.validated_data

        start_ms = int(time.time() * 1000)
        guidance = get_assist_guidance(
            job_id=data['job_id'],
            step_id=data['step_id'],
            question=data.get('question'),
            requirements=data.get('requirements') or [],
            evidence_state=data.get('evidence_state') or [],
            recent_outcomes=data.get('recent_ai_outcomes') or [],
        )
        latency_ms = int(time.time() * 1000) - start_ms

        assist_obj = AssistRequest.objects.create(
            correlation_id=correlation_id,
            tenant_id=data.get('tenant_id') or '',
            user_id=data.get('user_id') or '',
            job_id=data['job_id'],
            step_id=data['step_id'],
            question=data.get('question'),
            source_app=data.get('source_app', 'tech'),
            status=AssistRequest.Status.COMPLETE,
            response_json=guidance,
            latency_ms=latency_ms,
        )

        return Response(
            {
                'assist_id': assist_obj.assist_id,
                'correlation_id': correlation_id,
                'status': 'complete',
                'summary': guidance.get('summary'),
                'suggestions': guidance.get('suggestions') or [],
                'gaps': guidance.get('gaps') or [],
                'latency_ms': latency_ms,
            },
            status=status.HTTP_200_OK,
        )
