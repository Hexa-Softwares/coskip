# Postman payloads by image URL

Use **Body → raw → JSON** in Postman. Set **URL:** `POST http://127.0.0.1:8000/api/v1/image-analysis` and **Header:** `Authorization: Bearer test-key-12345`.

Copy each JSON block as the full body (one request per image).

---

## Request format (image URL)

Two JSON shapes are accepted:

1. **Flat** — All fields at the top level next to `image_url` (all examples below use this).
2. **Nested** — `image_url` at top level and a single `payload` object containing the rest (mirrors multipart convention). Use this when you don’t have `job_id` at the top level.

**Flat example:**
```json
{
  "image_url": "https://example.com/photo.jpg",
  "job_id": "JOB-1",
  "step_id": "step_1",
  "evidence_label": "Evidence label",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["req_1"],
  "sync": true
}
```

**Nested example (equivalent):**
```json
{
  "image_url": "https://example.com/photo.jpg",
  "payload": {
    "job_id": "JOB-1",
    "step_id": "step_1",
    "evidence_label": "Evidence label",
    "uploader_user_id": "u1",
    "uploader_role": "tech",
    "requirement_ids": ["req_1"],
    "sync": true
  }
}
```

**Note:** Only HTTPS image URLs are allowed. The image is downloaded and converted to JPEG before analysis.

---

## PLUMBING

### 1. Under-sink drain issue (circled joint)
```json
{
  "image_url": "https://i.sstatic.net/FUE61.jpg",
  "job_id": "JOB-PLUMB",
  "step_id": "under_sink_drain",
  "evidence_label": "Under-sink drain issue with leak callout",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drain_visible", "leak_area_visible"],
  "sync": true
}
```

### 2. Under-sink pipe / connection detail (close-up)
```json
{
  "image_url": "https://i.sstatic.net/p6trG.jpg",
  "job_id": "JOB-PLUMB",
  "step_id": "under_sink_detail",
  "evidence_label": "Under-sink pipe or connection detail",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["connection_visible", "pipe_visible"],
  "sync": true
}
```

### 3. Leaky shutoff / valve assembly (marked “Leaking”)
```json
{
  "image_url": "https://i.sstatic.net/U48Hl.png",
  "job_id": "JOB-PLUMB",
  "step_id": "shutoff_valve",
  "evidence_label": "Leaky shutoff or valve assembly",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["valve_visible", "leak_visible"],
  "sync": true
}
```

### 4. Leaky shutoff / valve assembly (alt angle)
```json
{
  "image_url": "https://i.sstatic.net/BLyPj.png",
  "job_id": "JOB-PLUMB",
  "step_id": "shutoff_valve_alt",
  "evidence_label": "Leaky shutoff or valve assembly",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["valve_visible", "leak_visible"],
  "sync": true
}
```

### 5. PVC elbow leak / droplet at elbow (attic/vent context)
```json
{
  "image_url": "https://i.sstatic.net/yP7eT.jpg",
  "job_id": "JOB-PLUMB",
  "step_id": "pvc_elbow_leak",
  "evidence_label": "PVC elbow or joint leak",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["pvc_visible", "leak_visible"],
  "sync": true
}
```

### 6. PVC joint leak (circled)
```json
{
  "image_url": "https://i.sstatic.net/xABrh.jpg",
  "job_id": "JOB-PLUMB",
  "step_id": "pvc_joint_leak",
  "evidence_label": "PVC joint leak",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["joint_visible", "leak_visible"],
  "sync": true
}
```

---

## HVAC

### 7. Condensate / drain piping at air handler (full context)
```json
{
  "image_url": "https://i.sstatic.net/YkqHR.jpg",
  "job_id": "JOB-HVAC",
  "step_id": "condensate_full",
  "evidence_label": "HVAC condensate drain PVC at air handler",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["condensate_drain_visible"],
  "sync": true
}
```

### 8. Condensate / drain piping at air handler (close-up)
```json
{
  "image_url": "https://i.sstatic.net/poE26.jpg",
  "job_id": "JOB-HVAC",
  "step_id": "condensate_closeup",
  "evidence_label": "HVAC condensate drain PVC at air handler",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["condensate_drain_visible"],
  "sync": true
}
```

### 9. Condensate drain line exit / staining on floor
```json
{
  "image_url": "https://i.sstatic.net/igERQ.jpg",
  "job_id": "JOB-HVAC",
  "step_id": "drain_exit_staining",
  "evidence_label": "Condensate drain line exit or staining on floor",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drain_exit_visible", "staining_visible"],
  "sync": true
}
```

### 10. Laundry/utility drain routing
```json
{
  "image_url": "https://i.sstatic.net/wmSJk.jpg",
  "job_id": "JOB-HVAC",
  "step_id": "utility_drain",
  "evidence_label": "Laundry or utility drain routing",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drain_routing_visible", "piping_visible"],
  "sync": true
}
```

### 11. “Emergency drain” drip location at soffit (exterior)
```json
{
  "image_url": "https://i.sstatic.net/Kg3Hv.png",
  "job_id": "JOB-HVAC",
  "step_id": "emergency_drain_soffit",
  "evidence_label": "Emergency drain drip location at soffit or exterior",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drip_location_visible", "soffit_context_visible"],
  "sync": true
}
```

---

## BASEMENT SEWAGE / DRAINS / BACKUPS

### 12. Basement floor drain opening (top-down close-up)
```json
{
  "image_url": "https://i.sstatic.net/y7uCH.jpg",
  "job_id": "JOB-BASEMENT",
  "step_id": "floor_drain",
  "evidence_label": "Basement floor drain opening",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drain_opening_visible"],
  "sync": true
}
```

### 13. Basement/garage style drain bowl (grate removed)
```json
{
  "image_url": "https://i.sstatic.net/oKvfa.jpg",
  "job_id": "JOB-BASEMENT",
  "step_id": "drain_bowl",
  "evidence_label": "Basement or garage drain bowl",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["drain_bowl_visible"],
  "sync": true
}
```

### 14. Exterior basement stairwell with standing water
```json
{
  "image_url": "https://i.sstatic.net/6Rlmn.jpg",
  "job_id": "JOB-BASEMENT",
  "step_id": "stairwell_water",
  "evidence_label": "Exterior basement stairwell or drain problem with standing water",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["stairwell_visible", "water_or_drain_visible"],
  "sync": true
}
```

---

## GENERAL CONTRACTING / STRUCTURAL

### 15. Basement wall leak / moisture staining (opened wall)
```json
{
  "image_url": "https://i.sstatic.net/DvtYT.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "wall_leak",
  "evidence_label": "Basement wall leak or moisture staining",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["wall_visible", "leak_or_staining_visible"],
  "sync": true
}
```

### 16. Foundation crack / efflorescence close-up
```json
{
  "image_url": "https://i.sstatic.net/DgPRk.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "foundation_crack",
  "evidence_label": "Foundation crack or efflorescence",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 17. Foundation crack w/ wall context (arrow)
```json
{
  "image_url": "https://i.sstatic.net/FLN33.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "foundation_crack_context",
  "evidence_label": "Foundation crack with wall context",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 18. Foundation crack closer (arrow)
```json
{
  "image_url": "https://i.sstatic.net/9wjuK.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "foundation_crack_close",
  "evidence_label": "Foundation crack close-up",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 19. Drywall ceiling crack (wide)
```json
{
  "image_url": "https://i.sstatic.net/Wt7cX.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "ceiling_crack",
  "evidence_label": "Drywall ceiling crack",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 20. Drywall ceiling crack (close)
```json
{
  "image_url": "https://i.sstatic.net/TFKi0.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "ceiling_crack_close",
  "evidence_label": "Drywall ceiling crack",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 21. Drywall ceiling crack (close alt)
```json
{
  "image_url": "https://i.sstatic.net/Bk7yn.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "ceiling_crack_close_alt",
  "evidence_label": "Drywall ceiling crack",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["crack_visible"],
  "sync": true
}
```

### 22. Demolition / framing exposure (room gut)
```json
{
  "image_url": "https://i.sstatic.net/MjVeb.jpg",
  "job_id": "JOB-STRUCTURAL",
  "step_id": "demolition_framing",
  "evidence_label": "Demolition or framing exposure",
  "uploader_user_id": "u1",
  "uploader_role": "tech",
  "requirement_ids": ["framing_visible", "area_visible"],
  "sync": true
}
```

---

## Postman setup reminder

- **Method:** POST  
- **URL:** `http://127.0.0.1:8000/api/v1/image-analysis`  
- **Headers:** `Authorization: Bearer test-key-12345`  
- **Body:** raw → JSON → paste one of the blocks above (each includes `image_url`, so no file upload needed)

Server must be running: `python manage.py runserver`
