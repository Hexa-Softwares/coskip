"""
Django settings for config project.
"""

from pathlib import Path
from urllib.parse import urlparse
import os

from decouple import config, Csv

# ── Base ──────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent.parent

# Load GCP credentials FIRST — must happen before any google SDK import
# Senior's fix: reads path from .env and injects into os.environ
_google_creds = config('GOOGLE_APPLICATION_CREDENTIALS', default='').strip().strip('"').strip("'")
if _google_creds:
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = _google_creds

# ── Security ──────────────────────────────────────────────────────────────────
SECRET_KEY = config(
    'SECRET_KEY',
    default='django-insecure-bvpx6fyt13&*i-3gh^2(6vfrvsfx#7=%k+ul!3t2%moht99dfk',
)
DEBUG = config('DEBUG', default=True, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='', cast=Csv())

# ── Apps ──────────────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'image_analysis',
    'channels',        # WebSocket support
    'voice',    # Voice AI module
]

# ── Middleware ────────────────────────────────────────────────────────────────
MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'image_analysis.middleware.CorrelationIdMiddleware',
    'image_analysis.middleware.RateLimitMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

# ── ASGI / Channels ───────────────────────────────────────────────────────────
ASGI_APPLICATION = 'config.asgi.application'

REDIS_URL = config('REDIS_URL', default='')

if REDIS_URL:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels_redis.core.RedisChannelLayer',
            'CONFIG': {'hosts': [REDIS_URL]},
        }
    }
else:
    # Dev / single-instance fallback — no Redis needed
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels.layers.InMemoryChannelLayer',
        }
    }

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE_URL = config('DATABASE_URL', default=None)
if DATABASE_URL:
    db_url = urlparse(DATABASE_URL)
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': db_url.path[1:],
            'USER': db_url.username,
            'PASSWORD': db_url.password,
            'HOST': db_url.hostname,
            'PORT': db_url.port or 5432,
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }

BOOTSTRAP_API_KEY = config('BOOTSTRAP_API_KEY', default='').strip()

# ── Auth validators ───────────────────────────────────────────────────────────
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ── i18n ──────────────────────────────────────────────────────────────────────
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# ── Static / Media ────────────────────────────────────────────────────────────
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'

# ── REST Framework ────────────────────────────────────────────────────────────
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'image_analysis.authentication.BearerTokenAuthentication',
        'image_analysis.authentication.APIKeyAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PARSER_CLASSES': [
        'rest_framework.parsers.JSONParser',
        'rest_framework.parsers.MultiPartParser',
        'rest_framework.parsers.FormParser',
    ],
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
    ],
}

FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024

# ── Image analysis ────────────────────────────────────────────────────────────
IMAGE_MAX_SIZE_MB = 10
IMAGE_MIN_LONG_EDGE_PX = 1
IMAGE_PREFERRED_LONG_EDGE_MIN_PX = 2000
IMAGE_PREFERRED_LONG_EDGE_MAX_PX = 4000
IMAGE_ALLOWED_FORMATS = ['JPEG', 'PNG', 'HEIC']
IMAGE_ANALYSIS_TIMEOUT_SECONDS = 30
MEDIAPIPE_IMAGE_CLASSIFIER_MODEL = None

# ── Vertex AI / Gemini ────────────────────────────────────────────────────────
VERTEX_AI_ENABLED = config('VERTEX_AI_ENABLED', default=True, cast=bool)
VERTEX_AI_PROJECT = config('VERTEX_AI_PROJECT', default='woven-environs-479604-i6')

# FIX: gemini-2.0-flash is only reachable via 'global' on this project.
# Senior's file set this to 'us-central1' which caused the 404.
VERTEX_AI_LOCATION = config('VERTEX_AI_LOCATION', default='global')

VERTEX_AI_MODEL = config('VERTEX_AI_MODEL', default='gemini-2.0-flash')
VERTEX_AI_TIMEOUT_SECONDS = config('VERTEX_AI_TIMEOUT_SECONDS', default=25, cast=int)

# ── Voice Module ──────────────────────────────────────────────────────────────
GOOGLE_CLOUD_STT_ENABLED = config('GOOGLE_CLOUD_STT_ENABLED', default=True, cast=bool)
VOICE_DEFAULT_LANGUAGE   = config('VOICE_DEFAULT_LANGUAGE',   default='en-US')
TTS_VOICE_NAME           = config('TTS_VOICE_NAME',           default='en-US-Neural2-D')

# ── CORS ──────────────────────────────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = config(
    'CORS_ALLOWED_ORIGINS',
    default='http://localhost:7073,http://127.0.0.1:7073',
    cast=Csv(),
)
CORS_ALLOW_ALL_ORIGINS = config('CORS_ALLOW_ALL_ORIGINS', default=False, cast=bool)
CORS_ALLOW_CREDENTIALS = False
CORS_ALLOW_HEADERS = [
    'accept',
    'authorization',
    'content-type',
    'x-api-key',
    'x-correlation-id',
    'x-forwarded-for',
]

# ── Rate limits ───────────────────────────────────────────────────────────────
RATE_LIMIT_IMAGE_ANALYSIS = config('RATE_LIMIT_IMAGE_ANALYSIS', default='60/60',  cast=str)
RATE_LIMIT_VOICE          = config('RATE_LIMIT_VOICE',          default='120/60', cast=str)
RATE_LIMIT_ASSIST         = config('RATE_LIMIT_ASSIST',          default='60/60',  cast=str)
ASSIST_TIMEOUT_SECONDS    = config('ASSIST_TIMEOUT_SECONDS',     default=12, cast=int)

# ── Production security ───────────────────────────────────────────────────────
IS_PRODUCTION = config('IS_PRODUCTION', default=False, cast=bool)
if not DEBUG and IS_PRODUCTION:
    SECURE_PROXY_SSL_HEADER    = ('HTTP_X_FORWARDED_PROTO', 'https')
    SECURE_SSL_REDIRECT        = config('SECURE_SSL_REDIRECT',    default=True, cast=bool)
    SESSION_COOKIE_SECURE      = config('SESSION_COOKIE_SECURE',  default=True, cast=bool)
    CSRF_COOKIE_SECURE         = config('CSRF_COOKIE_SECURE',     default=True, cast=bool)
    SECURE_BROWSER_XSS_FILTER  = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    X_FRAME_OPTIONS            = 'DENY'
    SECURE_HSTS_SECONDS        = config('SECURE_HSTS_SECONDS', default=31536000, cast=int)
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD        = True
else:
    SECURE_SSL_REDIRECT   = False
    SESSION_COOKIE_SECURE = False
    CSRF_COOKIE_SECURE    = False