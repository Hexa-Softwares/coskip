from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path


def root(request):
    """Minimal root response for health/uptime checks."""
    return JsonResponse(
        {"service": "coskip-api", "api": "/api/v1/"},
        headers={"X-Content-Type-Options": "nosniff"},
    )


urlpatterns = [
    path("", root),
    path("admin/", admin.site.urls),
    path("api/v1/", include("image_analysis.urls")),
    path("api/v1/", include("voice.urls")),   # ← voice sessions REST API
]
