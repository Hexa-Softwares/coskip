#!/bin/sh
set -e

# Cloud Run sets PORT; default 8000 for local Docker / legacy Run configs
export PORT="${PORT:-8000}"

echo "[entrypoint] Running migrations..."
python manage.py migrate --noinput

echo "[entrypoint] Starting gunicorn on 0.0.0.0:${PORT} ..."
exec gunicorn config.wsgi:application \
  --bind "0.0.0.0:${PORT}" \
  --workers "${GUNICORN_WORKERS:-1}" \
  --threads "${GUNICORN_THREADS:-1}" \
  --timeout "${GUNICORN_TIMEOUT:-120}" \
  --access-logfile - \
  --error-logfile -
