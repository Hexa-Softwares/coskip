# Coskip Image Analysis API

> **Production-ready Django REST Framework microservice** for intelligent image validation and analysis using Google Vertex AI (Gemini 2.0 Flash)

[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-6.0-green.svg)](https://www.djangoproject.com/)
[![License](https://img.shields.io/badge/license-Proprietary-red.svg)]()

---

## 🚀 Overview

**Coskip** is an enterprise-grade image analysis microservice designed for insurance and maintenance claims processing. It validates proof/evidence photos against configurable requirements, detects quality issues, and provides intelligent analysis using Google Vertex AI (Gemini 2.0 Flash) with robust fallback mechanisms.

### Key Features

- ✅ **🤖 AI-Powered Analysis** — Google Vertex AI (Gemini 2.0 Flash) for context-aware image validation
- ✅ **📋 Requirement-Based Validation** — Configurable requirement checks per evidence type
- ✅ **🔍 Quality Detection** — Automatically detects blur, low light, glare, occlusion, and wrong subject
- ✅ **📦 Dual Input Methods** — File upload (multipart) or image URL (JSON)
- ✅ **⚡ Sync & Async** — Supports both synchronous and asynchronous processing
- ✅ **🛡️ Robust Fallback** — Gracefully falls back to local heuristics if AI unavailable
- ✅ **📐 Contract Compliant** — Fully compliant with Image Analysis API v1 specification
- ✅ **🎯 Object Detection** — Optional bounding box annotations for detected objects

---

## 📋 Table of Contents

- [Quick Start](#-quick-start)
- [Features](#-features)
- [Technology Stack](#-technology-stack)
- [API Documentation](#-api-documentation)
- [Testing with Postman](#-testing-with-postman)
- [Configuration](#-configuration)
- [Usage Examples](#-usage-examples)
- [Project Structure](#-project-structure)
- [Documentation](#-documentation)
- [Testing](#-testing)
- [Deployment](#-deployment)

---

## ⚡ Quick Start

### Prerequisites

- Python 3.9 or higher
- pip (Python package manager)
- Google Cloud Platform account (for Vertex AI)
- PostgreSQL (recommended) or SQLite (development)

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/WhatBuilds/coskip.git
cd coskip

# 2. Create virtual environment
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your settings (see Configuration section)

# 5. Run migrations
python manage.py migrate

# 6. Create API key (via Django admin)
python manage.py createsuperuser
python manage.py runserver
# Visit http://127.0.0.1:8000/admin → Image Analysis → API Keys → Add

# 7. Start development server
python manage.py runserver
```

### Quick Test

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -F "image=@test-image.jpg" \
  -F 'payload={"job_id":"JOB-1","step_id":"step_1","evidence_label":"Test photo","uploader_user_id":"u1","uploader_role":"tech","requirement_ids":["drain_visible"],"sync":true}'
```

---

## 📮 Testing with Postman

A **Postman collection** is provided for easy API testing and client handover.

| File | Location | Description |
|------|----------|-------------|
| **CoSkip.postman_collection.json** | [`docs/CoSkip.postman_collection.json`](docs/CoSkip.postman_collection.json) | Import into Postman to run all endpoints with pre-configured requests and examples |

**How to use:**

1. **Import** — In Postman: *File → Import* → select `docs/CoSkip.postman_collection.json`.
2. **Set variables** — In the collection, set `base_url` (e.g. `http://127.0.0.1:8000`) and `api_key` (your API key from Django admin).
3. **Run** — Use *Submit (Multipart)* or *Submit (JSON with image_url)* to send requests; *Get Analysis by Request ID* uses the `request_id` saved automatically from the last submit.

The collection includes both submission methods, the GET result endpoint, and example requests (Plumbing, HVAC, Basement, Structural) with sample payloads. See the collection description in Postman for auth (Bearer or `X-Api-Key`) and optional fields.

---

## ✨ Features

### Intelligent Image Analysis

- **Evidence Validation:** Validates images against specific evidence types (plumbing, HVAC, structural, basement, etc.)
- **Context-Aware:** Uses `evidence_label` to understand what the image should contain
- **Wrong Subject Detection:** Flags images that don't match the expected evidence type

### Quality Checks

- **Blur Detection:** Laplacian variance analysis + AI detection
- **Lighting Analysis:** Detects too dark or too bright images
- **Glare Detection:** Identifies excessive brightness/reflections
- **Occlusion Detection:** Flags when required evidence is partially obstructed
- **Missing Elements:** Validates that all required elements are visible

### Flexible Processing

- **Synchronous:** Get results immediately (`sync: true`)
- **Asynchronous:** Queue for processing and retrieve later (`sync: false`)
- **Idempotency:** Prevent duplicate processing with `idempotency_key`

### Robust Architecture

- **AI Primary:** Vertex AI Gemini 2.0 Flash for intelligent analysis
- **Heuristics Fallback:** Local blur/brightness checks when AI unavailable
- **Error Handling:** Graceful degradation with clear error messages
- **Timeout Protection:** Hard timeouts prevent hanging requests

---

## 🛠️ Technology Stack

| Component | Technology |
|-----------|-----------|
| **Backend Framework** | Django 6.0 + Django REST Framework |
| **AI/ML Engine** | Google Vertex AI (Gemini 2.0 Flash) |
| **Image Processing** | Pillow (PIL), pillow-heif |
| **Database** | PostgreSQL (production) / SQLite (development) |
| **HTTP Client** | httpx |
| **Optional ML** | MediaPipe (for object detection/classification) |
| **Python Version** | 3.9+ |

---

## 📚 API Documentation

### Base URL

```
Development: http://localhost:8000/api/v1
Production: https://your-domain.com/api/v1
```

### Authentication

```http
Authorization: Bearer your-api-key-here
```

OR

```http
x-api-key: your-api-key-here
```

### Endpoints

#### 1. Submit Image Analysis

**POST** `/api/v1/image-analysis`

**Option A: File Upload (Multipart)**
```bash
curl -X POST "http://localhost:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -F "image=@image.jpg" \
  -F 'payload={"job_id":"JOB-1","step_id":"step_1","evidence_label":"HVAC condensate drain PVC at air handler","uploader_user_id":"u1","uploader_role":"tech","requirement_ids":["condensate_drain_visible"],"sync":true}'
```

**Option B: Image URL (JSON)**
```bash
curl -X POST "http://localhost:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "image_url": "https://example.com/image.jpg",
    "job_id": "JOB-1",
    "step_id": "step_1",
    "evidence_label": "HVAC condensate drain PVC at air handler",
    "uploader_user_id": "u1",
    "uploader_role": "tech",
    "requirement_ids": ["condensate_drain_visible"],
    "sync": true
  }'
```

#### 2. Get Analysis Result

**GET** `/api/v1/image-analysis/{request_id}`

```bash
curl -X GET "http://localhost:8000/api/v1/image-analysis/imgreq_123456" \
  -H "Authorization: Bearer your-api-key"
```

### Response Example

```json
{
  "request_id": "imgreq_9c81b3f2",
  "job_id": "JOB-1",
  "step_id": "step_1",
  "evidence_label": "HVAC condensate drain PVC at air handler",
  "status": "complete",
  "analysis": {
    "model": "gemini/gemini-2.0-flash",
    "overall_score": 0.85,
    "confidence": 0.9,
    "decision": "pass",
    "summary": "Image shows HVAC air handler unit and PVC condensate drain pipe clearly visible.",
    "checks": [
      {
        "id": "condensate_drain_visible",
        "label": "Condensate drain visible",
        "required": true,
        "passed": true,
        "score": 0.9
      }
    ],
    "issues": [],
    "annotations": [
      {
        "type": "bounding_box",
        "label": "condensate drain",
        "x": 0.15,
        "y": 0.3,
        "w": 0.25,
        "h": 0.4,
        "confidence": 0.92
      }
    ]
  },
  "review": {
    "status": "pass",
    "decision": "accept",
    "required_actions": [],
    "notes": "Evidence meets requirements."
  },
  "requirements": {
    "required_count": 1,
    "required_met": 1,
    "missing": []
  },
  "timestamps": {
    "created_at": "2026-02-12T10:00:00.000Z",
    "updated_at": "2026-02-12T10:00:01.234Z"
  }
}
```

**📮 For ready-to-use API requests, import [docs/CoSkip.postman_collection.json](docs/CoSkip.postman_collection.json) into Postman.**

---

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the project root:

```bash
# Django Settings
SECRET_KEY=your-secret-key-here
DEBUG=False
ALLOWED_HOSTS=your-domain.com,localhost

# Database (PostgreSQL recommended)
DATABASE_URL=postgresql://user:password@localhost:5432/coskip

# Vertex AI / Gemini
VERTEX_AI_ENABLED=True
VERTEX_AI_PROJECT=your-gcp-project-id
VERTEX_AI_LOCATION=global
VERTEX_AI_MODEL=gemini-2.0-flash
VERTEX_AI_TIMEOUT_SECONDS=25

# Image Settings
IMAGE_MIN_LONG_EDGE_PX=1  # Set to 1280 for production
IMAGE_MAX_SIZE_MB=10
IMAGE_ALLOWED_FORMATS=JPEG,PNG,HEIC
```

### Django Settings

Key settings in `config/settings.py`:

```python
# Vertex AI Configuration
VERTEX_AI_ENABLED = True
VERTEX_AI_PROJECT = "your-gcp-project-id"
VERTEX_AI_LOCATION = "global"
VERTEX_AI_MODEL = "gemini-2.0-flash"
VERTEX_AI_TIMEOUT_SECONDS = 25

# Image Validation
IMAGE_MIN_LONG_EDGE_PX = 1  # Change to 1280 for production
IMAGE_MAX_SIZE_MB = 10
IMAGE_ALLOWED_FORMATS = ['JPEG', 'PNG', 'HEIC']
```

### Google Cloud Setup

1. **Enable Vertex AI API:**
   ```bash
   gcloud services enable aiplatform.googleapis.com
   ```

2. **Set up Authentication:**
   ```bash
   gcloud auth application-default login
   ```

3. **Install Vertex AI SDK:**
   ```bash
   pip install google-cloud-aiplatform
   ```


---

## 💡 Usage Examples

### Example 1: HVAC Condensate Drain

```bash
curl -X POST "http://localhost:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "image_url": "https://example.com/hvac.jpg",
    "job_id": "JOB-HVAC-001",
    "step_id": "hvac_condensate",
    "evidence_label": "HVAC condensate drain PVC at air handler",
    "uploader_user_id": "tech_123",
    "uploader_role": "tech",
    "requirement_ids": ["condensate_drain_visible", "air_handler_visible"],
    "sync": true
  }'
```

### Example 2: Foundation Crack

```bash
curl -X POST "http://localhost:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "image_url": "https://example.com/crack.jpg",
    "job_id": "JOB-STRUCT-001",
    "step_id": "foundation_inspection",
    "evidence_label": "Foundation or basement wall crack",
    "uploader_user_id": "tech_123",
    "uploader_role": "tech",
    "requirement_ids": ["crack_visible", "location_context_visible"],
    "sync": true
  }'
```

### Example 3: Async Processing

```bash
# Submit request (async)
curl -X POST "http://localhost:8000/api/v1/image-analysis" \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "image_url": "https://example.com/image.jpg",
    "job_id": "JOB-1",
    "step_id": "step_1",
    "evidence_label": "Plumbing drain visible",
    "uploader_user_id": "u1",
    "uploader_role": "tech",
    "requirement_ids": ["drain_visible"],
    "sync": false
  }'

# Response: {"request_id": "imgreq_123456", "status": "queued", ...}

# Retrieve result
curl -X GET "http://localhost:8000/api/v1/image-analysis/imgreq_123456" \
  -H "Authorization: Bearer your-api-key"
```

**📖 For more examples and payload details, see [docs/POSTMAN_PAYLOADS_BY_IMAGE_URL.md](docs/POSTMAN_PAYLOADS_BY_IMAGE_URL.md).**

---

## 📁 Project Structure

```mermaid
flowchart TB
    subgraph root["coskip/"]
        subgraph config["config/"]
            s1["settings.py"]
            u1["urls.py"]
            w1["wsgi.py"]
        end
        subgraph app["image_analysis/"]
            m["models.py"]
            v["views.py"]
            ser["serializers.py"]
            auth["authentication.py"]
            u2["urls.py"]
            subgraph svc["services/"]
                a["analysis.py"]
                vert["vertex_ai.py"]
                val["validation.py"]
                st["storage.py"]
            end
        end
        subgraph scripts["scripts/"]
            test_vertex["test_vertex.py"]
        end
        subgraph docs["docs/"]
            postman["CoSkip.postman_collection.json"]
            payloads["POSTMAN_PAYLOADS_BY_IMAGE_URL.md"]
        end
        manage["manage.py"]
        reqs["requirements.txt"]
        readme["README.md"]
    end
```

---

## 📖 Documentation

Documentation and API assets live in the `docs/` directory:

| Document | Description |
|----------|-------------|
| **[CoSkip.postman_collection.json](docs/CoSkip.postman_collection.json)** | Postman collection — import for API testing and handover |
| **[POSTMAN_PAYLOADS_BY_IMAGE_URL.md](docs/POSTMAN_PAYLOADS_BY_IMAGE_URL.md)** | Payload examples using `image_url` (JSON) |

---

## 🧪 Testing

### Manual Testing

- **Postman (recommended)** — Import [docs/CoSkip.postman_collection.json](docs/CoSkip.postman_collection.json), set `base_url` and `api_key`, and run the requests. See [Testing with Postman](#-testing-with-postman) above.
- **curl** — See the [Quick Start](#-quick-start) section for basic curl examples.

### Automated Testing

```bash
# Test Vertex AI connectivity (optional)
python scripts/test_vertex.py
```

For full API testing, use the [Postman collection](docs/CoSkip.postman_collection.json) or the curl examples in this README.

### Test Results

Run the [Postman collection](docs/CoSkip.postman_collection.json) or use the curl examples in this README to verify the API.

---

## 🚀 Deployment

### Development

```bash
python manage.py runserver
```

### Production (Gunicorn + Nginx)

```bash
# Install Gunicorn
pip install gunicorn

# Run with Gunicorn
gunicorn --bind 0.0.0.0:8000 --workers 4 config.wsgi:application
```


---

## 🔧 Common Commands

| Command | Description |
|--------|-------------|
| `python manage.py runserver` | Start development server |
| `python manage.py migrate` | Apply database migrations |
| `python manage.py makemigrations` | Create migrations after model changes |
| `python manage.py createsuperuser` | Create admin user |
| `python manage.py shell` | Django shell |
| `python manage.py collectstatic` | Collect static files |

---

## 🐛 Troubleshooting

### Common Issues

**Vertex AI 404 Error:**
- Verify project ID: `gcloud config get-value project`
- Enable Vertex AI API: `gcloud services enable aiplatform.googleapis.com`
- Check authentication: `gcloud auth application-default login`

**Image Validation Failures:**
- Check `IMAGE_MIN_LONG_EDGE_PX` setting
- Verify image format is JPEG/PNG/HEIC
- Ensure image file is not corrupted

**Authentication Failures:**
- Verify API key exists in database
- Check API key is active (`is_active=True`)
- Verify `Authorization` header format: `Bearer your-key`


---

## 📝 License

Proprietary — All rights reserved

---

## 👥 Support

- **API testing:** [docs/CoSkip.postman_collection.json](docs/CoSkip.postman_collection.json) (Postman)
- **Payload examples:** [docs/POSTMAN_PAYLOADS_BY_IMAGE_URL.md](docs/POSTMAN_PAYLOADS_BY_IMAGE_URL.md)

---

## 🎯 Key Highlights

- ✅ **Production Ready** — Fully tested and deployed
- ✅ **AI-Powered** — Google Vertex AI (Gemini 2.0 Flash) integration
- ✅ **Robust** — Graceful fallback mechanisms
- ✅ **Compliant** — Meets Image Analysis API v1 specification
- ✅ **Well Documented** — Comprehensive documentation and Postman collection in `docs/`
- ✅ **Flexible** — Supports multiple input methods and processing modes

---

**Built with ❤️ using Django, Vertex AI, and modern Python best practices**
